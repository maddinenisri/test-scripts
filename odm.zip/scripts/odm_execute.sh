#!/usr/bin/env bash
#
# Track B execute-with-trace harness.
#
# Calls a deployed ODM decision operation via the HTDS REST endpoint with the
# __TraceFilter__ enabled, then writes ONE trace record (input_id, operation,
# fired_rules[], output) in the format `odm-trace --execution-trace` ingests.
#
# Run many inputs, concatenate the records into a JSON array, then:
#   odm-trace "<project>" -o out --execution-trace traces.json
#
# Usage:
#   scripts/odm_execute.sh <input.json> <input_id> <operation_name> >> records.ndjson
#
# Env (defaults match docker/docker-compose.yml):
#   RES_BASE   default http://localhost:9060
#   RULEAPP    e.g. claim_processing      RULEAPP_VER  default 1.0
#   RULESET    e.g. claim_processingRuleset   RULESET_VER default 1.0
#   ODM_USER / ODM_PASS  default odmAdmin / odmAdmin
set -euo pipefail

INPUT_FILE="$1"; INPUT_ID="$2"; OPERATION="$3"
RES_BASE="${RES_BASE:-http://localhost:9060}"
# RULEAPP/RULESET are only needed for a live call (not for RESP_FILE offline replay).
if [ -z "${RESP_FILE:-}" ]; then
  : "${RULEAPP:?set RULEAPP (or set RESP_FILE to replay a saved response)}"
  : "${RULESET:?set RULESET (or set RESP_FILE to replay a saved response)}"
fi
RULEAPP="${RULEAPP:-}"; RULEAPP_VER="${RULEAPP_VER:-1.0}"
RULESET="${RULESET:-}"; RULESET_VER="${RULESET_VER:-1.0}"
USER="${ODM_USER:-odmAdmin}"; PASS="${ODM_PASS:-odmAdmin}"

# HTDS Decision Engine REST path: /DecisionService/rest/<app>/<appV>/<ruleset>/<rulesetV>
# (older/XU deployments use a different prefix — override with HTDS_PREFIX if needed).
HTDS_PREFIX="${HTDS_PREFIX:-DecisionService/rest}"
URL="$RES_BASE/$HTDS_PREFIX/$RULEAPP/$RULEAPP_VER/$RULESET/$RULESET_VER"

# Inject the trace filter + a decision id into the caller's input JSON.
BODY="$(python3 - "$INPUT_FILE" "$INPUT_ID" <<'PY'
import json, sys
body = json.load(open(sys.argv[1]))
body["__DecisionID__"] = sys.argv[2]
body["__TraceFilter__"] = {
    "infoRulesFired": True, "infoTotalRulesFired": True,
    "infoTasksExecuted": True, "infoRulesNotFired": False,
}
print(json.dumps(body))
PY
)"

# RESP_FILE replays a saved HTDS response (offline) instead of calling ODM — used to
# validate the extraction without a live server, and to re-merge captured responses.
if [ -n "${RESP_FILE:-}" ]; then
  RESP="$(cat "$RESP_FILE")"
else
  RESP="$(curl -sk -X POST -H "Content-Type: application/json" -u "$USER:$PASS" -d "$BODY" "$URL")"
fi

# Extract fired rules + output into one ingestion record. The extraction lives in the
# `odm.htds` module (one tested implementation; requires the `odm` package installed,
# same as the `odm-trace` merge step). Each fired rule becomes {name, path?, uuid?} so
# the merge can disambiguate rules that share a bare name.
printf '%s' "$RESP" | python3 -m odm.htds "$INPUT_ID" "$OPERATION"
