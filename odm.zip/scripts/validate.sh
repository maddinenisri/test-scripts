#!/usr/bin/env bash
#
# Baseline validation: clone the public IBM ODM sample projects, run odm-trace on
# each, and assert the expected operations / ruleflows / 0-unresolved. Prints
# PASS/FAIL per project and exits non-zero if any baseline regresses.
#
# Usage:
#   scripts/validate.sh           # 3 quick samples
#   scripts/validate.sh --full    # also the large decision-microservice (12 ops)
#
# Override the clone cache dir with ODM_VALIDATE_CACHE.

set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CACHE="${ODM_VALIDATE_CACHE:-$ROOT/.validate-cache}"
OUT="$(mktemp -d)"
mkdir -p "$CACHE"
trap 'rm -rf "$OUT"' EXIT

# Activate the project venv if present.
[ -f "$ROOT/.venv/bin/activate" ] && source "$ROOT/.venv/bin/activate"

# Prefer the installed console script; fall back to the module.
if command -v odm-trace >/dev/null 2>&1; then TRACE=(odm-trace); else TRACE=(python -m odm.cli); fi

pass=0; fail=0

clone() { # repo-name cache-dir
  if [ ! -d "$CACHE/$2/.git" ]; then
    echo "  · cloning $1 ..."
    git clone --depth 1 "https://github.com/DecisionsDev/$1.git" "$CACHE/$2" >/dev/null 2>&1 \
      || { echo "  · clone failed: $1"; return 1; }
  fi
}

check() { # label source-path expected-ops expected-flows
  local label="$1" src="$2" eo="$3" ef="$4"
  rm -rf "$OUT/o"
  "${TRACE[@]}" "$src" -o "$OUT/o" -q >/dev/null 2>&1
  if [ ! -f "$OUT/o/_workspace_summary.json" ]; then
    printf "  \033[31mFAIL\033[0m  %-24s (no output produced)\n" "$label"; fail=$((fail+1)); return
  fi
  read -r ops flows unres < <(python3 - "$OUT/o" <<'PY'
import json, sys
b = sys.argv[1]
s = json.load(open(b + "/_workspace_summary.json"))
d = json.load(open(b + "/operation_trace.json"))
flows = {(t["ruleflow"]["name"] if t["ruleflow"] else t["execution_kind"]) for t in d}
print(s["operations"], len(flows), s["unresolved_total"])
PY
)
  if [ "$ops" = "$eo" ] && [ "$flows" = "$ef" ] && [ "$unres" = "0" ]; then
    printf "  \033[32mPASS\033[0m  %-24s ops=%s flows=%s unresolved=0\n" "$label" "$ops" "$flows"
    pass=$((pass+1))
  else
    printf "  \033[31mFAIL\033[0m  %-24s ops=%s(exp %s) flows=%s(exp %s) unresolved=%s\n" \
      "$label" "$ops" "$eo" "$flows" "$ef" "$unres"
    fail=$((fail+1))
  fi
}

echo "ODM parser — baseline validation"
echo "cache: $CACHE"
echo

clone odm-on-cloud-getting-started getting-started && check "miniloan"               "$CACHE/getting-started/Miniloan Service" 1 1
clone odm-on-cloud-debug          debug           && check "loan-validation"        "$CACHE/debug/answer"                     4 3
clone odm-transformation-advisor  ota             && check "transformation-advisor" "$CACHE/ota"                              2 2

if [ "${1:-}" = "--full" ]; then
  clone decision-microservice dmsvc && check "decision-microservice" "$CACHE/dmsvc" 12 5
fi

# local nested-sub-flow sample (in-repo, no clone)
SAMPLE="$ROOT/samples/nested-claim/ClaimProcessing"
if [ -d "$SAMPLE" ]; then
  rm -rf "$OUT/o"; "${TRACE[@]}" "$SAMPLE" -o "$OUT/o" -q >/dev/null 2>&1
  read -r ops unres rules depth < <(python3 - "$OUT/o" <<'PYEOF'
import json, sys
b = sys.argv[1]
s = json.load(open(b + "/_workspace_summary.json")); d = json.load(open(b + "/operation_trace.json"))
def depth(st): return 0 if not st else 1 + max((depth(x.get("substeps", [])) for x in st), default=0)
def rules(st):
    n = 0
    for x in st: n += len(x["rules"]) + rules(x.get("substeps", []))
    return n
print(s["operations"], s["unresolved_total"], rules(d[0]["steps"]) if d else 0, depth(d[0]["steps"]) if d else 0)
PYEOF
)
  if [ "$ops" = 1 ] && [ "$unres" = 0 ] && [ "$rules" -ge 18 ] && [ "$depth" -ge 4 ]; then
    printf "  \033[32mPASS\033[0m  %-24s ops=1 rules=%s nesting-depth=%s unresolved=0\n" "nested-claim (local)" "$rules" "$depth"; pass=$((pass+1))
  else
    printf "  \033[31mFAIL\033[0m  %-24s ops=%s rules=%s depth=%s unresolved=%s\n" "nested-claim (local)" "$ops" "$rules" "$depth" "$unres"; fail=$((fail+1))
  fi
fi


echo
echo "----------------------------------------"
echo "PASS=$pass  FAIL=$fail"
if [ "$fail" -eq 0 ]; then echo "ALL GREEN ✅"; else echo "REGRESSIONS ❌"; exit 1; fi
