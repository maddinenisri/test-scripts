#!/usr/bin/env python3
"""Standalone tester for the LLM interaction (against a Claude-compatible proxy).

Send a PRD bundle (or any prompt) through the proxy and print the result. Mirrors
the proxy's own `scripts/test_proxy_chat.py`, but uses the package's `llm` client so
you can exercise exactly the code path `odm-parser --llm-endpoint` uses.

Examples:
    python3 scripts/llm_prd.py --health
    python3 scripts/llm_prd.py --prompt "Reply with exactly: proxy_ok"
    python3 scripts/llm_prd.py out/<project>/prd-bundles/<flow>.md -o flow.prd.md
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Allow running the script directly from the repo without installing.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from odm_parser.llm import LLMClient, LLMConfig, LLMError  # noqa: E402


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("bundle", nargs="?", help="path to a PRD bundle .md file")
    parser.add_argument("--prompt", help="send this literal prompt instead of a file")
    parser.add_argument("--base-url", default="http://127.0.0.1:9001")
    parser.add_argument("--model", default=None)
    parser.add_argument("--max-tokens", type=int, default=None)
    parser.add_argument("-o", "--out", help="write the result here instead of stdout")
    parser.add_argument("--health", action="store_true", help="only check proxy health")
    args = parser.parse_args(argv)

    client = LLMClient(
        LLMConfig(base_url=args.base_url, model=args.model, max_tokens=args.max_tokens)
    )

    if args.health:
        ok = client.health()
        print(f"proxy {args.base_url}: {'reachable' if ok else 'UNREACHABLE'}")
        return 0 if ok else 1

    if args.prompt:
        text = args.prompt
    elif args.bundle:
        text = Path(args.bundle).read_text(encoding="utf-8")
    else:
        parser.error("provide a bundle file, --prompt, or --health")

    try:
        result = client.complete(text)
    except LLMError as exc:
        print(f"LLM error: {exc}", file=sys.stderr)
        return 1

    if args.out:
        Path(args.out).write_text(result, encoding="utf-8")
        print(f"wrote {len(result)} chars to {args.out}")
    else:
        print(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
