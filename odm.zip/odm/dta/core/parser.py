"""
DTA (Decision Table) parser for IBM ODM .dta files (Studio XML format).

A .dta file is a single decision table stored in IBM ODM Studio XML format.

Each decision row becomes a ClassMethod (one rule per row). Table-level ODM fields
are collected in a single parse pass with the row registry.

Mapping:
  metadata.classes            → one Class per table; each row → ClassMethod
  metadata.odm_file_metadata  → decision table + row registry for enrich/ingest
"""

import logging
import re
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from ...models import (
    CallExpression,
    Class,
    ClassAttribute,
    ClassMethod,
    Metadata,
    OdmDecisionTable,
    OdmDecisionTableExecution,
    OdmDecisionTableRow,
    OdmFile,
    OdmFileMetadata,
    OdmScenarioAssignment,
    Parameter,
)
from ...utils import Tokenizer, consistent_key_uuid
from ...base_odm_parser import BaseODMParser
from ...bom_helpers import extract_bom_qualified_types_from_dta
from ...source_positions import (
    SourceSpan,
    element_span,
    fragment_span_in_element,
    parse_xml_root,
)
from ...xml_utils import (
    extract_documentation,
    extract_element_studio_uuid,
    extract_studio_uuid,
    find_first_el,
    strip_ns,
)

logger = logging.getLogger(__name__)


def _execution_from_dict(meta: Dict[str, Any]) -> Optional[OdmDecisionTableExecution]:
    if not meta:
        return None
    return OdmDecisionTableExecution(
        hit_policy=meta.get("hit_policy"),
        rule_ordering=meta.get("rule_ordering"),
        policy=meta.get("policy"),
        execution_mode=meta.get("execution_mode"),
    )


class DTAParser(BaseODMParser):
    """Parses IBM ODM .dta decision-table Studio XML into standard Metadata."""

    def __init__(self):
        super().__init__()
        self._dta_odm_context: Optional[Dict[str, Any]] = None

    def _get_language_name(self) -> str:
        return "odm_dta"

    def _extract_odm_metadata(
        self, source_code: str, file_name: str, file_uuid: str
    ) -> Optional[OdmFileMetadata]:
        ctx = self._dta_odm_context
        if not ctx:
            return None

        execution = _execution_from_dict(ctx.get("execution_meta") or {})
        decision_table = OdmDecisionTable(
            name=ctx["table_name"],
            table_key=ctx["table_key"],
            class_key=ctx.get("class_key", ""),
            studio_uuid=ctx.get("studio_uuid"),
            documentation=ctx.get("documentation"),
            execution=execution,
            preconditions=ctx.get("preconditions"),
            precondition_statements=ctx.get("precondition_statements") or [],
            bom_type_refs=ctx.get("bom_type_refs") or [],
        )
        odm_file = OdmFile(
            key=file_uuid,
            file_name=file_name,
            language="odm_dta",
            parsed_date_time=datetime.now(),
            studio_uuid=ctx.get("studio_uuid"),
        )
        return OdmFileMetadata(
            file=odm_file,
            decision_tables=[decision_table],
            decision_table_rows=ctx.get("rows") or [],
            parsed_date_time=datetime.now(),
        )

    def _extract_classes(self, source_code: str, file_uuid: str) -> List[Class]:
        try:
            root = parse_xml_root(source_code)
        except ET.ParseError:
            return []

        name_el = find_first_el(root, "name")
        table_name = (
            name_el.text.strip()
            if name_el is not None and name_el.text
            else "UnnamedTable"
        )

        cond_headers, action_headers, _, _ = self._parse_headers(root)
        precond_text, precond_statements, precond_span = self._parse_preconditions(
            source_code, root
        )

        row_registry: List[OdmDecisionTableRow] = []
        class_key = consistent_key_uuid(f"{file_uuid}-dta-class-{table_name}")
        self._dta_odm_context = {
            "table_name": table_name,
            "table_key": consistent_key_uuid(f"{file_uuid}-dta-table-{table_name}"),
            "studio_uuid": extract_studio_uuid(root),
            "documentation": extract_documentation(root),
            "execution_meta": self._parse_execution_metadata(root),
            "preconditions": precond_text,
            "precondition_statements": precond_statements,
            "rows": [],
            "class_key": class_key,
            "bom_type_refs": [],
        }

        methods = self._parse_rows(
            source_code, root, table_name, cond_headers, action_headers, file_uuid, row_registry,
        )
        bom_type_refs = extract_bom_qualified_types_from_dta(source_code)
        if not methods and not bom_type_refs and not cond_headers and not action_headers:
            self._dta_odm_context = None
            return []

        self._dta_odm_context["rows"] = row_registry
        self._dta_odm_context["bom_type_refs"] = bom_type_refs

        if methods:
            class_span = SourceSpan(
                min(m.start_line for m in methods),
                min(m.start_column for m in methods),
                max(m.end_line for m in methods),
                max(m.end_column for m in methods),
            )
        else:
            class_span = element_span(source_code, root)
        name_span = element_span(source_code, name_el) if name_el is not None else class_span
        attributes: List[ClassAttribute] = [
            ClassAttribute(
                name="table_type", type="str",
                start_line=name_span.start_line, start_column=name_span.start_column,
                end_line=name_span.end_line, end_column=name_span.end_column,
            )
        ]
        if precond_text and precond_span is not None:
            attributes.append(
                ClassAttribute(
                    name="preconditions", type="precondition",
                    start_line=precond_span.start_line, start_column=precond_span.start_column,
                    end_line=precond_span.end_line, end_column=precond_span.end_column,
                )
            )
        cls = Class(
            name=table_name,
            start_line=class_span.start_line, start_column=class_span.start_column,
            end_line=class_span.end_line, end_column=class_span.end_column,
            methods=methods, attributes=attributes, extends=[], implements=[],
        )
        cls.key = class_key
        return [cls]

    def parse_file(self, relative_path: str, file_name: str, source_code: str, file_hash: str, file_uuid: str, charset: str = "utf-8", parser_run_config=None, s3_handler=None):
        self._dta_odm_context = None
        metadata = self._create_metadata()
        try:
            package = self._extract_package(source_code)
            metadata.file = self._create_file_metadata(
                source_code=source_code, relative_path=relative_path, file_name=file_name,
                file_hash=file_hash, file_uuid=file_uuid, charset=charset, package=package,
            )
            metadata.functions = self._extract_functions(source_code, file_uuid)
            metadata.classes = self._extract_classes(source_code, file_uuid)
            metadata.interfaces = self._extract_interfaces(source_code, file_uuid)
            odm_meta = self._extract_odm_metadata(source_code, file_name, file_uuid)
            if odm_meta is not None:
                metadata.odm_file_metadata = odm_meta
        except Exception as exc:
            logger.exception(f"Error parsing ODM DTA file {relative_path}")
            self._add_processing_error_if_not_duplicate(
                metadata=metadata, title=f"Parser error: {type(exc).__name__}", detailed=str(exc),
            )
        metadata.raw_token_count = self.raw_token_count_estimator(metadata, self.tokenizer, source_code)
        metadata.input_unit_count = (
            0 if metadata.raw_token_count == 0
            else self._calculate_input_unit_count(self.tokenizer, source_code)
        )
        return metadata

    def raw_token_count_estimator(self, metadata: Metadata, tokenizer: Tokenizer, source_code: str) -> int:
        full_tokens = tokenizer.count_tokens(source_code)
        total = 0
        for cls in metadata.classes:
            total += full_tokens * len(cls.methods)
        return total

    def _parse_headers(self, root: ET.Element) -> Tuple[Dict[str, str], Dict[str, str], Dict[str, ET.Element], Dict[str, ET.Element]]:
        cond_headers: Dict[str, str] = {}
        action_headers: Dict[str, str] = {}
        cond_elements: Dict[str, ET.Element] = {}
        action_elements: Dict[str, ET.Element] = {}

        resources_el = find_first_el(root, "Resources")
        if resources_el is not None:
            for resource_set in resources_el:
                for data_el in resource_set:
                    name_attr = data_el.get("Name") or ""
                    text = data_el.text or ""
                    if "#HeaderText" in name_attr:
                        # Use only the main column header `Definitions(Cx)#HeaderText`.
                        # Skip the per-cell sub-headers `Definitions(Cx)[n]#HeaderText`
                        # (e.g. Min/Max of a range column) — they share the same Cx key
                        # and would otherwise overwrite the real column name.
                        if "]#HeaderText" in name_attr:
                            continue
                        raw = name_attr.split("(")[-1].split(")")[0]
                        if raw.startswith("C"):
                            cond_headers[raw] = text
                        elif raw.startswith("A"):
                            action_headers[raw] = text

        structure = find_first_el(root, "Structure")
        if structure is not None:
            for cond_def in structure.iter():
                if strip_ns(cond_def.tag) == "ConditionDefinition":
                    col_id = cond_def.get("Id", "")
                    if col_id not in cond_headers:
                        text_el = find_first_el(cond_def, "Text")
                        cond_headers[col_id] = (text_el.text or col_id) if text_el is not None else col_id
                    cond_elements[col_id] = cond_def
            for act_def in structure.iter():
                if strip_ns(act_def.tag) == "ActionDefinition":
                    col_id = act_def.get("Id", "")
                    if col_id not in action_headers:
                        text_el = find_first_el(act_def, "Text")
                        action_headers[col_id] = (text_el.text or col_id) if text_el is not None else col_id
                    action_elements[col_id] = act_def

        return cond_headers, action_headers, cond_elements, action_elements

    def _parse_execution_metadata(self, root: ET.Element) -> Dict[str, Any]:
        meta: Dict[str, Any] = {}
        structure = find_first_el(root, "Structure")
        candidates = [root]
        if structure is not None:
            candidates.append(structure)
        dt_el = find_first_el(root, "DT")
        if dt_el is not None:
            candidates.append(dt_el)

        attr_map = {
            "HitPolicy": "hit_policy", "hitPolicy": "hit_policy",
            "RuleOrdering": "rule_ordering", "ruleOrdering": "rule_ordering",
            "Policy": "policy",
            "ExecutionMode": "execution_mode", "executionMode": "execution_mode",
        }
        for el in candidates:
            for xml_name, key in attr_map.items():
                val = el.get(xml_name)
                if val and key not in meta:
                    meta[key] = val.strip()
            for child in el:
                ctag = strip_ns(child.tag)
                if ctag in ("HitPolicy", "RuleOrdering", "Policy", "ExecutionMode"):
                    text = (child.text or child.get("value") or "").strip()
                    key = attr_map.get(ctag, ctag.lower())
                    if text:
                        meta[key] = text
        return meta

    def _parse_rows(self, source_code: str, root: ET.Element, table_name: str, cond_headers: Dict[str, str], action_headers: Dict[str, str], file_uuid: str, row_registry: List[OdmDecisionTableRow]) -> List[ClassMethod]:
        contents = find_first_el(root, "Contents")
        if contents is None:
            dt_el = find_first_el(root, "DT")
            contents = dt_el
        if contents is None:
            return []

        methods: List[ClassMethod] = []
        counter = [0]
        class_key = self._dta_odm_context["class_key"]
        self._parse_sibling_condition_action_rows(source_code, contents, cond_headers, action_headers, table_name, file_uuid, class_key, counter, methods, row_registry)
        self._walk_tree(source_code, contents, cond_headers, action_headers, table_name, file_uuid, class_key, None, [], counter, methods, row_registry, parent_el=None)
        return methods

    def _parse_sibling_condition_action_rows(self, source_code: str, contents: ET.Element, cond_headers: Dict[str, str], action_headers: Dict[str, str], table_name: str, file_uuid: str, class_key: str, counter: List[int], methods: List[ClassMethod], row_registry: List[OdmDecisionTableRow]) -> None:
        children = list(contents)
        idx = 0
        while idx < len(children):
            child = children[idx]
            if strip_ns(child.tag) != "Condition":
                idx += 1
                continue
            cond_el = child
            action_el = None
            if idx + 1 < len(children) and strip_ns(children[idx + 1].tag) in ("Action", "ActionSet"):
                action_el = children[idx + 1]
                idx += 2
            else:
                idx += 1
            if action_el is None:
                continue
            expr_val = self._condition_expression(cond_el)
            def_id = cond_el.get("DefId", "")
            col_name = cond_headers.get(def_id, def_id)
            if col_name and expr_val:
                next_chosen = [(col_name, expr_val)]
            elif expr_val:
                next_chosen = [("condition", expr_val)]
            else:
                next_chosen = []
            action_strings = self._action_strings_for_container(action_el, action_headers)
            has_action_values = any(a.split(": ", 1)[-1].strip() for a in action_strings)
            is_placeholder = not expr_val and not has_action_values
            if is_placeholder:
                continue
            display_conds, structured_conds = self._format_row_conditions(chosen_conditions=next_chosen, fallback_expr=expr_val)
            structured_actions = self._parse_action_assignments(action_strings)
            row_uuid = extract_element_studio_uuid(cond_el) or extract_element_studio_uuid(action_el)
            self._append_row_method(source_code, cond_el, table_name, file_uuid, class_key, display_conds, action_strings, structured_conds, structured_actions, counter, methods, row_registry, row_uuid, is_placeholder=False)

    def _parse_action_assignments(self, action_strings: List[str]) -> List[OdmScenarioAssignment]:
        assignments: List[OdmScenarioAssignment] = []
        for action in action_strings:
            if not action:
                continue
            if ": " in action:
                field, value = action.split(": ", 1)
                assignments.append(OdmScenarioAssignment(field=field.strip(), value=value.strip()))
            else:
                assignments.append(OdmScenarioAssignment(field="action", value=action))
        return assignments

    def _format_row_conditions(self, *, chosen_conditions: List[Tuple[str, str]], fallback_expr: str) -> Tuple[List[str], List[OdmScenarioAssignment]]:
        display: List[str] = []
        structured: List[OdmScenarioAssignment] = []
        for field, value in chosen_conditions:
            if not field or value is None:
                continue
            display.append(f"{field} = {value}")
            structured.append(OdmScenarioAssignment(field=field, value=value))
        if not structured and fallback_expr:
            display.append(fallback_expr)
            structured.append(OdmScenarioAssignment(field="condition", value=fallback_expr))
        return display, structured

    def _action_container_for_condition(self, parent_el: Optional[ET.Element], condition_el: ET.Element) -> Optional[ET.Element]:
        action_container = next((c for c in condition_el if strip_ns(c.tag) == "ActionSet"), None)
        if action_container is not None:
            return action_container
        if parent_el is None:
            return None
        siblings = list(parent_el)
        try:
            idx = siblings.index(condition_el)
        except ValueError:
            return None
        if idx + 1 >= len(siblings):
            return None
        nxt = siblings[idx + 1]
        if strip_ns(nxt.tag) in ("ActionSet", "Action"):
            return nxt
        return None

    def _action_strings_for_container(self, action_container: ET.Element, action_headers: Dict[str, str]) -> List[str]:
        tag = strip_ns(action_container.tag)
        if tag == "ActionSet":
            return self._extract_actions(action_container, action_headers)
        if tag == "Action":
            return self._extract_actions_from_element(action_container, action_headers)
        return []

    def _walk_tree(self, source_code: str, el: ET.Element, cond_headers: Dict[str, str], action_headers: Dict[str, str], table_name: str, file_uuid: str, class_key: str, active_partition: Optional[Tuple[str, str]], chosen_conditions: List[Tuple[str, str]], counter: List[int], methods: List[ClassMethod], row_registry: List[OdmDecisionTableRow], parent_el: Optional[ET.Element] = None) -> None:
        tag = strip_ns(el.tag)

        if tag == "Condition":
            expr_val = self._condition_expression(el)
            action_set = self._action_container_for_condition(parent_el, el)
            next_chosen = chosen_conditions
            if active_partition is not None:
                _, col_name = active_partition
                if col_name:
                    next_chosen = chosen_conditions + [(col_name, expr_val)]
            elif expr_val:
                next_chosen = chosen_conditions + [("condition", expr_val)]

            if action_set is not None:
                action_strings = self._action_strings_for_container(action_set, action_headers)
                has_action_values = any(a.split(": ", 1)[-1].strip() for a in action_strings)
                is_placeholder = not expr_val and not has_action_values
                if not is_placeholder:
                    display_conds, structured_conds = self._format_row_conditions(chosen_conditions=next_chosen, fallback_expr=expr_val)
                    structured_actions = self._parse_action_assignments(action_strings)
                    row_uuid = extract_element_studio_uuid(el) or extract_element_studio_uuid(action_set)
                    self._append_row_method(source_code, el, table_name, file_uuid, class_key, display_conds, action_strings, structured_conds, structured_actions, counter, methods, row_registry, row_uuid, is_placeholder=False)

            for child in el:
                ctag = strip_ns(child.tag)
                if ctag in ("Partition", "Condition", "Contents"):
                    self._walk_tree(source_code, child, cond_headers, action_headers, table_name, file_uuid, class_key, active_partition, next_chosen if action_set is None else chosen_conditions, counter, methods, row_registry, parent_el=el)

        elif tag == "Partition":
            def_id = el.get("DefId", "")
            col_name = cond_headers.get(def_id, def_id)
            next_partition = (def_id, col_name) if def_id else None
            for child in el:
                ctag = strip_ns(child.tag)
                if ctag in ("Condition", "Partition", "Contents"):
                    self._walk_tree(source_code, child, cond_headers, action_headers, table_name, file_uuid, class_key, next_partition, chosen_conditions, counter, methods, row_registry, parent_el=el)

        elif tag in ("Contents", "DT", "Structure", "definition", "Body"):
            for child in el:
                ctag = strip_ns(child.tag)
                if ctag in ("Contents", "Partition", "Condition", "DT"):
                    self._walk_tree(source_code, child, cond_headers, action_headers, table_name, file_uuid, class_key, active_partition, chosen_conditions, counter, methods, row_registry, parent_el=el)
        else:
            for child in el:
                if strip_ns(child.tag) in ("Contents", "Partition", "Condition", "DT", "Structure"):
                    self._walk_tree(source_code, child, cond_headers, action_headers, table_name, file_uuid, class_key, active_partition, chosen_conditions, counter, methods, row_registry, parent_el=el)

    def _append_row_method(self, source_code: str, row_el: ET.Element, table_name: str, file_uuid: str, class_key: str, conditions: List[str], actions: List[str], structured_conditions: List[OdmScenarioAssignment], structured_actions: List[OdmScenarioAssignment], counter: List[int], methods: List[ClassMethod], row_registry: List[OdmDecisionTableRow], row_uuid: Optional[str], is_placeholder: bool) -> None:
        counter[0] += 1
        row_index = counter[0]
        row_span = element_span(source_code, row_el)

        calls: List[CallExpression] = []
        for action in actions:
            if not action:
                continue
            act_span = fragment_span_in_element(source_code, row_el, action)
            if act_span is None:
                act_span = row_span
            calls.append(CallExpression(function_called=action, start_line=act_span.start_line, start_column=act_span.start_column, end_line=act_span.end_line, end_column=act_span.end_column))

        method = ClassMethod(
            name=f"Rule {row_index}", class_name=table_name,
            parameters=[Parameter(name=c, type="condition", optional=False) for c in conditions if c],
            return_type="void",
            start_line=row_span.start_line, start_column=row_span.start_column,
            end_line=row_span.end_line, end_column=row_span.end_column,
            calls=calls,
            body_start_line=row_span.start_line, body_start_column=row_span.start_column,
            body_end_line=row_span.end_line, body_end_column=row_span.end_column,
        )
        uuid_suffix = row_uuid or str(row_index)
        method.key = consistent_key_uuid(f"{file_uuid}-dta-row-{table_name}-{uuid_suffix}")
        method.line_count = row_span.end_line - row_span.start_line + 1
        methods.append(method)
        row_registry.append(OdmDecisionTableRow(row_index=row_index, method_key=method.key, class_key=class_key, studio_uuid=row_uuid, conditions=structured_conditions, actions=structured_actions, is_placeholder=is_placeholder))

    def _parse_preconditions(self, source_code: str, root: ET.Element) -> Tuple[Optional[str], List[str], Optional[SourceSpan]]:
        preconds_el = find_first_el(root, "Preconditions")
        if preconds_el is None:
            return None, [], None
        text_el = find_first_el(preconds_el, "Text")
        if text_el is None or not text_el.text or not text_el.text.strip():
            return None, [], element_span(source_code, preconds_el)
        raw = text_el.text.strip()
        statements = self._split_precondition_statements(raw)
        span = element_span(source_code, text_el)
        return raw, statements, span

    def _split_precondition_statements(self, text: str) -> List[str]:
        statements: List[str] = []
        for line in text.splitlines():
            for segment in line.split(";"):
                stripped = segment.strip()
                if not stripped:
                    continue
                if re.match(r"^definitions\s*$", stripped, re.IGNORECASE):
                    continue
                stripped = re.sub(r"^definitions\s+", "", stripped, flags=re.IGNORECASE).strip()
                if stripped:
                    statements.append(stripped)
        return statements

    def _render_text_with_params(self, text: str, params: List[str]) -> str:
        t = (text or "").strip()
        p = [x.strip() for x in params if x and x.strip()]
        if not t:
            if len(p) == 1:
                return p[0]
            if len(p) > 1:
                return f"{p[0]} – {p[-1]}"
            return ""
        if not p:
            return t
        placeholder_re = re.compile(r"<[^>]+>")
        placeholders = placeholder_re.findall(t)
        if placeholders:
            idx = 0
            def repl(_: re.Match[str]) -> str:
                nonlocal idx
                if idx < len(p):
                    value = p[idx]
                    idx += 1
                    return value
                return p[-1]
            return placeholder_re.sub(repl, t)
        return f"{t} ({', '.join(p)})"

    def _condition_expression(self, condition_el: ET.Element) -> str:
        for child in condition_el:
            if strip_ns(child.tag) == "Expression":
                for sub in child:
                    if strip_ns(sub.tag) == "Otherwise":
                        return "otherwise"
                text_el = find_first_el(child, "Text")
                params = [p.text or "" for p in child if strip_ns(p.tag) == "Param" and p.text]
                if text_el is not None and text_el.text:
                    rendered = self._render_text_with_params(text_el.text, params)
                    if rendered:
                        return rendered
                if len(params) == 1:
                    return params[0]
                if len(params) > 1:
                    return f"{params[0]} – {params[-1]}"
        return ""

    def _extract_actions_from_element(self, action_el: ET.Element, action_headers: Dict[str, str]) -> List[str]:
        def_id = action_el.get("DefId", "")
        col_name = action_headers.get(def_id, def_id)
        actions: List[str] = []
        for expr in action_el:
            if strip_ns(expr.tag) != "Expression":
                continue
            params = [p.text or "" for p in expr if strip_ns(p.tag) == "Param" and p.text]
            value = params[0] if params else ""
            actions.append(f"{col_name}: {value}")
        return actions

    def _extract_actions(self, action_set_el: ET.Element, action_headers: Dict[str, str]) -> List[str]:
        actions = []
        for action_el in action_set_el:
            if strip_ns(action_el.tag) == "Action":
                actions.extend(self._extract_actions_from_element(action_el, action_headers))
        return actions
