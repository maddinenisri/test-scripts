"""
FCT (Function) parser for IBM ODM .fct files.

Each .fct file defines one ruleset function.
"""

import logging
import re
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import List, Optional, Tuple

from ...models import (
    Function,
    Metadata,
    OdmBrlRule,
    OdmFile,
    OdmFileMetadata,
    Parameter,
)
from ...utils import Tokenizer, consistent_key_uuid
from ...base_odm_parser import BaseODMParser
from ...source_positions import element_span, parse_xml_root
from ...xml_utils import child_text, extract_documentation, extract_studio_uuid, find_first_el, strip_ns

logger = logging.getLogger(__name__)

_FUNC_HEADER_RE = re.compile(
    r"function\s+(\S+)\s+(\w+)\s*\(([^)]*)\)",
    re.IGNORECASE,
)


def _parse_param_list(param_text: str) -> List[Parameter]:
    params: List[Parameter] = []
    if not param_text or not param_text.strip():
        return params
    parts: List[str] = []
    depth = 0
    current: List[str] = []
    for ch in param_text:
        if ch in "<([":
            depth += 1
        elif ch in ">)])":
            depth = max(0, depth - 1)
        if ch == "," and depth == 0:
            parts.append("".join(current).strip())
            current = []
            continue
        current.append(ch)
    tail = "".join(current).strip()
    if tail:
        parts.append(tail)
    for part in parts:
        if not part:
            continue
        tokens = part.split()
        if len(tokens) >= 2:
            params.append(Parameter(name=tokens[-1], type=" ".join(tokens[:-1]), optional=False))
        elif len(tokens) == 1:
            params.append(Parameter(name=tokens[0], type="Object", optional=False))
    return params


def _parse_fct_signature_metadata(irl_text: str) -> Tuple[str, List[Parameter]]:
    match = _FUNC_HEADER_RE.search(irl_text)
    if not match:
        return "void", []
    return_type = match.group(1)
    params = _parse_param_list(match.group(3))
    return return_type, params


def _extract_xml_parameters(root: ET.Element) -> List[Parameter]:
    params: List[Parameter] = []
    for child in root:
        if strip_ns(child.tag) != "parameters":
            continue
        for param_el in child:
            if strip_ns(param_el.tag) != "parameter":
                continue
            name = param_el.get("name") or child_text(param_el, "name") or ""
            ptype = param_el.get("type") or child_text(param_el, "type") or "Object"
            if name:
                params.append(Parameter(name=name, type=ptype, optional=False))
    return params


class FCTParser(BaseODMParser):
    """Parses IBM ODM .fct Function XML into standard Metadata."""

    def _get_language_name(self) -> str:
        return "odm_fct"

    def _extract_odm_metadata(
        self, source_code: str, file_name: str, file_uuid: str
    ) -> Optional[OdmFileMetadata]:
        try:
            root = parse_xml_root(source_code)
        except ET.ParseError:
            return None

        studio_uuid = extract_studio_uuid(root)
        name_el = find_first_el(root, "name")
        func_name = (
            name_el.text.strip()
            if name_el is not None and name_el.text
            else "UnnamedFunction"
        )
        documentation = extract_documentation(root)
        function_key = consistent_key_uuid(f"{file_uuid}-fct-{func_name}")

        return OdmFileMetadata(
            file=OdmFile(
                key=file_uuid,
                file_name=file_name,
                language="odm_fct",
                parsed_date_time=datetime.now(),
                studio_uuid=studio_uuid,
            ),
            rules=[
                OdmBrlRule(
                    name=func_name,
                    function_key=function_key,
                    studio_uuid=studio_uuid,
                    documentation=documentation,
                )
            ],
            parsed_date_time=datetime.now(),
        )

    def _extract_functions(self, source_code: str, file_uuid: str) -> List[Function]:
        try:
            root = parse_xml_root(source_code)
        except ET.ParseError as exc:
            logger.warning(f"FCTParser: XML parse error — {exc}")
            return []

        name_el = find_first_el(root, "name")
        func_name = (
            name_el.text.strip()
            if name_el is not None and name_el.text
            else "UnnamedFunction"
        )

        return_type_el = find_first_el(root, "returnType")
        xml_return_type = (
            return_type_el.text.strip()
            if return_type_el is not None and return_type_el.text
            else None
        )

        definition_el = find_first_el(root, "definition")
        irl_text = (definition_el.text or "") if definition_el is not None else ""

        parsed_return_type, parsed_params = _parse_fct_signature_metadata(irl_text)
        return_type = xml_return_type or parsed_return_type or "void"

        xml_params = _extract_xml_parameters(root)
        parameters = xml_params if xml_params else parsed_params

        if definition_el is not None:
            func_span = element_span(source_code, definition_el)
        else:
            func_span = element_span(source_code, root)

        func = Function(
            name=func_name,
            parameters=parameters,
            return_type=return_type,
            start_line=func_span.start_line,
            start_column=func_span.start_column,
            end_line=func_span.end_line,
            end_column=func_span.end_column,
            calls=[],
            body_start_line=func_span.start_line,
            body_start_column=func_span.start_column,
            body_end_line=func_span.end_line,
            body_end_column=func_span.end_column,
        )
        func.key = consistent_key_uuid(f"{file_uuid}-fct-{func_name}")
        func.line_count = func_span.end_line - func_span.start_line + 1
        return [func]

    def raw_token_count_estimator(
        self, metadata: Metadata, tokenizer: Tokenizer, source_code: str
    ) -> int:
        return tokenizer.count_tokens(source_code) * len(metadata.functions)
