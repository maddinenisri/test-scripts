"""Standalone models for the ODM parser — no external dependencies."""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Set

from pydantic import BaseModel, Field


class FileProcessingErrorType(str, Enum):
    error = "error"
    warning = "warning"


class FileProcessingErrorKind(str, Enum):
    parse = "parse"
    enrich = "enrich"


class FileProcessingError(BaseModel):
    title: str
    detailed: str
    type: FileProcessingErrorType = FileProcessingErrorType.error
    kind: FileProcessingErrorKind = FileProcessingErrorKind.parse
    start_line_number: int = -1
    start_column_number: int = -1
    end_line_number: int = -1
    end_column_number: int = -1


class File(BaseModel):
    start_line: int
    start_column: int
    end_line: int
    end_column: int
    language: str = "typescript"
    file_hash: str = ""
    parsed_file_hash: str = ""
    is_marked_for_deleted: bool = False
    is_n2s_processed: bool = False
    key: str = ""
    parsed_date_time: datetime
    relative_path: str = ""
    file_name: str = ""
    folder_path: str = ""
    extension: Optional[str] = ""
    package: Optional[str] = ""
    charset: Optional[str] = "utf-8"

    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}


class Dependency(BaseModel):
    module_name: str
    is_local: bool
    start_line: int
    start_column: int
    end_line: int
    end_column: int
    key: str = ""
    is_wild_card_import: bool = False
    related_file_keys: Optional[List[str]] = Field(default_factory=list)
    create_reverse_link: bool = False
    includes: bool = False


class Parameter(BaseModel):
    name: str
    type: str = "any"
    optional: bool = False


class CallExpression(BaseModel):
    function_called: str
    start_line: int
    start_column: int
    end_line: int
    end_column: int
    resolution_needed: bool = True


class Function(BaseModel):
    name: str
    key: str = ""
    line_count: int = 0
    parameters: List[Parameter] = Field(default_factory=list)
    return_type: str = "void"
    start_line: int
    start_column: int
    end_line: int
    end_column: int
    calls: List[CallExpression] = Field(default_factory=list)
    body_start_line: Optional[int] = None
    body_start_column: Optional[int] = None
    body_end_line: Optional[int] = None
    body_end_column: Optional[int] = None
    is_llm_extraction_attempted: bool = False
    is_llm_extraction_successful: bool = False
    is_virtual: bool = False


class ClassAttribute(BaseModel):
    name: str
    type: str = "any"
    start_line: int
    start_column: int
    end_line: int
    end_column: int


class ClassMethod(Function):
    class_name: str


class Class(BaseModel):
    name: str
    start_line: int
    start_column: int
    end_line: int
    end_column: int
    is_exported: bool = False
    extends: List[str] = Field(default_factory=list)
    implements: List[str] = Field(default_factory=list)
    attributes: List[ClassAttribute] = Field(default_factory=list)
    methods: List[ClassMethod] = Field(default_factory=list)
    key: str = ""


class Interface(BaseModel):
    name: str
    start_line: int
    start_column: int
    end_line: int
    end_column: int
    is_exported: bool = False
    extends: List[str] = Field(default_factory=list)
    attributes: List[ClassAttribute] = Field(default_factory=list)
    methods: List[ClassMethod] = Field(default_factory=list)
    key: str = ""


# --- ODM-specific models ---


class OdmFile(BaseModel):
    file_hash: str = ""
    is_marked_for_deleted: bool = False
    is_processed: bool = False
    key: str = ""
    parsed_date_time: datetime
    file_name: str = ""
    language: str = ""
    studio_uuid: Optional[str] = None

    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}


class OdmBrlRule(BaseModel):
    name: str
    function_key: str = ""
    studio_uuid: Optional[str] = None
    documentation: Optional[str] = None
    bom_type_refs: List[str] = Field(default_factory=list)
    bom_type_keys: List[str] = Field(default_factory=list)


class OdmDecisionTableExecution(BaseModel):
    hit_policy: Optional[str] = None
    rule_ordering: Optional[str] = None
    policy: Optional[str] = None
    execution_mode: Optional[str] = None


class OdmDecisionTable(BaseModel):
    name: str
    table_key: str = ""
    class_key: str = ""
    studio_uuid: Optional[str] = None
    documentation: Optional[str] = None
    execution: Optional[OdmDecisionTableExecution] = None
    preconditions: Optional[str] = None
    precondition_statements: List[str] = Field(default_factory=list)
    bom_type_refs: List[str] = Field(default_factory=list)
    bom_type_keys: List[str] = Field(default_factory=list)


class OdmScenarioAssignment(BaseModel):
    field: str
    value: str


class OdmDecisionTableRow(BaseModel):
    row_index: int
    method_key: str = ""
    class_key: str = ""
    studio_uuid: Optional[str] = None
    conditions: List[OdmScenarioAssignment] = Field(default_factory=list)
    actions: List[OdmScenarioAssignment] = Field(default_factory=list)
    is_placeholder: bool = False


class OdmRuleListEntryType(str, Enum):
    PACKAGE = "package"
    RULE = "rule"


class OdmRuleListEntry(BaseModel):
    entry_type: OdmRuleListEntryType
    list_order: int = 0
    package_name: Optional[str] = None
    rule_uuid: Optional[str] = None


class OdmFlowTransition(BaseModel):
    identifier: str = ""
    source: str = ""
    target: str = ""
    condition: Optional[str] = None
    guard: Optional[str] = None
    label: Optional[str] = None


class SubFlowCall(BaseModel):
    key: str = ""
    name: str


class OdmStepEnrichV2(BaseModel):
    type_key: str = ""
    file_key: str = ""
    method_key: str = ""
    rule_list_entries: List[OdmRuleListEntry] = Field(default_factory=list)


class OdmStep(BaseModel):
    key: str = ""
    name: str
    line_number: Optional[int] = None
    condition_desc: str
    program_name: Optional[str] = None
    step_type: str
    start_line: int
    start_column: int
    end_line: int
    end_column: int
    statement: Optional[str] = None
    sub_flow_call: Optional[SubFlowCall] = None
    is_conditional: bool = False
    condition_statement: Optional[str] = None
    order: Optional[int] = None
    task_id: Optional[str] = None
    node_id: Optional[str] = None
    next_step_ids: List[str] = Field(default_factory=list)
    predecessor_step_ids: List[str] = Field(default_factory=list)
    rule_list_entries: List[OdmRuleListEntry] = Field(default_factory=list)
    execution_mode: Optional[str] = None
    ordering: Optional[str] = None
    exit_criteria: Optional[str] = None
    initial_actions_irl: Optional[str] = None
    sub_flow_key: Optional[str] = None
    studio_uuid: Optional[str] = None
    llm_enrich_v2: Optional[OdmStepEnrichV2] = None


class BranchTypeV2(str, Enum):
    DEFAULT = "DEFAULT"
    BRANCH = "BRANCH"
    LOOP = "LOOP"


class JobFlowBranchV2(BaseModel):
    branch_id: str
    branch_type: BranchTypeV2
    label: Optional[str] = None
    condition_expression: Optional[str] = None
    step_keys: List[str] = Field(default_factory=list)
    parent_branch_id: Optional[str] = None


class JobFlowDecisionPointV2(BaseModel):
    step_key: str
    branch_ids: List[str] = Field(default_factory=list)


class JobFlowV2(BaseModel):
    schema_version: str = "2.0"
    branches: List[JobFlowBranchV2] = Field(default_factory=list)
    decision_points: List[JobFlowDecisionPointV2] = Field(default_factory=list)


class OdmFlow(BaseModel):
    name: str
    language: str
    key: str = ""
    flow_hash: str = ""
    diagram: Optional[str] = None
    steps: List[OdmStep] = Field(default_factory=list)
    transitions: List[OdmFlowTransition] = Field(default_factory=list)
    flow_v2: Optional[JobFlowV2] = None
    studio_uuid: Optional[str] = None
    documentation: Optional[str] = None
    start_line: int
    end_line: int
    is_llm_extracted: bool = False


class OdmBomMember(BaseModel):
    name: str
    data_type: str = ""
    role: str = "member"
    label: Optional[str] = None


class OdmBomTypeDetails(BaseModel):
    name: str
    package: str = ""
    qualified_name: str = ""
    kind: str = "concept"
    extends: List[str] = Field(default_factory=list)
    members: List[OdmBomMember] = Field(default_factory=list)
    class_summary: str = ""


class OdmBomType(BaseModel):
    interface_key: str = ""
    details: OdmBomTypeDetails


# --- Deployment-tier models (operation / deployment / project) ---


class OdmOperationVariable(BaseModel):
    """A variable referenced by a decision-service operation (its IN/OUT signature)."""

    name: str
    set_name: str = ""
    direction: str = "IN"  # IN | OUT | IN_OUT
    var_set_uuid: Optional[str] = None
    var_set_key: str = ""


class OdmOperation(BaseModel):
    """A `.dop` decision-service operation — the deployable unit that 'runs'."""

    name: str
    studio_uuid: Optional[str] = None
    ruleset_name: str = ""
    ruleflow_name: str = ""
    ruleflow_uuid: Optional[str] = None
    ruleflow_key: str = ""  # resolved by linker -> OdmFlow/file key
    target_project_name: str = ""
    target_project_uuid: Optional[str] = None
    target_project_key: str = ""  # resolved by linker
    description: Optional[str] = None
    variables: List[OdmOperationVariable] = Field(default_factory=list)


class OdmOperationRef(BaseModel):
    operation_name: str
    operation_uuid: Optional[str] = None
    operation_key: str = ""  # resolved by linker


class OdmVersionPolicy(BaseModel):
    label: str = ""
    ruleset: Optional[str] = None
    is_default: bool = False


class OdmDeployment(BaseModel):
    """A `.dep` RuleApp deployment descriptor."""

    name: str
    studio_uuid: Optional[str] = None
    ruleapp_name: str = ""
    production: bool = False
    operations: List[OdmOperationRef] = Field(default_factory=list)
    version_policies: List[OdmVersionPolicy] = Field(default_factory=list)


class OdmProjectDependency(BaseModel):
    name: str = ""
    project_uuid: Optional[str] = None
    project_key: str = ""  # resolved by linker


class OdmRuleProject(BaseModel):
    """A `.ruleproject` dotfile — project identity + cross-project dependencies."""

    name: str
    studio_uuid: Optional[str] = None
    build_mode: Optional[str] = None
    dependencies: List[OdmProjectDependency] = Field(default_factory=list)


class OdmB2xMethod(BaseModel):
    name: str
    parameters: List[str] = Field(default_factory=list)
    body: str = ""


class OdmB2xClass(BaseModel):
    business_name: str = ""
    methods: List[OdmB2xMethod] = Field(default_factory=list)


class OdmB2xMapping(BaseModel):
    """A `.b2xa`/`.b2x` BOM-to-XOM execution binding (what BOM methods do)."""

    studio_uuid: Optional[str] = None
    id: str = ""
    lang: str = ""
    classes: List[OdmB2xClass] = Field(default_factory=list)


class OdmQuery(BaseModel):
    """A `.qry` ruleset query."""

    name: str
    studio_uuid: Optional[str] = None
    definition: Optional[str] = None


class OdmIrlRule(BaseModel):
    """A `.irl` intermediate-rule-language artifact (raw body)."""

    name: str
    studio_uuid: Optional[str] = None
    body: Optional[str] = None


class OdmDomainTable(BaseModel):
    """A worksheet from a `.xlsx` BOM enum domain-provider workbook."""

    sheet: str = ""
    headers: List[str] = Field(default_factory=list)
    row_count: int = 0


class OdmVariable(BaseModel):
    """One typed, verbalized variable declared in a `.var` set."""

    name: str  # technical name (as referenced by operations)
    type: str = "Object"
    verbalization: Optional[str] = None
    initial_value: Optional[str] = None


class OdmVariableSet(BaseModel):
    """A `.var` ruleset variable set — keeps technical names for operation I/O typing."""

    name: str
    studio_uuid: Optional[str] = None
    variables: List[OdmVariable] = Field(default_factory=list)


class OdmFileMetadata(BaseModel):
    file: Optional[OdmFile] = None
    flows: List[OdmFlow] = Field(default_factory=list)
    rules: List[OdmBrlRule] = Field(default_factory=list)
    decision_tables: List[OdmDecisionTable] = Field(default_factory=list)
    decision_table_rows: List[OdmDecisionTableRow] = Field(default_factory=list)
    bom_types: List[OdmBomType] = Field(default_factory=list)
    operations: List[OdmOperation] = Field(default_factory=list)
    deployments: List[OdmDeployment] = Field(default_factory=list)
    rule_project: Optional[OdmRuleProject] = None
    b2x_mappings: List[OdmB2xMapping] = Field(default_factory=list)
    queries: List[OdmQuery] = Field(default_factory=list)
    irl_rules: List[OdmIrlRule] = Field(default_factory=list)
    domain_tables: List[OdmDomainTable] = Field(default_factory=list)
    variable_set: Optional[OdmVariableSet] = None
    errors: List[str] = Field(default_factory=list)
    parsed_date_time: datetime = Field(default_factory=datetime.now)


class Metadata(BaseModel):
    file: Optional[File] = None
    dependencies: List[Dependency] = Field(default_factory=list)
    functions: List[Function] = Field(default_factory=list)
    classes: List[Class] = Field(default_factory=list)
    interfaces: List[Interface] = Field(default_factory=list)
    language: Optional[str] = None
    odm_file_metadata: Optional[OdmFileMetadata] = None
    db_metadata: Optional[Any] = None
    processing_errors: List[FileProcessingError] = Field(default_factory=list)
    input_unit_count: int = 0
    raw_token_count: int = 0

    class Config:
        extra = "ignore"


# --- Helper functions ---


def build_odm_flow_v2(
    flow_steps: List[OdmStep],
    transitions: List[OdmFlowTransition],
    node_to_task: Dict[str, str],
    conditional_tasks: Set[str],
) -> Optional[JobFlowV2]:
    step_key_by_task = {s.task_id: s.key for s in flow_steps if s.task_id}
    if not conditional_tasks:
        return None

    branches: List[JobFlowBranchV2] = [
        JobFlowBranchV2(
            branch_id="main",
            branch_type=BranchTypeV2.DEFAULT,
            step_keys=[s.key for s in flow_steps],
        )
    ]
    decision_points: List[JobFlowDecisionPointV2] = []

    outgoing_by_task: Dict[str, List[OdmFlowTransition]] = {}
    for trans in transitions:
        src_task = node_to_task.get(trans.source, trans.source)
        if src_task in conditional_tasks:
            outgoing_by_task.setdefault(src_task, []).append(trans)

    for task_id, trans_list in outgoing_by_task.items():
        if len(trans_list) < 2:
            continue
        step_key = step_key_by_task.get(task_id)
        if not step_key:
            continue
        branch_ids: List[str] = []
        for idx, trans in enumerate(trans_list):
            tgt_task = node_to_task.get(trans.target, trans.target)
            tgt_key = step_key_by_task.get(tgt_task, "") if tgt_task else ""
            branch_id = f"branch-{task_id}-{idx}"
            branches.append(
                JobFlowBranchV2(
                    branch_id=branch_id,
                    branch_type=BranchTypeV2.BRANCH,
                    label=trans.label or trans.identifier or None,
                    condition_expression=trans.condition or trans.guard,
                    step_keys=[tgt_key] if tgt_key else [],
                )
            )
            branch_ids.append(branch_id)
        decision_points.append(
            JobFlowDecisionPointV2(step_key=step_key, branch_ids=branch_ids)
        )

    if not decision_points:
        return None
    return JobFlowV2(branches=branches, decision_points=decision_points)


def build_odm_bom_type_details(
    iface: Interface,
    package: str = "",
) -> OdmBomTypeDetails:
    def member_role(attr: ClassAttribute) -> str:
        attr_type = (attr.type or "").strip()
        if attr_type == "domain-static-ref":
            return "domain_static"
        if attr_type.endswith("-enum-value"):
            return "enum_value"
        if ":domain-ref" in attr_type:
            return "property"
        if attr_type in ("concept-label", "verbalization", "phrase"):
            return "phrase"
        return "member"

    def bom_kind() -> str:
        extends = [e.lower() for e in (iface.extends or [])]
        if "enumeration" in extends:
            return "enumeration"
        if "domain" in extends:
            return "domain"
        return "concept"

    pkg = (package or "").strip()
    qualified = f"{pkg}.{iface.name}" if pkg else iface.name

    return OdmBomTypeDetails(
        name=iface.name,
        package=pkg,
        qualified_name=qualified,
        kind=bom_kind(),
        extends=list(iface.extends or []),
        members=[
            OdmBomMember(
                name=attr.name,
                data_type=attr.type or "",
                role=member_role(attr),
            )
            for attr in iface.attributes or []
        ],
    )
