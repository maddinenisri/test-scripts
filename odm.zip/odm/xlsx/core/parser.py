"""
XLSX parser for IBM ODM BOM enum domain-provider workbooks.

An `.xlsx` file is a ZIP of XML parts (OOXML).  This module uses only
stdlib (zipfile + xml.etree.ElementTree) — no openpyxl or third-party deps.

Public API
----------
read_xlsx(path) -> list[list[dict]]
    Low-level reader.  Opens the workbook, reads shared strings and each
    worksheet, treats row 0 as headers, and returns one list of
    header-keyed row dicts per sheet (in workbook order).

XlsxParser(BaseODMParser)
    Fits the BaseODMParser interface.  Because XLSX is binary the normal
    text-based ``parse_file()`` path does not apply.  Callers must use
    ``XlsxParser().parse_path(path)`` instead, which is special-cased by
    the integrator on the basis of the file extension.

    ``parse_file()`` is intentionally *not* overridden; the base
    implementation is available but will receive an empty string for
    ``source_code`` because the binary cannot be decoded as text.
    ``parse_path()`` is the authoritative entry point.
"""

from __future__ import annotations

import hashlib
import logging
import os
import re
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Union

from ...base_odm_parser import BaseODMParser
from ...models import (
    Metadata,
    OdmDomainTable,
    OdmFile,
    OdmFileMetadata,
)
from ...utils import Tokenizer

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# OOXML namespace
# ---------------------------------------------------------------------------
_NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
_REL_NS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
_WB_NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _col_index(ref: str) -> int:
    """Convert an Excel column-reference prefix to a zero-based index.

    Examples::
        _col_index("A1")  -> 0
        _col_index("C5")  -> 2
        _col_index("AA3") -> 26
    """
    letters = re.match(r"[A-Z]+", ref or "")
    if not letters:
        return 0
    n = 0
    for ch in letters.group(0):
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def _cell_value(cell: ET.Element, shared: List[str]) -> str:
    """Extract the string value of a single <c> element.

    Handles:
    - ``t="s"``          — shared string index stored in <v>
    - ``t="inlineStr"``  — inline rich-text stored in <is><t>…</t></is>
    - default            — raw value in <v> (numbers, dates, booleans)
    """
    kind = cell.get("t")
    if kind == "inlineStr":
        is_el = cell.find(_NS + "is")
        if is_el is not None:
            return "".join(t.text or "" for t in is_el.iter(_NS + "t"))
        return ""
    v_el = cell.find(_NS + "v")
    if v_el is None or v_el.text is None:
        return ""
    if kind == "s":
        try:
            return shared[int(v_el.text)]
        except (IndexError, ValueError):
            return v_el.text
    return v_el.text


def _parse_sheet_grid(sheet_xml: bytes, shared: List[str]) -> List[List[str]]:
    """Parse a worksheet XML blob into a 2-D list of strings (ragged is OK).

    Sparse rows (cells with gaps) are expanded to a dense list up to the
    widest occupied cell; missing cells within a row become empty strings.
    Completely empty rows are skipped.
    """
    root = ET.fromstring(sheet_xml)
    grid: List[List[str]] = []
    for row_el in root.iter(_NS + "row"):
        cell_map: dict[int, str] = {}
        for cell in row_el.findall(_NS + "c"):
            value = _cell_value(cell, shared)
            if value != "":
                col = _col_index(cell.get("r", ""))
                cell_map[col] = value
        if cell_map:
            width = max(cell_map) + 1
            grid.append([cell_map.get(i, "") for i in range(width)])
    return grid


def _read_shared_strings(zf: zipfile.ZipFile) -> List[str]:
    """Read xl/sharedStrings.xml and return a flat list of string values."""
    if "xl/sharedStrings.xml" not in zf.namelist():
        return []
    sroot = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    return [
        "".join(t.text or "" for t in si.iter(_NS + "t"))
        for si in sroot
    ]


def _read_sheet_order(zf: zipfile.ZipFile) -> List[tuple[str, str]]:
    """Return (sheet_name, zip_member_path) pairs in workbook order.

    Uses xl/workbook.xml + xl/_rels/workbook.xml.rels so that:
    - Sheet names are the human-readable tab names (not "Sheet1")
    - Order matches the tab order the author defined
    - The xl/ prefix is prepended to the relative Target paths in the rels
    """
    wb_xml = zf.read("xl/workbook.xml")
    wb_root = ET.fromstring(wb_xml)

    rels_xml = zf.read("xl/_rels/workbook.xml.rels")
    rels_root = ET.fromstring(rels_xml)
    # Map rId -> target path (relative to xl/)
    rel_map: dict[str, str] = {}
    for rel in rels_root:
        rel_type = rel.get("Type", "")
        if "worksheet" in rel_type:
            rid = rel.get("Id", "")
            target = rel.get("Target", "")
            # Target is relative to xl/, e.g. "worksheets/sheet1.xml"
            rel_map[rid] = "xl/" + target

    sheets_el = wb_root.find(_WB_NS + "sheets")
    if sheets_el is None:
        # Fallback: sort by filename number
        return []

    result: List[tuple[str, str]] = []
    for sh in sheets_el:
        name = sh.get("name", "")
        rid = sh.get(_REL_NS + "id", "")
        member = rel_map.get(rid, "")
        if member and member in zf.namelist():
            result.append((name, member))
    return result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def read_xlsx(path: Union[str, Path]) -> List[List[dict]]:
    """Read an XLSX workbook into a list of sheets.

    Each sheet is a list of header-keyed row dicts (row 0 = headers).
    Sheets are returned in workbook tab order with their human-readable
    names available via ``sheet_name`` metadata embedded in the return
    value (accessible only when using the full parser; ``read_xlsx``
    returns plain lists of dicts).

    Parameters
    ----------
    path:
        File-system path to the ``.xlsx`` file.  The file is opened as a
        binary ZIP — it must *not* be pre-decoded to text.

    Returns
    -------
    list[list[dict]]
        One entry per worksheet.  Each entry is a (possibly empty) list of
        dicts whose keys are the column headers from row 0.  If a sheet has
        no rows (or only a header row with no data), the list is empty.
    """
    path = Path(path)
    with zipfile.ZipFile(path, "r") as zf:
        shared = _read_shared_strings(zf)
        sheet_order = _read_sheet_order(zf)

        if not sheet_order:
            # Fallback: discover sheets by filename pattern, unnamed
            _SHEET_RE = re.compile(r"xl/worksheets/sheet(\d+)\.xml$")
            members = sorted(
                (n for n in zf.namelist() if _SHEET_RE.search(n)),
                key=lambda n: int(_SHEET_RE.search(n).group(1)),  # type: ignore[union-attr]
            )
            sheet_order = [("", m) for m in members]

        sheets: List[List[dict]] = []
        for _name, member in sheet_order:
            try:
                sheet_xml = zf.read(member)
            except KeyError:
                sheets.append([])
                continue

            grid = _parse_sheet_grid(sheet_xml, shared)
            if not grid:
                sheets.append([])
                continue

            headers = grid[0]
            rows: List[dict] = []
            for row in grid[1:]:
                row_dict = {
                    headers[i]: (row[i] if i < len(row) else "")
                    for i in range(len(headers))
                }
                rows.append(row_dict)
            sheets.append(rows)

    return sheets


def read_xlsx_with_names(path: Union[str, Path]) -> List[tuple[str, List[dict]]]:
    """Like ``read_xlsx`` but returns (sheet_name, rows) pairs.

    This is the internal helper used by ``XlsxParser.parse_path``; it is
    exported so callers that need sheet names can use it directly.
    """
    path = Path(path)
    with zipfile.ZipFile(path, "r") as zf:
        shared = _read_shared_strings(zf)
        sheet_order = _read_sheet_order(zf)

        if not sheet_order:
            _SHEET_RE = re.compile(r"xl/worksheets/sheet(\d+)\.xml$")
            members = sorted(
                (n for n in zf.namelist() if _SHEET_RE.search(n)),
                key=lambda n: int(_SHEET_RE.search(n).group(1)),  # type: ignore[union-attr]
            )
            sheet_order = [("", m) for m in members]

        result: List[tuple[str, List[dict]]] = []
        for sheet_name, member in sheet_order:
            try:
                sheet_xml = zf.read(member)
            except KeyError:
                result.append((sheet_name, []))
                continue

            grid = _parse_sheet_grid(sheet_xml, shared)
            if not grid:
                result.append((sheet_name, []))
                continue

            headers = grid[0]
            rows: List[dict] = [
                {
                    headers[i]: (row[i] if i < len(row) else "")
                    for i in range(len(headers))
                }
                for row in grid[1:]
            ]
            result.append((sheet_name, rows))

    return result


# ---------------------------------------------------------------------------
# XlsxParser — BaseODMParser subclass
# ---------------------------------------------------------------------------

class XlsxParser(BaseODMParser):
    """Parser for ``.xlsx`` BOM enum domain-provider workbooks.

    Usage (special-cased by the integrator)
    ----------------------------------------
    Because ``.xlsx`` is a binary ZIP, the standard ``parse_file()`` path
    (which receives decoded text) does not apply.  The integrator detects
    the ``.xlsx`` extension and calls::

        metadata = XlsxParser().parse_path(path)

    instead of the generic ``parse_file()`` call used for text-based ODM
    artifacts.

    ``parse_file()`` still exists (inherited from ``BaseODMParser``) and
    will gracefully handle being called with an empty source string, but it
    will produce an ``OdmFileMetadata`` with empty ``domain_tables``.
    """

    def _get_language_name(self) -> str:
        return "odm_xlsx"

    def raw_token_count_estimator(
        self, metadata: Metadata, tokenizer: Tokenizer, source_code: str
    ) -> int:
        """Estimate token count for xlsx.

        Because the source is binary, ``source_code`` will typically be an
        empty string when called from the base ``parse_file()`` path.  When
        called from ``parse_path()``, we estimate from the serialised headers
        and row counts stored on the domain tables.
        """
        if source_code:
            return tokenizer.count_tokens(source_code)
        if metadata.odm_file_metadata and metadata.odm_file_metadata.domain_tables:
            # Rough estimate: sum of (headers * avg_token_size) * row_count
            total = 0
            for dt in metadata.odm_file_metadata.domain_tables:
                header_tokens = sum(len(h.split()) for h in dt.headers)
                total += header_tokens * max(dt.row_count, 1)
            return total
        return 0

    # ------------------------------------------------------------------
    # Primary entry point for binary xlsx files
    # ------------------------------------------------------------------

    def parse_path(self, path: Union[str, Path]) -> Metadata:
        """Parse an ``.xlsx`` file from disk and return enriched Metadata.

        This is the authoritative entry point for the integrator.  It reads
        the file as bytes (via ``zipfile``), extracts sheet names, headers,
        and row counts, and populates ``metadata.odm_file_metadata`` with
        one ``OdmDomainTable`` per worksheet.

        Parameters
        ----------
        path:
            Absolute or relative file-system path to the ``.xlsx`` file.

        Returns
        -------
        Metadata
            ``metadata.language`` = ``"odm_xlsx"``
            ``metadata.odm_file_metadata.domain_tables`` is a non-empty list
            of ``OdmDomainTable`` objects (one per non-empty sheet).
        """
        path = Path(path)
        metadata = self._create_metadata()  # language = "odm_xlsx"

        try:
            file_bytes = path.read_bytes()
            file_hash = hashlib.sha256(file_bytes).hexdigest()
            file_name = path.name
            relative_path = str(path)

            named_sheets = read_xlsx_with_names(path)

            domain_tables: List[OdmDomainTable] = []
            for sheet_name, rows in named_sheets:
                if not rows:
                    continue
                headers = [str(k) for k in rows[0].keys()]
                domain_tables.append(
                    OdmDomainTable(
                        sheet=sheet_name,
                        headers=headers,
                        row_count=len(rows),
                    )
                )

            odm_file = OdmFile(
                file_hash=file_hash,
                file_name=file_name,
                language="odm_xlsx",
                parsed_date_time=datetime.now(),
            )

            metadata.odm_file_metadata = OdmFileMetadata(
                file=odm_file,
                domain_tables=domain_tables,
                parsed_date_time=datetime.now(),
            )

            # Populate metadata.file via the base helper using a synthetic
            # source string so that relative_path / file_name are recorded.
            synthetic_src = "\n".join(
                dt.sheet + ": " + ", ".join(dt.headers)
                for dt in domain_tables
            )
            metadata.file = self._create_file_metadata(
                source_code=synthetic_src,
                relative_path=relative_path,
                file_name=file_name,
                file_hash=file_hash,
                file_uuid=file_hash[:36],
                charset="binary",
            )

            metadata.raw_token_count = self.raw_token_count_estimator(
                metadata, self.tokenizer, ""
            )
            metadata.input_unit_count = metadata.raw_token_count

        except Exception as exc:
            logger.exception("XlsxParser.parse_path failed for %s", path)
            self._add_processing_error_if_not_duplicate(
                metadata=metadata,
                title=f"XlsxParser error: {type(exc).__name__}",
                detailed=str(exc),
            )

        return metadata
