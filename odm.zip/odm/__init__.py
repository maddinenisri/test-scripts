"""
Standalone ODM Parser package.

Usage:
    from odm import parse_file, Language
    metadata = parse_file("path/to/file.brl")
"""

from .odm_parser import Language, detect_language, get_parser, parse_file, parse_repo
from .models import Metadata, OdmFileMetadata
from .workspace import Workspace, build_workspace
from .operation_trace import (
    DeploymentTrace,
    OperationTrace,
    parse_workspace,
    trace_all_deployments,
    trace_deployment,
    trace_operation,
)

__all__ = [
    "Language",
    "Metadata",
    "OdmFileMetadata",
    "detect_language",
    "get_parser",
    "parse_file",
    "parse_repo",
    # workspace / operation-trace layer
    "Workspace",
    "OperationTrace",
    "DeploymentTrace",
    "build_workspace",
    "parse_workspace",
    "trace_operation",
    "trace_deployment",
    "trace_all_deployments",
]
