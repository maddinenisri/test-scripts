"""
Decision-service Operation (.dop) parser for IBM ODM.

Each .dop file describes a single deployable operation: its name, the ruleflow
it invokes, the target rule project, and its variable signature (IN / OUT).
"""

import logging
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import List, Optional

from ...base_odm_parser import BaseODMParser
from ...models import (
    Metadata,
    OdmFile,
    OdmFileMetadata,
    OdmOperation,
    OdmOperationVariable,
)
from ...utils import Tokenizer
from ...xml_utils import attr, child_text, find_first_el, strip_ns

logger = logging.getLogger(__name__)


def _uuid_of(href: str) -> str:
    """Extract the UUID fragment from an href like 'path/to/file#<uuid>'."""
    if href and "#" in href:
        return href.split("#")[-1]
    return ""


class OperationParser(BaseODMParser):
    """Parses IBM ODM .dop XML files into standard Metadata."""

    def _get_language_name(self) -> str:
        return "odm_operation"

    def raw_token_count_estimator(
        self, metadata: Metadata, tokenizer: Tokenizer, source_code: str
    ) -> int:
        return tokenizer.count_tokens(source_code) * max(len(metadata.odm_file_metadata.operations) if metadata.odm_file_metadata else 0, 1)

    def _extract_odm_metadata(
        self, source_code: str, file_name: str, file_uuid: str
    ) -> Optional[OdmFileMetadata]:
        try:
            root = ET.fromstring(source_code)
        except ET.ParseError as exc:
            logger.warning("OperationParser: XML parse error — %s", exc)
            return None

        # --- Root-level attributes ---
        ruleset_name = attr(root, "rulesetName") or ""
        ruleflow_name = attr(root, "ruleflowName") or ""
        target_project_name = attr(root, "targetRuleProjectName") or ""

        # --- Direct child elements ---
        name_el = find_first_el(root, "name")
        name = (name_el.text.strip() if name_el is not None and name_el.text else "") or ""

        uuid_el = find_first_el(root, "uuid")
        studio_uuid: Optional[str] = (
            uuid_el.text.strip() if uuid_el is not None and uuid_el.text else None
        )

        desc_el = find_first_el(root, "description")
        description: Optional[str] = None
        if desc_el is not None:
            raw = (desc_el.text or "").strip()
            description = raw or None

        # --- referencedVariables ---
        variables: List[OdmOperationVariable] = []
        for child in root:
            if strip_ns(child.tag) == "referencedVariables":
                var_name = attr(child, "variableName") or ""
                set_name = attr(child, "variableSetName") or ""
                direction = attr(child, "direction") or "IN"
                # Locate the nested <variableSet href="...">
                var_set_href = ""
                for nested in child:
                    if strip_ns(nested.tag) == "variableSet":
                        var_set_href = attr(nested, "href") or ""
                        break
                var_set_uuid = _uuid_of(var_set_href) or None
                variables.append(
                    OdmOperationVariable(
                        name=var_name,
                        set_name=set_name,
                        direction=direction,
                        var_set_uuid=var_set_uuid,
                    )
                )

        # --- <ruleflow href="..."> ---
        ruleflow_uuid: Optional[str] = None
        ruleflow_el = find_first_el(root, "ruleflow")
        if ruleflow_el is not None:
            href = attr(ruleflow_el, "href") or ""
            ruleflow_uuid = _uuid_of(href) or None

        # --- <targetRuleProject href="..."> ---
        target_project_uuid: Optional[str] = None
        trp_el = find_first_el(root, "targetRuleProject")
        if trp_el is not None:
            href = attr(trp_el, "href") or ""
            target_project_uuid = _uuid_of(href) or None

        operation = OdmOperation(
            name=name,
            studio_uuid=studio_uuid,
            ruleset_name=ruleset_name,
            ruleflow_name=ruleflow_name,
            ruleflow_uuid=ruleflow_uuid,
            target_project_name=target_project_name,
            target_project_uuid=target_project_uuid,
            description=description,
            variables=variables,
        )

        return OdmFileMetadata(
            file=OdmFile(
                key=file_uuid,
                file_name=file_name,
                language="odm_operation",
                parsed_date_time=datetime.now(),
                studio_uuid=studio_uuid,
            ),
            operations=[operation],
            parsed_date_time=datetime.now(),
        )
