"""Map ODM XML elements and text fragments to source line/column spans."""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import List, Optional, Union

from .xml_utils import strip_ns

XmlElement = Union[ET.Element, object]


@dataclass(frozen=True)
class SourceSpan:
    start_line: int
    start_column: int
    end_line: int
    end_column: int

    @staticmethod
    def whole_file(source: str) -> "SourceSpan":
        end_line = max(source.count("\n") + 1, 1)
        last_line = source[source.rfind("\n") + 1 :]
        end_col = max(len(last_line), 1)
        return SourceSpan(1, 1, end_line, end_col)

    @staticmethod
    def single_line(line: int, start_col: int = 1, end_col: int = 1) -> "SourceSpan":
        return SourceSpan(line, start_col, line, end_col)


def parse_xml_root(source: str):
    """Parse XML; prefer lxml for element.sourceline when available."""
    try:
        from lxml import etree

        parser = etree.XMLParser(recover=True)
        return etree.fromstring(source.encode("utf-8"), parser=parser)
    except Exception:
        return ET.fromstring(source)


def offset_to_line_col(source: str, offset: int) -> tuple[int, int]:
    if offset <= 0:
        return 1, 1
    line = source.count("\n", 0, offset) + 1
    line_start = source.rfind("\n", 0, offset)
    col = offset + 1 if line_start < 0 else offset - line_start
    return line, col


def offset_at_line(source: str, line: int) -> int:
    if line <= 1:
        return 0
    offset = 0
    for _ in range(line - 1):
        nl = source.find("\n", offset)
        if nl < 0:
            return len(source)
        offset = nl + 1
    return offset


def span_from_offsets(source: str, start: int, end: int) -> SourceSpan:
    end = max(start, end)
    sl, sc = offset_to_line_col(source, start)
    el, ec = offset_to_line_col(source, max(start, end - 1))
    return SourceSpan(sl, sc, el, ec)


def element_span(source: str, el: XmlElement) -> SourceSpan:
    """Best-effort span for an XML element in the original source text."""
    sourceline = getattr(el, "sourceline", None)
    if not sourceline:
        return _element_span_by_search(source, el)

    start_line = int(sourceline)
    start_off = offset_at_line(source, start_line)
    line_end = source.find("\n", start_off)
    if line_end < 0:
        line_end = len(source)
    line_slice = source[start_off:line_end]

    tag = strip_ns(el.tag)
    local_tag = tag.split(":")[-1] if ":" in tag else tag
    rel = -1
    for pattern in (f"<{local_tag}", f":{local_tag}"):
        rel = line_slice.find(pattern)
        if rel >= 0:
            break
    if rel < 0:
        rel = line_slice.find("<")
    abs_start = start_off + rel if rel >= 0 else start_off
    start_col = rel + 1 if rel >= 0 else 1

    end_off = _find_element_end_offset(source, el, abs_start, local_tag)
    end_line, end_col = offset_to_line_col(source, max(abs_start, end_off - 1))
    if end_off < len(source) and source[end_off - 1] == "\n":
        end_col = 1
    return SourceSpan(start_line, start_col, end_line, end_col)


def _find_element_end_offset(source: str, el: XmlElement, start_off: int, local_tag: str) -> int:
    if len(el) == 0 and not (el.text and str(el.text).strip()):
        self_close = source.find("/>", start_off)
        if self_close >= 0:
            return self_close + 2

    close = f"</{local_tag}>"
    close_idx = source.find(close, start_off)
    if close_idx >= 0:
        return close_idx + len(close)

    # Leaf element with text — end after text on same or following lines
    if el.text and str(el.text).strip():
        text = str(el.text).strip()
        text_idx = source.find(text, start_off)
        if text_idx >= 0:
            return text_idx + len(text)

    open_end = source.find(">", start_off)
    return open_end + 1 if open_end >= 0 else start_off + 1


def _element_span_by_search(source: str, el: XmlElement) -> SourceSpan:
    tag = strip_ns(el.tag)
    local_tag = tag.split(":")[-1] if ":" in tag else tag

    for attr_name in (
        "Identifier",
        "identifier",
        "Uuid",
        "uuid",
        "DefId",
        "Name",
        "name",
        "Task",
        "Id",
    ):
        val = el.get(attr_name) if hasattr(el, "get") else None
        if val:
            pattern = (
                rf"<(?:[\w.-]+:)?{re.escape(local_tag)}\b"
                rf"[^>]*\b{re.escape(attr_name)}\s*=\s*[\"']{re.escape(val)}[\"']"
            )
            match = re.search(pattern, source)
            if match:
                end_off = _find_element_end_offset(source, el, match.start(), local_tag)
                sl, sc = offset_to_line_col(source, match.start())
                eline, ecol = offset_to_line_col(source, max(match.start(), end_off - 1))
                return SourceSpan(sl, sc, eline, ecol)

    pattern = rf"<(?:[\w.-]+:)?{re.escape(local_tag)}\b"
    match = re.search(pattern, source)
    if match:
        end_off = _find_element_end_offset(source, el, match.start(), local_tag)
        sl, sc = offset_to_line_col(source, match.start())
        eline, ecol = offset_to_line_col(source, max(match.start(), end_off - 1))
        return SourceSpan(sl, sc, eline, ecol)

    return SourceSpan.whole_file(source)


def fragment_span_in_element(
    source: str, parent_el: XmlElement, fragment: str
) -> Optional[SourceSpan]:
    """Locate a text fragment within the parent's source span."""
    if not fragment:
        return None
    parent = element_span(source, parent_el)
    start_off = offset_at_line(source, parent.start_line)
    end_off = offset_at_line(source, parent.end_line + 1)
    region = source[start_off:end_off]
    rel = region.find(fragment)
    if rel < 0:
        return None
    return span_from_offsets(source, start_off + rel, start_off + rel + len(fragment))


def span_enclosing_spans(*spans: SourceSpan) -> SourceSpan:
    if not spans:
        return SourceSpan(1, 1, 1, 1)
    return SourceSpan(
        min(s.start_line for s in spans),
        min(s.start_column for s in spans),
        max(s.end_line for s in spans),
        max(s.end_column for s in spans),
    )


def span_enclosing_elements(source: str, *elements: XmlElement) -> SourceSpan:
    spans: List[SourceSpan] = []
    for el in elements:
        if el is None:
            continue
        if isinstance(el, SourceSpan):
            spans.append(el)
        else:
            spans.append(element_span(source, el))
    if not spans:
        return SourceSpan.whole_file(source)
    return span_enclosing_spans(*spans)


def extract_source_snippet(
    source: str,
    start_line: int,
    start_column: int,
    end_line: int,
    end_column: int,
) -> str:
    """Return the source text for a 1-based line/column span (inclusive)."""
    if not source:
        return source
    lines = source.splitlines(keepends=True)
    if not lines:
        return source

    start_line = max(1, min(int(start_line), len(lines)))
    end_line = max(start_line, min(int(end_line), len(lines)))
    start_column = max(1, int(start_column))
    end_column = max(1, int(end_column))

    if start_line == end_line:
        line = lines[start_line - 1]
        content = line.rstrip("\r\n")
        start_idx = min(start_column - 1, len(content))
        end_idx = min(end_column, len(content))
        if end_idx < start_idx:
            end_idx = len(content)
        return content[start_idx:end_idx]

    first = lines[start_line - 1]
    if start_column > 1:
        first = first[start_column - 1 :]

    last = lines[end_line - 1]
    content_end = last.rstrip("\r\n")
    end_idx = min(end_column, len(content_end))
    last = last[: end_idx + (len(last) - len(content_end))]

    return "".join([first, *lines[start_line : end_line - 1], last])
