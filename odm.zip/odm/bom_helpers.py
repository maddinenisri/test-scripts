"""BOM helper functions for ODM parsers — extracted from bom_dependency_llm.py and bom_type_refs.py."""

from __future__ import annotations

import re
from typing import Iterable, List, Set

from .models import Dependency, Metadata
from .source_positions import parse_xml_root
from .xml_utils import find_first_el, strip_ns

_BOM_TYPED_REF_RE = re.compile(r"<a\s+([A-Za-z_][\w.]*)>", re.IGNORECASE)
_BUILTIN_TYPES = frozenset(
    {
        "string",
        "int",
        "integer",
        "boolean",
        "bool",
        "float",
        "double",
        "date",
        "time",
        "datetime",
        "object",
        "number",
    }
)


def append_bom_dependencies(
    metadata: Metadata,
    packages: Iterable[str],
    *,
    start_line: int = 1,
    start_column: int = 1,
    end_line: int = 1,
    end_column: int = 1,
) -> None:
    """Append unresolved BOM package dependencies to metadata."""
    if metadata.dependencies is None:
        metadata.dependencies = []

    existing = {dep.module_name for dep in metadata.dependencies}
    for pkg in sorted({p.strip() for p in packages if p and p.strip()}):
        if pkg in existing:
            continue
        metadata.dependencies.append(
            Dependency(
                module_name=pkg,
                is_local=True,
                is_wild_card_import=False,
                start_line=start_line,
                start_column=start_column,
                end_line=end_line,
                end_column=end_column,
            )
        )
        existing.add(pkg)


def extract_dta_irl_text_chunks(source_code: str) -> List[str]:
    try:
        root = parse_xml_root(source_code)
    except Exception:
        return []

    chunks: List[str] = []
    for element in root.iter():
        tag = element.tag
        if not isinstance(tag, str):
            tag = str(tag)
        if strip_ns(tag) == "Text" and element.text and element.text.strip():
            chunks.append(element.text.strip())
    return chunks


def _is_bom_qualified_type(qualified: str) -> bool:
    name = (qualified or "").strip()
    if not name or name.lower() in _BUILTIN_TYPES:
        return False
    if "." in name:
        return True
    return bool(re.match(r"^[A-Z]", name))


def extract_bom_qualified_types_from_text(text: str) -> List[str]:
    """Return sorted unique BOM type names from IRL/XML text (`<a pkg.Type>`)."""
    if not text:
        return []
    found: Set[str] = set()
    for match in _BOM_TYPED_REF_RE.finditer(text):
        qualified = match.group(1).strip()
        if _is_bom_qualified_type(qualified):
            found.add(qualified)
    return sorted(found)


def extract_bom_qualified_types_from_dta(source_code: str) -> List[str]:
    """Collect BOM type references from all DTA expression text nodes."""
    chunks = extract_dta_irl_text_chunks(source_code)
    if not chunks:
        return []
    return extract_bom_qualified_types_from_text("\n".join(chunks))


def extract_bom_qualified_types_from_brl(source_code: str) -> List[str]:
    """Collect BOM type references from a BRL file's `<definition>` body."""
    text = source_code
    try:
        root = parse_xml_root(source_code)
        definition_el = find_first_el(root, "definition")
        if definition_el is not None and definition_el.text:
            text = definition_el.text
    except Exception:
        pass
    return extract_bom_qualified_types_from_text(text)
