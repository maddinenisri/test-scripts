"""
Workspace linker — the cross-file layer on top of the per-file ODM parsers.

`build_workspace(root)` discovers every ODM artifact under a directory tree, parses
each with the existing parsers, and builds the UUID/name indexes needed to answer
cross-file questions — most importantly **"what actually runs when operation X is
called?"** It also fills the cross-reference keys the per-file parsers deliberately
leave empty (`OdmOperation.ruleflow_key`, `SubFlowCall.key`, `OdmBrlRule.bom_type_keys`).

Resolution mirrors IBM ODM's own semantics:
- cross-references are matched on the UUID fragment of `path#uuid` hrefs (path is
  advisory), so file moves never break resolution;
- rule packages are directory-based; a Rule task that selects a package by *name*
  runs every rule under that package directory, searching the task's own project
  first, then its declared dependency projects in order.
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

from . import discovery
from .models import (
    Metadata,
    OdmDeployment,
    OdmFlow,
    OdmOperation,
    OdmRuleProject,
)
from .odm_parser import detect_language, parse_file

logger = logging.getLogger(__name__)

# Languages that contribute an individually-addressable rule (uuid -> file).
_RULE_LANGUAGES = {"odm_brl", "odm_trl", "odm_dta", "odm_fct"}


@dataclass
class WorkspaceFile:
    """One parsed ODM artifact plus its on-disk project/package context."""

    path: Path
    rel_path: str
    language: str
    project_dir: Optional[Path]
    package_dir: Optional[Path]
    metadata: Metadata

    @property
    def key(self) -> str:
        return self.metadata.file.key if self.metadata.file else ""

    def rule_records(self) -> List[Tuple[str, Optional[str], str]]:
        """Return (name, studio_uuid, kind) for each rule/table this file defines."""
        ofm = self.metadata.odm_file_metadata
        out: List[Tuple[str, Optional[str], str]] = []
        if not ofm:
            return out
        for r in ofm.rules:
            kind = {
                "odm_brl": "ActionRule",
                "odm_trl": "TechnicalRule",
                "odm_fct": "Function",
            }.get(self.language, "Rule")
            out.append((r.name, r.studio_uuid, kind))
        for t in ofm.decision_tables:
            out.append((t.name, t.studio_uuid, "DecisionTable"))
        return out


@dataclass
class Workspace:
    root: Path
    files: List[WorkspaceFile] = field(default_factory=list)
    projects: List[Path] = field(default_factory=list)

    rules_by_uuid: Dict[str, WorkspaceFile] = field(default_factory=dict)
    flows_by_uuid: Dict[str, Tuple[WorkspaceFile, OdmFlow]] = field(default_factory=dict)
    operations: List[Tuple[WorkspaceFile, OdmOperation]] = field(default_factory=list)
    operations_by_uuid: Dict[str, Tuple[WorkspaceFile, OdmOperation]] = field(default_factory=dict)
    deployments: List[Tuple[WorkspaceFile, OdmDeployment]] = field(default_factory=list)
    projects_by_uuid: Dict[str, Path] = field(default_factory=dict)
    project_meta_by_dir: Dict[Path, OdmRuleProject] = field(default_factory=dict)
    package_dirs: List[Path] = field(default_factory=list)
    # package dir -> set of dotted qualified-name candidates (suffixes of its path
    # below the project root, lowercased), e.g. {"6_1_risk_assessment",
    # "6_verification.6_1_risk_assessment"} — how ODM ruleflows name nested packages.
    package_qnames: Dict[Path, "object"] = field(default_factory=dict)
    bom_type_keys_by_qname: Dict[str, str] = field(default_factory=dict)
    # BOM field-level schema: qualified name -> (kind, extends, [(field_name, field_type)])
    bom_fields_by_qname: Dict[str, "object"] = field(default_factory=dict)
    # enum/domain qualified name -> [{value, title, description, summary}], joined
    # with the resources/*.xlsx domain providers (keyed by TAG/VALUE/NAME).
    bom_enums_by_qname: Dict[str, "object"] = field(default_factory=dict)
    # variable-set uuid -> {technical name -> OdmVariable}; plus a global by-name fallback
    variables_by_set: Dict[str, Dict[str, "object"]] = field(default_factory=dict)
    variable_sets_by_uuid: Dict[str, Tuple[WorkspaceFile, "object"]] = field(default_factory=dict)
    variables_by_name: Dict[str, "object"] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)

    def variable_info(self, var_set_uuid: Optional[str], name: str):
        """Resolve a variable to its OdmVariable (type+verbalization), set first then global."""
        if var_set_uuid and var_set_uuid in self.variables_by_set:
            v = self.variables_by_set[var_set_uuid].get(name)
            if v is not None:
                return v
        return self.variables_by_name.get(name)

    # ----- resolution helpers -----

    def dependency_dirs(self, project_dir: Optional[Path]) -> List[Path]:
        """Resolved dependency project directories, in declared order."""
        if project_dir is None:
            return []
        meta = self.project_meta_by_dir.get(project_dir)
        if not meta:
            return []
        dirs: List[Path] = []
        for dep in meta.dependencies:
            if dep.project_uuid and dep.project_uuid in self.projects_by_uuid:
                dirs.append(self.projects_by_uuid[dep.project_uuid])
        return dirs

    def rules_under(self, directory: Path) -> List[WorkspaceFile]:
        d = directory.resolve()
        out = []
        for wf in self.files:
            if wf.language not in _RULE_LANGUAGES:
                continue
            try:
                wf.path.resolve().relative_to(d)
            except ValueError:
                continue
            out.append(wf)
        return sorted(out, key=lambda w: w.rel_path)

    def resolve_package(
        self, project_dir: Optional[Path], package_name: str
    ) -> Tuple[List[WorkspaceFile], bool]:
        """Resolve a `<Package Name=..>` ref to its rule files.

        ODM names a nested package by its dotted **qualified path** below the source
        folder, e.g. ``6_verification.6_1_risk_assessment`` for
        ``rules/6_verification/6_1_risk_assessment``. We match on that qualified
        name (so repeated leaf names under different parents stay distinct), collect
        rules recursively (selecting a parent package includes its sub-packages),
        and fall back to a basename match for simple un-nested names.

        Searches the task's own project first, then its dependency projects in
        declared order. Returns (rules, resolved?). A package that exists but holds
        no rules still resolves (to an empty list) — it is not "unresolved".
        """
        name = (package_name or "").strip()
        if not name:
            return [], False
        req = name.lower().replace("/", ".").replace("\\", ".")
        variants = {req, req.replace(" ", "_"), req.replace("_", " ")}
        last = req.split(".")[-1]
        basenames = {last, last.replace(" ", "_"), last.replace("_", " ")}

        search_roots: List[Path] = []
        if project_dir is not None:
            search_roots.append(project_dir)
        search_roots.extend(self.dependency_dirs(project_dir))
        search_roots.extend(p for p in self.projects if p not in search_roots)
        if not search_roots:
            search_roots = sorted({d.parent for d in self.package_dirs})  # marker-less fallback

        for use_qualified in (True, False):
            for root in search_roots:
                root_res = root.resolve()
                if use_qualified:
                    matches = [
                        d for d in self.package_dirs
                        if _is_under(d, root_res)
                        and (self.package_qnames.get(d, set()) & variants)
                    ]
                else:  # fallback: match the leaf folder basename (simple un-nested refs)
                    matches = [
                        d for d in self.package_dirs
                        if _is_under(d, root_res) and d.name.lower() in basenames
                    ]
                if not matches:
                    continue
                rules: List[WorkspaceFile] = []
                seen = set()
                for d in matches:
                    for r in self.rules_under(d):
                        if r.key not in seen:
                            seen.add(r.key)
                            rules.append(r)
                return rules, True
        return [], False


def _is_under(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent)
        return True
    except ValueError:
        return False


_TITLE_NON_LABEL = {"int", "string", "boolean", "double", "object", "float", "long", "short"}


def _strip_html(text: str) -> str:
    return re.sub(r"<[^>]+>", "", text or "").replace("&nbsp;", " ").strip()


def _title_from_dtype(dtype: str):
    """Extract an embedded label, e.g. 'Classic Rule Engine-enum-value' -> the title."""
    if dtype and dtype.endswith("-enum-value"):
        prefix = dtype[: -len("-enum-value")].strip()
        if prefix and prefix.lower() not in _TITLE_NON_LABEL and not prefix.endswith("[]"):
            return prefix
    return None


def _build_domain_info(ws: Workspace) -> None:
    """Join enum/domain BOM types to their resources/*.xlsx values + descriptions.

    Builds a global value index from every .xlsx (keyed by TAG / VALUE / NAME) and,
    for each enum/domain BOM type, records its values with title/description/summary
    so the requirements docs can list "allowed values and what each means".
    """
    from .xlsx.core.parser import read_xlsx  # local import: optional binary reader

    value_info: Dict[str, dict] = {}
    for wf in ws.files:
        if wf.language != "odm_xlsx":
            continue
        try:
            sheets = read_xlsx(wf.path)
        except Exception as exc:  # never let a bad workbook abort linking
            logger.warning("xlsx read failed for %s: %s", wf.path, exc)
            continue
        for sheet in sheets:
            for row in sheet:
                key = row.get("TAG") or row.get("VALUE") or row.get("NAME")
                if key:
                    value_info.setdefault(str(key).strip(), row)

    for wf in ws.files:
        ofm = wf.metadata.odm_file_metadata
        if not ofm:
            continue
        for bt in ofm.bom_types:
            d = bt.details
            if d.kind not in ("enumeration", "domain"):
                continue
            values = ws.bom_enums_by_qname.setdefault(d.qualified_name, [])
            seen = {v["value"] for v in values}
            for m in d.members:
                if m.role not in ("enum_value", "domain_static") or m.name in seen:
                    continue
                seen.add(m.name)
                row = value_info.get(m.name, {})
                title = _strip_html(row.get("TITLE", "") or row.get("LABEL", "")) or _title_from_dtype(m.data_type) or ""
                values.append({
                    "value": m.name,
                    "title": title,
                    "description": _strip_html(row.get("DESCRIPTION", "")),
                    "summary": _strip_html(row.get("SUMMARY", "")),
                })
    # drop enums that produced no values
    ws.bom_enums_by_qname = {k: v for k, v in ws.bom_enums_by_qname.items() if v}


def _index_packages(ws: Workspace) -> None:
    """Compute the dotted qualified-name candidates for every package directory.

    For ``rules/6_verification/6_1_risk_assessment`` (relative to its project) we
    record every dotted suffix — ``6_verification.6_1_risk_assessment`` (the form
    ODM ruleflows use), ``6_1_risk_assessment`` (basename), and the source-folder
    prefixed form — plus space/underscore variants, so a `<Package Name>` reference
    matches regardless of how deeply it is qualified.
    """
    for d in ws.package_dirs:
        proj = discovery.project_for(d, ws.projects)
        try:
            parts = list(d.resolve().relative_to(proj.resolve()).parts) if proj else [d.name]
        except ValueError:
            parts = [d.name]
        # Canonical qualified names: the source-folder-relative dotted path (drop the
        # leading source folder, e.g. "rules") AND the full path. NOT bare
        # intermediate leaves — so nested packages match exactly and repeated leaf
        # names under different parents stay distinct.
        cands = {".".join(parts).lower()}
        if len(parts) >= 2:
            cands.add(".".join(parts[1:]).lower())
        for c in list(cands):
            cands.add(c.replace(" ", "_"))
            cands.add(c.replace("_", " "))
        ws.package_qnames[d] = cands


def build_workspace(root: Union[str, Path]) -> Workspace:
    """Discover, parse, and link every ODM artifact under `root`."""
    root = Path(root).resolve()
    ws = Workspace(root=root)
    logger.info("Discovering ODM projects/files under %s ...", root)
    ws.projects = discovery.find_projects(root)
    ws.package_dirs = [m.parent.resolve() for m in root.rglob(".rulepackage") if ".git" not in m.parts]
    _index_packages(ws)

    files = discovery.find_odm_files(root)
    total = len(files)
    logger.info("Discovered %d ODM file(s) in %d project(s); parsing...", total, len(ws.projects))
    for i, path in enumerate(files, 1):
        lang = detect_language(path)
        if lang is None:
            continue
        # logged BEFORE parsing, so if it ever truly hangs the last line names the file
        logger.debug("[%d/%d] parsing %s", i, total, path.relative_to(root))
        t0 = time.perf_counter()
        try:
            md = parse_file(path)
        except Exception as exc:  # never let one bad file abort the workspace
            ws.warnings.append(f"parse failed: {path.relative_to(root)}: {type(exc).__name__}: {exc}")
            logger.warning("parse failed for %s: %s", path, exc)
            continue
        dt = time.perf_counter() - t0
        if dt > 2.0:
            logger.warning("slow parse: %s took %.1fs", path.relative_to(root), dt)
        if i % 50 == 0 or i == total:
            logger.info("  ...parsed %d/%d files", i, total)
        wf = WorkspaceFile(
            path=path,
            rel_path=str(path.relative_to(root)),
            language=lang.value,
            project_dir=discovery.project_for(path, ws.projects),
            package_dir=discovery.package_dir_for(path),
            metadata=md,
        )
        ws.files.append(wf)

    logger.info("Linking %d parsed file(s) (building UUID indexes)...", len(ws.files))
    _build_indexes(ws)
    _build_domain_info(ws)
    _fill_keys(ws)
    logger.info(
        "Linked: %d rule(s), %d flow(s), %d operation(s), %d deployment(s), %d enum domain(s)",
        len(ws.rules_by_uuid), len(ws.flows_by_uuid), len(ws.operations),
        len(ws.deployments), len(ws.bom_enums_by_qname),
    )
    return ws


def _build_indexes(ws: Workspace) -> None:
    for wf in ws.files:
        ofm = wf.metadata.odm_file_metadata
        if not ofm:
            continue

        for name, su, _kind in wf.rule_records():
            if su:
                ws.rules_by_uuid.setdefault(su, wf)

        for flow in ofm.flows:
            if flow.studio_uuid:
                ws.flows_by_uuid.setdefault(flow.studio_uuid, (wf, flow))

        for op in ofm.operations:
            ws.operations.append((wf, op))
            if op.studio_uuid:
                ws.operations_by_uuid[op.studio_uuid] = (wf, op)

        for dep in ofm.deployments:
            ws.deployments.append((wf, dep))

        if ofm.rule_project and wf.project_dir is not None:
            ws.project_meta_by_dir[wf.project_dir.resolve()] = ofm.rule_project
            if ofm.rule_project.studio_uuid:
                ws.projects_by_uuid[ofm.rule_project.studio_uuid] = wf.project_dir.resolve()

        ifaces_by_key = {i.key: i for i in wf.metadata.interfaces}
        for bt in ofm.bom_types:
            qn = bt.details.qualified_name
            if not qn:
                continue
            ws.bom_type_keys_by_qname.setdefault(qn, bt.interface_key or wf.key)
            iface = ifaces_by_key.get(bt.interface_key)
            if iface and iface.attributes:
                entry = ws.bom_fields_by_qname.setdefault(
                    qn, {"kind": bt.details.kind, "extends": list(bt.details.extends), "fields": []}
                )
                seen = {f[0] for f in entry["fields"]}
                for a in iface.attributes:
                    if a.name not in seen:
                        seen.add(a.name)
                        entry["fields"].append((a.name, a.type or "Object"))

        if ofm.variable_set:
            by_name = {v.name: v for v in ofm.variable_set.variables}
            if ofm.variable_set.studio_uuid:
                ws.variables_by_set[ofm.variable_set.studio_uuid] = by_name
                ws.variable_sets_by_uuid[ofm.variable_set.studio_uuid] = (wf, ofm.variable_set)
            for v in ofm.variable_set.variables:
                ws.variables_by_name.setdefault(v.name, v)


def _fill_keys(ws: Workspace) -> None:
    """Fill cross-reference keys the per-file parsers leave empty."""
    # operations -> ruleflow / target project
    for wf, op in ws.operations:
        if op.ruleflow_uuid and op.ruleflow_uuid in ws.flows_by_uuid:
            op.ruleflow_key = ws.flows_by_uuid[op.ruleflow_uuid][0].key
        if op.target_project_uuid and op.target_project_uuid in ws.projects_by_uuid:
            op.target_project_key = str(ws.projects_by_uuid[op.target_project_uuid])

    # ruleflow subflow calls + BOM type refs on rules
    for wf in ws.files:
        ofm = wf.metadata.odm_file_metadata
        if not ofm:
            continue
        for flow in ofm.flows:
            for step in flow.steps:
                if step.studio_uuid and step.studio_uuid in ws.flows_by_uuid:
                    target = ws.flows_by_uuid[step.studio_uuid][0]
                    step.sub_flow_key = target.key
                    if step.sub_flow_call is not None:
                        step.sub_flow_call.key = target.key
        for rule in ofm.rules:
            rule.bom_type_keys = [
                ws.bom_type_keys_by_qname[q]
                for q in rule.bom_type_refs
                if q in ws.bom_type_keys_by_qname
            ]
        for tbl in ofm.decision_tables:
            tbl.bom_type_keys = [
                ws.bom_type_keys_by_qname[q]
                for q in tbl.bom_type_refs
                if q in ws.bom_type_keys_by_qname
            ]
