"""
QueryParser — parses IBM ODM .qry (ruleset query) XML files.

Each .qry file is a single Query artifact in IBM ODM Studio XML format.
The XML structure is:
  <ilog.rules.studio.model.query:Query ...>
    <name>...</name>
    <uuid>...</uuid>
    <definition><![CDATA[...]]></definition>
    <locale>...</locale>
  </ilog.rules.studio.model.query:Query>
"""

import logging
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from typing import Optional

from ...models import (
    Metadata,
    OdmFile,
    OdmFileMetadata,
    OdmQuery,
)
from ...utils import Tokenizer
from ...base_odm_parser import BaseODMParser
from ...xml_utils import (
    extract_studio_uuid,
    find_first_el,
)

logger = logging.getLogger(__name__)


def _parse_xml_root(source_code: str) -> ET.Element:
    return ET.fromstring(source_code)


class QueryParser(BaseODMParser):
    """Parses IBM ODM .qry XML files into standard Metadata."""

    def _get_language_name(self) -> str:
        return "odm_query"

    def raw_token_count_estimator(
        self, metadata: Metadata, tokenizer: Tokenizer, source_code: str
    ) -> int:
        odm = metadata.odm_file_metadata
        count = len(odm.queries) if odm and odm.queries else 1
        return tokenizer.count_tokens(source_code) * count

    def _extract_odm_metadata(
        self, source_code: str, file_name: str, file_uuid: str
    ) -> Optional[OdmFileMetadata]:
        try:
            root = _parse_xml_root(source_code)
        except ET.ParseError as exc:
            logger.warning("QueryParser: XML parse error — %s", exc)
            return None

        # Extract name
        name_el = find_first_el(root, "name")
        query_name = (
            name_el.text.strip()
            if name_el is not None and name_el.text and name_el.text.strip()
            else Path(file_name).stem
        )

        # Extract studio UUID from <uuid> element
        studio_uuid = extract_studio_uuid(root)

        # Extract definition body from <definition> element (may be CDATA)
        definition_el = find_first_el(root, "definition")
        definition: Optional[str] = None
        if definition_el is not None:
            raw = (definition_el.text or "").strip()
            definition = raw if raw else None

        return OdmFileMetadata(
            file=OdmFile(
                key=file_uuid,
                file_name=file_name,
                language="odm_query",
                parsed_date_time=datetime.now(),
                studio_uuid=studio_uuid,
            ),
            queries=[
                OdmQuery(
                    name=query_name,
                    studio_uuid=studio_uuid,
                    definition=definition,
                )
            ],
            parsed_date_time=datetime.now(),
        )
