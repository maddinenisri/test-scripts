"""
RuleProject parser for IBM ODM extensionless dotfile `.ruleproject`.

Each `.ruleproject` file is an XML document that declares project identity
(name, studio UUID, build mode) and cross-project BOM/XOM dependencies.
"""

import logging
import urllib.parse
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import List, Optional

from ...models import (
    Metadata,
    OdmFile,
    OdmFileMetadata,
    OdmProjectDependency,
    OdmRuleProject,
)
from ...utils import Tokenizer
from ...base_odm_parser import BaseODMParser
from ...xml_utils import attr, element_text, strip_ns

logger = logging.getLogger(__name__)


def _uuid_of(href: str) -> str:
    """Extract the UUID fragment from an href like 'Foo%20Bar#some-uuid'."""
    return href.split("#")[-1] if "#" in href else ""


def _name_of(href: str) -> str:
    """Extract and URL-decode the path portion of an href (before '#')."""
    path_part = href.split("#")[0] if "#" in href else href
    # Strip any leading path segments — keep only the last segment
    # e.g. '../../../../git/repo/underwriting-bom' -> 'underwriting-bom'
    last_segment = path_part.rstrip("/").split("/")[-1]
    return urllib.parse.unquote(last_segment)


class RuleProjectParser(BaseODMParser):
    """Parses IBM ODM `.ruleproject` XML dotfiles into standard Metadata."""

    def _get_language_name(self) -> str:
        return "odm_ruleproject"

    def raw_token_count_estimator(
        self, metadata: Metadata, tokenizer: Tokenizer, source_code: str
    ) -> int:
        # Mirror BRL pattern: scale by number of logical items.
        # For ruleproject files the single logical item is the project itself;
        # if there are dependencies count them too (min 1 so we always return > 0).
        odm = metadata.odm_file_metadata
        if odm is not None and odm.rule_project is not None:
            n = max(1, 1 + len(odm.rule_project.dependencies))
        else:
            n = 1
        return tokenizer.count_tokens(source_code) * n

    def _extract_odm_metadata(
        self, source_code: str, file_name: str, file_uuid: str
    ) -> Optional[OdmFileMetadata]:
        try:
            root = ET.fromstring(source_code)
        except ET.ParseError as exc:
            logger.warning("RuleProjectParser: XML parse error — %s", exc)
            return None

        # --- name ---
        name_val = element_text(root, "name") or ""

        # --- studio UUID ---
        uuid_el = None
        for child in root:
            if strip_ns(child.tag) == "uuid":
                uuid_el = child
                break
        studio_uuid: Optional[str] = None
        if uuid_el is not None:
            studio_uuid = (uuid_el.text or "").strip() or None

        # --- buildMode attribute (namespace-qualified or plain) ---
        build_mode: Optional[str] = (
            root.get("buildMode") or attr(root, "buildMode") or None
        )

        # --- dependencies: find all <ruleProject href=...> anywhere in the tree ---
        seen_uuids: set = set()
        deps: List[OdmProjectDependency] = []

        for el in root.iter():
            if strip_ns(el.tag) == "ruleProject":
                href = el.get("href", "").strip()
                if not href:
                    continue
                proj_uuid = _uuid_of(href)
                # Deduplicate by project_uuid
                if proj_uuid and proj_uuid in seen_uuids:
                    continue
                proj_name = _name_of(href)
                dep = OdmProjectDependency(
                    project_uuid=proj_uuid or None,
                    name=proj_name,
                )
                deps.append(dep)
                if proj_uuid:
                    seen_uuids.add(proj_uuid)

        rule_project = OdmRuleProject(
            name=name_val,
            studio_uuid=studio_uuid,
            build_mode=build_mode,
            dependencies=deps,
        )

        return OdmFileMetadata(
            file=OdmFile(
                key=file_uuid,
                file_name=file_name,
                language="odm_ruleproject",
                parsed_date_time=datetime.now(),
                studio_uuid=studio_uuid,
            ),
            rule_project=rule_project,
            parsed_date_time=datetime.now(),
        )
