"""
Command-line entry point for the ODM workspace tools.

    python -m odm.cli <workspace_root> [-o OUT] [--summary]

Builds the workspace (discover -> parse -> link), resolves every decision-service
operation to "what actually runs", and writes JSON traces to OUT (default: out/).
"""

import argparse
import logging
import sys
from pathlib import Path

from .operation_trace import parse_workspace


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="odm", description="Resolve ODM operations to what runs.")
    p.add_argument("source", type=Path, help="ODM project or workspace root directory")
    p.add_argument("-o", "--out", type=Path, default=Path("out"), help="output directory (default: out/)")
    p.add_argument("--operation", help="only this operation (name substring); sub-flows are included")
    p.add_argument("--ruleflow", help="only operations on this ruleflow (name substring); sub-flows included")
    p.add_argument("--summary", action="store_true", help="print a per-operation summary to stdout")
    p.add_argument("--schema", action="store_true", help="print nested I/O field schemas per operation")
    p.add_argument("--requirements", action="store_true",
                   help="write per-operation requirements Markdown (with rule logic) to <out>/requirements/")
    p.add_argument("--prd", action="store_true",
                   help="write per-operation PRD skeletons ([TOOL] facts + [ANALYST] placeholders) to <out>/prd/")
    p.add_argument("--prompt", action="store_true",
                   help="write per-operation LLM prompt bundles (instructions + grounded facts + JSON) to <out>/prompts/")
    p.add_argument("--sample-input", action="store_true",
                   help="write a representative input-object JSON per operation to <out>/inputs/")
    p.add_argument("--execution-trace", metavar="FILE",
                   help="merge ODM execution traces (fired rules) from FILE into execution-grounded docs in <out>/execution/")
    p.add_argument("--llm", action="store_true",
                   help="generate requirements via a local LLM endpoint -> <out>/llm/<service>.md")
    p.add_argument("--llm-url", help="LLM endpoint base URL (default http://127.0.0.1:9001 / $ODM_PARSER_LLM_URL)")
    p.add_argument("--llm-model", help="model name override (default: let the proxy choose / $ODM_PARSER_LLM_MODEL)")
    p.add_argument("-q", "--quiet", action="store_true", help="suppress progress logging")
    p.add_argument("-v", "--verbose", action="store_true", help="per-file debug logging (names each file as it parses)")
    args = p.parse_args(argv)

    level = logging.WARNING if args.quiet else (logging.DEBUG if args.verbose else logging.INFO)
    logging.basicConfig(level=level, format="%(asctime)s  %(levelname)-7s %(message)s",
                        datefmt="%H:%M:%S", stream=sys.stderr)

    if not args.source.exists():
        print(f"error: source not found: {args.source}", file=sys.stderr)
        return 2

    ws, traces = parse_workspace(args.source, output_dir=args.out,
                                 operation=args.operation, ruleflow=args.ruleflow)
    if (args.operation or args.ruleflow) and not traces:
        print(f"  no operation matched operation={args.operation!r} ruleflow={args.ruleflow!r}",
              file=sys.stderr)
        return 4

    if args.requirements:
        from .generators.requirements import generate_requirements
        generate_requirements(ws, traces, args.out / "requirements")

    if args.prd:
        from .generators.prd import generate_prd
        generate_prd(ws, traces, args.out / "prd")

    if args.prompt:
        from .generators.prompt import generate_prompts
        generate_prompts(ws, traces, args.out / "prompts")

    if args.sample_input:
        from .generators.sample_input import generate_sample_inputs
        generate_sample_inputs(ws, traces, args.out / "inputs")

    if args.execution_trace:
        from .generators.execution_merge import load_trace_records, merge_execution
        merge_execution(ws, traces, load_trace_records(args.execution_trace), args.out / "execution")

    if args.llm:
        from .generators.llm import generate_llm
        try:
            generate_llm(ws, traces, args.out / "llm",
                         base_url=args.llm_url, model=args.llm_model)
        except Exception as exc:
            print(f"  --llm error: {exc}", file=sys.stderr)
            return 3

    print(
        f"Parsed {len(ws.files)} files across {len(ws.projects)} project(s); "
        f"{len(ws.operations)} operation(s), {len(ws.deployments)} deployment(s). "
        f"Wrote traces to {args.out}/"
    )
    unresolved = sum(t.stats.get("unresolved", 0) for t in traces)
    if unresolved:
        print(f"  {unresolved} unresolved reference(s) — see operation_trace.json")
    for w in ws.warnings:
        print(f"  warning: {w}")

    if args.summary:
        for t in traces:
            flow = t.ruleflow.name if t.ruleflow else f"({t.execution_kind})"
            print(f"\n{t.operation}  [{flow}]  -> {t.stats.get('rule_refs', 0)} rule(s)")
            sig = lambda v: f"{v.name}: {v.type or '?'}"
            if t.inputs or t.outputs:
                print(f"  IN ({', '.join(sig(v) for v in t.inputs)})"
                      f" -> OUT ({', '.join(sig(v) for v in t.outputs)})")
            for s in t.steps:
                names = ", ".join(r.name for r in s.rules)
                tail = f" -> {names}" if names else (f" -> subflow {s.subflow.name}" if s.subflow else "")
                print(f"  [{s.order}] {s.kind:8} {s.task}{tail}")

    if args.schema:
        for t in traces:
            print(f"\n=== {t.operation}: I/O schema ===")

            def render(qn, ind, seen):
                s = t.type_schemas.get(qn)
                if not s:
                    return
                if qn in seen:
                    print("  " * ind + f"{qn} (… recursive)")
                    return
                seen = seen | {qn}
                for f in s.fields:
                    coll = "[]" if f.collection else ""
                    print("  " * ind + f"{f.name}: {f.type}{coll}")
                    if f.bom:
                        from .operation_trace import _element_type
                        el, _ = _element_type(f.type)
                        render(el, ind + 1, seen)

            for grp, items in (("IN", t.inputs), ("OUT", t.outputs)):
                for v in items:
                    print(f"  {grp} {v.name}: {v.type}")
                    if v.type in t.type_schemas:
                        render(v.type, 2, set())

    if args.summary:
        from .operation_trace import trace_all_deployments
        dep_traces = trace_all_deployments(ws)
        if dep_traces:
            print("\n" + "=" * 60 + "\nDEPLOYMENTS (RuleApp -> ruleflows -> rules)")
            for d in dep_traces:
                tag = " [production]" if d.production else ""
                print(f"\n{d.ruleapp or d.name}{tag}  "
                      f"-> {d.stats['operations']} op(s), {d.stats['ruleflows']} ruleflow(s), "
                      f"{d.stats['unique_rules']} unique rule(s)")
                for o in d.operations:
                    rf = o.ruleflow or f"({o.execution_kind})"
                    mark = "" if o.resolved else "  [UNRESOLVED]"
                    print(f"  - {o.operation}  [{rf}]  {o.rule_count} rule(s){mark}")
                print(f"    ruleflows: {', '.join(rf.name for rf in d.ruleflows) or '(none)'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
