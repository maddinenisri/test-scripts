"""
Workspace discovery for ODM rule projects.

ODM marks projects and packages with **extensionless dotfiles** (``.ruleproject``,
``.rulepackage``) whose meaning is the full filename, not a suffix. Package
membership is *directory-based*: a ``.rulepackage`` dotfile marks its folder and all
rules beneath it; a project is the directory containing a ``.ruleproject`` dotfile.

This module is the single place that understands that on-disk convention.
"""

import os
from pathlib import Path
from typing import Dict, List, Optional, Union

# Dotfile artifacts whose whole name is the type (no suffix).
DOTFILE_TYPES = {
    ".ruleproject": "ruleproject",
    ".rulepackage": "rulepackage",
}

# Suffix -> logical ODM artifact type. Used for discovery + classification.
SUFFIX_TYPES = {
    ".brl": "brl",
    ".trl": "trl",
    ".dta": "dta",
    ".dmt": "dmt",
    ".rfl": "ruleflow",
    ".bom": "bom",
    ".voc": "voc",
    ".var": "var",
    ".fct": "fct",
    ".dop": "operation",
    ".dep": "deployment",
    ".b2xa": "b2x",
    ".b2x": "b2x",
    ".xlsx": "xlsx",
    ".qry": "query",
    ".irl": "irl",
}


def classify(path: Union[str, Path]) -> Optional[str]:
    """Return the logical ODM artifact type for a path, or None if not an ODM file.

    Handles extensionless dotfiles (``.ruleproject`` / ``.rulepackage``) by full
    name, everything else by lower-cased suffix.
    """
    p = Path(path)
    name = p.name
    if name in DOTFILE_TYPES:
        return DOTFILE_TYPES[name]
    return SUFFIX_TYPES.get(p.suffix.lower())


def is_odm_file(path: Union[str, Path]) -> bool:
    return classify(path) is not None


def find_projects(root: Union[str, Path]) -> List[Path]:
    """Return sorted project directories (each containing a ``.ruleproject``)."""
    root = Path(root)
    projects = set()
    if (root / ".ruleproject").is_file():
        projects.add(root)
    for marker in root.rglob(".ruleproject"):
        if ".git" in marker.parts:
            continue
        projects.add(marker.parent)
    return sorted(projects)


def find_odm_files(root: Union[str, Path]) -> List[Path]:
    """Return all ODM artifact files under root (including dotfile artifacts)."""
    root = Path(root)
    out: List[Path] = []
    for f in root.rglob("*"):
        if not f.is_file():
            continue
        if ".git" in f.parts or "__MACOSX" in f.parts:
            continue
        if is_odm_file(f):
            out.append(f)
    return sorted(out)


def project_for(path: Union[str, Path], projects: List[Path]) -> Optional[Path]:
    """Nearest-ancestor project directory for a file path."""
    p = Path(path).resolve()
    best: Optional[Path] = None
    for proj in projects:
        pr = proj.resolve()
        try:
            p.relative_to(pr)
        except ValueError:
            continue
        if best is None or len(pr.parts) > len(best.resolve().parts):
            best = proj
    return best


def package_dir_for(path: Union[str, Path]) -> Optional[Path]:
    """Nearest-ancestor directory that is a rule package (contains ``.rulepackage``).

    Walks up from the file's own directory; returns the first directory holding a
    ``.rulepackage`` dotfile, or None.
    """
    start = Path(path)
    if start.is_file():
        start = start.parent
    for d in [start, *start.parents]:
        if (d / ".rulepackage").is_file():
            return d
    return None


def package_name_to_dirs(root: Union[str, Path]) -> Dict[str, List[Path]]:
    """Map a dotted/spaced package name to the directories that define it.

    A package's name is the relative path of its ``.rulepackage`` directory under the
    nearest project's source folder, with separators normalised. We index by both the
    directory basename and the full relative segment chain so ruleflow ``Package
    Name`` references (which may be dotted, e.g. ``determination.eligibility``) can be
    matched flexibly by the resolver.
    """
    root = Path(root)
    index: Dict[str, List[Path]] = {}
    for marker in root.rglob(".rulepackage"):
        if ".git" in marker.parts:
            continue
        d = marker.parent
        keys = {d.name, d.name.replace(" ", "_"), d.name.lower()}
        for key in keys:
            index.setdefault(key, []).append(d)
    return index
