"""Standalone utilities for the ODM parser — no external dependencies."""

import uuid

import tiktoken


def consistent_key_uuid(key: str) -> str:
    return str(uuid.uuid5(uuid.NAMESPACE_URL, key.lower()))


class Tokenizer:
    """Minimal tokenizer using tiktoken for token counting."""

    def __init__(self, url: str = "", user_id: str = "", encoding_name: str = "cl100k_base"):
        self.encoding = tiktoken.get_encoding(encoding_name)

    def count_tokens(self, text: str) -> int:
        return len(self.encoding.encode(text))
