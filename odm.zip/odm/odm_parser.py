"""
ODM file processing entry point (standalone — no LLM dependencies).

Provides a Language enum mapping file extensions to parser classes, and a
simple synchronous `parse_file()` function that reads and parses any
supported ODM file type.
"""

import hashlib
import json
import logging
import os
import uuid
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Union

from .models import Metadata
from .base_odm_parser import BaseODMParser
from .bom.core.parser import BOMParser
from .brl.core.parser import BRLParser
from .dmt.core.parser import DMTParser
from .dta.core.parser import DTAParser
from .fct.core.parser import FCTParser
from .ruleflow.core.parser import RuleflowParser
from .rulepackage.core.parser import RulePackageParser
from .trl.core.parser import TRLParser
from .var.core.parser import VarSetParser
from .operation.core.parser import OperationParser
from .deployment.core.parser import DeploymentParser
from .ruleproject.core.parser import RuleProjectParser
from .b2x.core.parser import B2xParser
from .xlsx.core.parser import XlsxParser
from .query.core.parser import QueryParser
from .irl.core.parser import IrlParser


class Language(Enum):
    BRL = "odm_brl"
    DMT = "odm_dmt"
    RULEFLOW = "odm_ruleflow"
    BOM = "odm_bom"
    VAR = "odm_var"
    DTA = "odm_dta"
    RULEPACKAGE = "odm_rulepackage"
    TRL = "odm_trl"
    FCT = "odm_fct"
    OPERATION = "odm_operation"
    DEPLOYMENT = "odm_deployment"
    RULEPROJECT = "odm_ruleproject"
    B2X = "odm_b2x"
    XLSX = "odm_xlsx"
    QUERY = "odm_query"
    IRL = "odm_irl"


_EXTENSION_MAP = {
    ".brl": Language.BRL,
    ".dmt": Language.DMT,
    ".rfl": Language.RULEFLOW,
    ".bom": Language.BOM,
    ".voc": Language.BOM,
    ".var": Language.VAR,
    ".dta": Language.DTA,
    ".rulepackage": Language.RULEPACKAGE,
    ".trl": Language.TRL,
    ".fct": Language.FCT,
    ".dop": Language.OPERATION,
    ".dep": Language.DEPLOYMENT,
    ".b2xa": Language.B2X,
    ".b2x": Language.B2X,
    ".xlsx": Language.XLSX,
    ".qry": Language.QUERY,
    ".irl": Language.IRL,
}

# Extensionless dotfile artifacts (whole filename is the type).
_DOTFILE_MAP = {
    ".ruleproject": Language.RULEPROJECT,
    ".rulepackage": Language.RULEPACKAGE,
}

_PARSER_MAP = {
    Language.BRL: BRLParser,
    Language.DMT: DMTParser,
    Language.RULEFLOW: RuleflowParser,
    Language.BOM: BOMParser,
    Language.VAR: VarSetParser,
    Language.DTA: DTAParser,
    Language.RULEPACKAGE: RulePackageParser,
    Language.TRL: TRLParser,
    Language.FCT: FCTParser,
    Language.OPERATION: OperationParser,
    Language.DEPLOYMENT: DeploymentParser,
    Language.RULEPROJECT: RuleProjectParser,
    Language.B2X: B2xParser,
    Language.XLSX: XlsxParser,
    Language.QUERY: QueryParser,
    Language.IRL: IrlParser,
}

# Languages whose source is binary and must be read from the file path, not text.
_BINARY_LANGUAGES = {Language.XLSX}


def get_parser(language: Language) -> BaseODMParser:
    """Return a fresh parser instance for the given language."""
    cls = _PARSER_MAP[language]
    return cls()


def detect_language(file_path: Union[str, Path]) -> Optional[Language]:
    """Detect the ODM language from a file name. Returns None if unknown.

    Handles extensionless dotfile artifacts (``.ruleproject``/``.rulepackage``) by
    full name, everything else by lower-cased suffix.
    """
    name = Path(file_path).name
    if name in _DOTFILE_MAP:
        return _DOTFILE_MAP[name]
    ext = os.path.splitext(str(file_path))[1].lower()
    return _EXTENSION_MAP.get(ext)


def parse_file(
    file_path: Union[str, Path],
    language: Optional[Language] = None,
    charset: str = "utf-8",
) -> Metadata:
    """
    Parse a single ODM file and return its Metadata.

    Parameters
    ----------
    file_path : path to the ODM source file on disk
    language  : if None, auto-detected from extension
    charset   : file encoding (default utf-8)

    Returns
    -------
    Metadata  : structured parse result (classes, functions, ODM metadata, etc.)
    """
    file_path = Path(file_path)
    if language is None:
        language = detect_language(file_path)
    if language is None:
        raise ValueError(
            f"Cannot detect ODM language for {file_path.name!r}. "
            f"Supported: {', '.join(sorted(_EXTENSION_MAP.keys()) + sorted(_DOTFILE_MAP.keys()))}"
        )

    # Binary artifacts (e.g. .xlsx) cannot be read as text — parse from the path.
    if language in _BINARY_LANGUAGES:
        return XlsxParser().parse_path(file_path)

    source_code = file_path.read_text(encoding=charset)
    file_name = file_path.name
    relative_path = str(file_path)
    file_hash = hashlib.sha256(source_code.encode(charset)).hexdigest()
    file_uuid = str(uuid.uuid5(uuid.NAMESPACE_URL, relative_path.lower()))

    parser = get_parser(language)
    return parser.parse_file(
        relative_path=relative_path,
        file_name=file_name,
        source_code=source_code,
        file_hash=file_hash,
        file_uuid=file_uuid,
        charset=charset,
    )


logger = logging.getLogger(__name__)


def parse_repo(
    repo_path: Union[str, Path],
    output_dir: Optional[Union[str, Path]] = None,
    charset: str = "utf-8",
) -> Dict[str, Metadata]:
    """
    Walk a directory tree, parse every supported ODM file, and save each
    result as a JSON file under output_dir.

    Parameters
    ----------
    repo_path  : root directory to scan for ODM files
    output_dir : where to write JSON metadata files (default: ODMParser/tmp/)
    charset    : file encoding (default utf-8)

    Returns
    -------
    dict mapping relative file path -> Metadata object
    """
    repo_path = Path(repo_path).resolve()
    if output_dir is None:
        output_dir = Path(__file__).resolve().parent.parent / "tmp"
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    from . import discovery

    results: Dict[str, Metadata] = {}
    errors: List[str] = []

    odm_files = discovery.find_odm_files(repo_path)

    logger.info(f"Found {len(odm_files)} ODM files in {repo_path}")

    for file_path in odm_files:
        relative = str(file_path.relative_to(repo_path))
        try:
            metadata = parse_file(file_path, charset=charset)
            results[relative] = metadata

            base, ext = os.path.splitext(relative)
            json_path = output_dir / f"{base}{ext}.redux-meta.json"
            json_path.parent.mkdir(parents=True, exist_ok=True)
            json_path.write_text(
                metadata.model_dump_json(indent=2),
                encoding="utf-8",
            )
        except Exception as exc:
            errors.append(f"{relative}: {type(exc).__name__}: {exc}")
            logger.error(f"Failed to parse {relative}: {exc}")

    summary = {
        "repo_path": str(repo_path),
        "total_files_found": len(odm_files),
        "successfully_parsed": len(results),
        "failed": len(errors),
        "errors": errors,
        "files_parsed": sorted(results.keys()),
    }
    summary_path = output_dir / "_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    logger.info(
        f"Done: {len(results)} parsed, {len(errors)} failed. "
        f"Output in {output_dir}"
    )
    return results
