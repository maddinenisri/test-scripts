"""
Extract an execution-trace record from an ODM HTDS (Decision Server) response.

The HTDS REST runtime, when called with `__TraceFilter__`, returns the decision
output plus a `__decisionTrace__` block listing the rules that fired. This turns one
such response into the `(input_id, operation, fired_rules[], output)` record that
`odm-trace --execution-trace` ingests.

Validated against a real ODM 9.6 `Miniloan_ServiceRuleset` response — see
tests/data/htds-real/ and docs/guide/track-b-execution-trace.md.

CLI (used by scripts/odm_execute.sh): reads the response JSON on stdin.
    python -m odm.htds <input_id> <operation>  < response.json
"""

from __future__ import annotations

import json
import sys
from typing import Union

_TRACE_KEYS = {"rulesfired", "inforulesfired", "executedrules"}
_DROP_KEYS = {"__DecisionID__", "__TraceFilter__", "__decisionTrace__",
              "decisionTrace", "rulesFired", "executionTrace"}


def _props(rule: dict) -> dict:
    """HTDS nests rule metadata as properties.property = [{name,value},...]."""
    p = (rule.get("properties") or {}).get("property")
    return {d.get("name"): d.get("value") for d in p if isinstance(d, dict)} if isinstance(p, list) else {}


def _fired_entry(rule) -> Union[dict, str]:
    if not isinstance(rule, dict):
        return str(rule)
    pr = _props(rule)
    out = {}
    # qualified path (e.g. "eligibility.minimum_income") is the reliable join key
    qual = pr.get("ruleExecutionName") or rule.get("name") or rule.get("ruleName")
    if qual:
        out["path"] = str(qual)
    name = rule.get("businessName") or rule.get("name") or pr.get("ruleExecutionShortName")
    if name:
        out["name"] = str(name)
    uid = pr.get("ilog.rules.teamserver.elementID") or rule.get("id") or rule.get("ruleId") or rule.get("uuid")
    if uid:
        out["uuid"] = str(uid)
    return out or str(rule)


def _each_rule(v):
    """rulesFired is a list, OR {ruleInformation:[...]} (Decision Engine HTDS)."""
    if isinstance(v, list):
        return v
    if isinstance(v, dict):
        ri = v.get("ruleInformation")
        return ri if isinstance(ri, list) else [ri] if isinstance(ri, dict) else []
    return []


def extract_record(resp: dict, input_id: str, operation: str) -> dict:
    """Turn one HTDS response dict into an ingestion record."""
    fired = []

    def walk(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if k.lower() in _TRACE_KEYS:
                    fired.extend(_fired_entry(r) for r in _each_rule(v))
                else:
                    walk(v)
        elif isinstance(o, list):
            for x in o:
                walk(x)

    walk(resp)
    output = {k: v for k, v in resp.items() if k not in _DROP_KEYS}
    return {"input_id": input_id, "operation": operation, "fired_rules": fired, "output": output}


def main(argv=None) -> int:
    argv = argv if argv is not None else sys.argv[1:]
    if len(argv) != 2:
        print("usage: python -m odm.htds <input_id> <operation>  < response.json", file=sys.stderr)
        return 2
    resp = json.load(sys.stdin)
    print(json.dumps(extract_record(resp, argv[0], argv[1]), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
