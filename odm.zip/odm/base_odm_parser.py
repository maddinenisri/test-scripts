"""
Abstract base class for all ODM artifact parsers.

ODM files (.brl, .dmt, .ruleflow, .bom) have no tree-sitter grammar, so this
base uses regex/XML parsing instead.  It mirrors the interface and token-counting
contract of BaseTreeSitterParser in common/base_parser.py so every ODM parser
fits into parse_and_enrich_file() without changes to the pipeline.
"""

import logging
import os
from abc import ABC, abstractmethod
from datetime import datetime
from typing import List, Optional

from .models import (
    Class,
    File,
    FileProcessingError,
    FileProcessingErrorType,
    Function,
    Interface,
    Metadata,
    OdmFileMetadata,
)
from .utils import Tokenizer

logger = logging.getLogger(__name__)


class BaseODMParser(ABC):
    """Shared base for BRLParser, DMTParser, RuleflowParser, and BOMParser."""

    def __init__(self):
        self.tokenizer = Tokenizer()

    @abstractmethod
    def _get_language_name(self) -> str:
        pass

    @abstractmethod
    def raw_token_count_estimator(
        self, metadata: Metadata, tokenizer: Tokenizer, source_code: str
    ) -> int:
        pass

    def _extract_package(self, source_code: str) -> Optional[str]:
        return None

    def _extract_imports(self, source_code: str, metadata: Metadata) -> None:
        pass

    def _extract_functions(self, source_code: str, file_uuid: str) -> List[Function]:
        return []

    def _extract_classes(self, source_code: str, file_uuid: str) -> List[Class]:
        return []

    def _extract_interfaces(self, source_code: str, file_uuid: str) -> List[Interface]:
        return []

    def _extract_db_metadata(
        self,
        source_code: str,
        file_name: str,
        file_hash: str,
        file_uuid: str,
    ):
        return None

    def _extract_odm_metadata(
        self, source_code: str, file_name: str, file_uuid: str
    ) -> Optional[OdmFileMetadata]:
        return None

    def _calculate_input_unit_count(self, tokenizer: Tokenizer, source_code: str) -> int:
        return tokenizer.count_tokens(source_code)

    def _create_metadata(self) -> Metadata:
        return Metadata(language=self._get_language_name())

    def _create_file_metadata(
        self,
        source_code: str,
        relative_path: str,
        file_name: str,
        file_hash: str,
        file_uuid: str,
        charset: str = "utf-8",
        package: Optional[str] = None,
    ) -> File:
        lines = source_code.splitlines()
        line_count = len(lines)
        last_col = len(lines[-1]) if lines else 0
        return File(
            start_line=1,
            start_column=1,
            end_line=max(line_count, 1),
            end_column=last_col,
            file_hash=file_hash,
            language=self._get_language_name(),
            parsed_date_time=datetime.now(),
            key=file_uuid,
            relative_path=relative_path,
            file_name=file_name,
            folder_path=os.path.dirname(relative_path),
            charset=charset,
            package=package,
        )

    def _add_processing_error_if_not_duplicate(
        self,
        metadata: Metadata,
        title: str,
        detailed: str,
        start_line_number: int = -1,
        start_column_number: int = -1,
        end_line_number: int = -1,
        end_column_number: int = -1,
    ) -> None:
        if any(e.title == title for e in metadata.processing_errors):
            return
        metadata.processing_errors.append(
            FileProcessingError(
                title=title,
                detailed=detailed,
                type=FileProcessingErrorType.error,
                start_line_number=start_line_number,
                start_column_number=start_column_number,
                end_line_number=end_line_number,
                end_column_number=end_column_number,
            )
        )

    def parse_file(
        self,
        relative_path: str,
        file_name: str,
        source_code: str,
        file_hash: str,
        file_uuid: str,
        charset: str = "utf-8",
        parser_run_config=None,
        s3_handler=None,
    ) -> Metadata:
        metadata = self._create_metadata()

        try:
            package = self._extract_package(source_code)
            metadata.file = self._create_file_metadata(
                source_code=source_code,
                relative_path=relative_path,
                file_name=file_name,
                file_hash=file_hash,
                file_uuid=file_uuid,
                charset=charset,
                package=package,
            )

            self._extract_imports(source_code, metadata)
            metadata.functions = self._extract_functions(source_code, file_uuid)
            metadata.classes = self._extract_classes(source_code, file_uuid)
            metadata.interfaces = self._extract_interfaces(source_code, file_uuid)

            db_meta = self._extract_db_metadata(source_code, file_name, file_hash, file_uuid)
            if db_meta is not None:
                metadata.db_metadata = db_meta

            odm_meta = self._extract_odm_metadata(source_code, file_name, file_uuid)
            if odm_meta is not None:
                metadata.odm_file_metadata = odm_meta

        except Exception as e:
            logger.exception(f"Error parsing ODM file {relative_path}")
            self._add_processing_error_if_not_duplicate(
                metadata=metadata,
                title=f"Parser error: {type(e).__name__}",
                detailed=str(e),
            )
            if metadata.file is None:
                metadata.file = File(
                    start_line=0,
                    start_column=0,
                    end_line=0,
                    end_column=0,
                    file_hash=file_hash,
                    language=self._get_language_name(),
                    parsed_date_time=datetime.now(),
                    key=file_uuid,
                    relative_path=relative_path,
                    file_name=file_name,
                    folder_path=os.path.dirname(relative_path),
                    charset=charset,
                )

        metadata.raw_token_count = self.raw_token_count_estimator(
            metadata, self.tokenizer, source_code
        )
        metadata.input_unit_count = (
            0
            if metadata.raw_token_count == 0
            else self._calculate_input_unit_count(self.tokenizer, source_code)
        )

        return metadata
