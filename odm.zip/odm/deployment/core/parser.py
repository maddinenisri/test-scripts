"""
Deployment (.dep) parser for IBM ODM RuleApp deployment descriptors.

Each .dep file is an XML document describing a RuleApp deployment:
  - Root element attributes: ruleAppName, production
  - <name> child: human-readable deployment name
  - <uuid> child: ODM Studio UUID
  - <operations operationName="..."> children: operation references
  - <versionPolicies label="..." ruleset="..." default="..."> children

Produces one OdmDeployment per file wrapped in OdmFileMetadata.
"""

import logging
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import List, Optional

from ...models import (
    Metadata,
    OdmDeployment,
    OdmFile,
    OdmFileMetadata,
    OdmOperationRef,
    OdmVersionPolicy,
)
from ...utils import Tokenizer
from ...base_odm_parser import BaseODMParser
from ...xml_utils import strip_ns

logger = logging.getLogger(__name__)


def _uuid_of(href: str) -> str:
    """Extract the fragment UUID from an href like 'foo.dop#some-uuid'."""
    return href.split("#")[-1] if "#" in href else ""


def _parse_dep_xml(source_code: str) -> Optional[ET.Element]:
    """Parse XML source, returning the root element or None on error."""
    try:
        return ET.fromstring(source_code)
    except ET.ParseError as exc:
        logger.warning("DeploymentParser: XML parse error — %s", exc)
        return None


def _extract_operations(root: ET.Element) -> List[OdmOperationRef]:
    """Extract all <operations> elements and their nested <operation href=...>."""
    ops: List[OdmOperationRef] = []
    for child in root:
        if strip_ns(child.tag) != "operations":
            continue
        operation_name = (child.get("operationName") or "").strip()
        # Find the nested <operation href="...">
        operation_uuid: Optional[str] = None
        for sub in child:
            if strip_ns(sub.tag) == "operation":
                href = (sub.get("href") or "").strip()
                if href:
                    operation_uuid = _uuid_of(href)
                break
        ops.append(
            OdmOperationRef(
                operation_name=operation_name,
                operation_uuid=operation_uuid or None,
            )
        )
    return ops


def _extract_version_policies(root: ET.Element) -> List[OdmVersionPolicy]:
    """Extract all <versionPolicies> elements."""
    policies: List[OdmVersionPolicy] = []
    for child in root:
        if strip_ns(child.tag) != "versionPolicies":
            continue
        label = (child.get("label") or "").strip()
        ruleset_raw = (child.get("ruleset") or "").strip()
        default_raw = (child.get("default") or "").strip().lower()
        policies.append(
            OdmVersionPolicy(
                label=label,
                ruleset=ruleset_raw if ruleset_raw else None,
                is_default=(default_raw == "true"),
            )
        )
    return policies


class DeploymentParser(BaseODMParser):
    """Parses IBM ODM .dep RuleApp deployment descriptor XML files."""

    def _get_language_name(self) -> str:
        return "odm_deployment"

    def raw_token_count_estimator(
        self, metadata: Metadata, tokenizer: Tokenizer, source_code: str
    ) -> int:
        # Mirror brl parser: token_count * number of top-level extracted items.
        # For deployment files there is exactly one deployment per file.
        odm_meta = metadata.odm_file_metadata
        item_count = len(odm_meta.deployments) if odm_meta else 0
        if item_count == 0:
            return 0
        return tokenizer.count_tokens(source_code) * item_count

    def _extract_odm_metadata(
        self, source_code: str, file_name: str, file_uuid: str
    ) -> Optional[OdmFileMetadata]:
        root = _parse_dep_xml(source_code)
        if root is None:
            return None

        try:
            # Root-level attributes
            ruleapp_name = (root.get("ruleAppName") or "").strip()
            production_raw = (root.get("production") or "false").strip().lower()
            production = production_raw == "true"

            # <name> and <uuid> direct children
            name: str = ""
            studio_uuid: Optional[str] = None
            for child in root:
                local = strip_ns(child.tag)
                if local == "name" and not name:
                    name = (child.text or "").strip()
                elif local == "uuid" and studio_uuid is None:
                    studio_uuid = (child.text or "").strip() or None

            operations = _extract_operations(root)
            version_policies = _extract_version_policies(root)

            deployment = OdmDeployment(
                name=name or ruleapp_name or file_name,
                studio_uuid=studio_uuid,
                ruleapp_name=ruleapp_name,
                production=production,
                operations=operations,
                version_policies=version_policies,
            )

            odm_file = OdmFile(
                key=file_uuid,
                file_name=file_name,
                language="odm_deployment",
                parsed_date_time=datetime.now(),
                studio_uuid=studio_uuid,
            )

            return OdmFileMetadata(
                file=odm_file,
                deployments=[deployment],
                parsed_date_time=datetime.now(),
            )

        except Exception as exc:
            logger.warning("DeploymentParser: failed to extract metadata — %s", exc)
            return None
