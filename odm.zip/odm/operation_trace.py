"""
Operation resolver — answers "what actually runs when operation X is called?"

`trace_operation` walks a decision-service operation through its ruleflow, in
execution order, resolving each Rule task to the concrete rules that fire (across
project boundaries) and recursively expanding sub-flow calls. The result is a
JSON-serialisable `OperationTrace`.

`parse_workspace(root, out)` builds the workspace and writes one trace per
operation plus an aggregate `operation_trace.json` and `_workspace_summary.json`.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Union

from pydantic import BaseModel, Field

from .models import OdmFlow, OdmOperation
from .workspace import Workspace, WorkspaceFile, build_workspace

logger = logging.getLogger(__name__)


# --- trace output models ---


class ResolvedRuleRef(BaseModel):
    name: str
    uuid: Optional[str] = None
    file: Optional[str] = None
    kind: str = "Rule"
    project: Optional[str] = None
    via: str = "package"  # "package" | "rule_uuid"


class TraceSubflow(BaseModel):
    name: str = ""
    uuid: Optional[str] = None
    file: Optional[str] = None
    resolved: bool = False


class SchemaField(BaseModel):
    name: str
    type: str
    bom: bool = False         # `type`'s element is an expandable BOM type in type_schemas
    collection: bool = False  # `type` is an array/collection of its element type


class EnumValue(BaseModel):
    value: str
    title: Optional[str] = None
    description: Optional[str] = None
    summary: Optional[str] = None


class TypeSchema(BaseModel):
    name: str
    kind: str = "concept"  # concept | enumeration | domain
    extends: List[str] = Field(default_factory=list)
    fields: List[SchemaField] = Field(default_factory=list)
    enum_values: List[EnumValue] = Field(default_factory=list)


class TraceVariable(BaseModel):
    name: str
    type: Optional[str] = None
    verbalization: Optional[str] = None
    initial_value: Optional[str] = None
    set: str = ""
    direction: str = "IN"
    variable_set_uuid: Optional[str] = None
    variable_set_file: Optional[str] = None


class TraceVariableSet(BaseModel):
    name: str = ""
    uuid: Optional[str] = None
    file: Optional[str] = None
    variables: List[TraceVariable] = Field(default_factory=list)


class TraceSourceArtifacts(BaseModel):
    variable_sets: List[str] = Field(default_factory=list)
    bom: List[str] = Field(default_factory=list)
    b2xa: List[str] = Field(default_factory=list)
    voc: List[str] = Field(default_factory=list)
    xom_java: List[str] = Field(default_factory=list)
    xom_libraries: List[str] = Field(default_factory=list)


class UnresolvedRef(BaseModel):
    kind: str  # "ruleflow" | "package" | "rule_uuid" | "subflow"
    value: str
    where: str = ""


class TraceStep(BaseModel):
    task: str
    kind: str  # "Rule" | "Action" | "Subflow" | "Start" | "Stop"
    order: Optional[int] = None
    description: Optional[str] = None
    action_irl: Optional[str] = None
    execution_mode: Optional[str] = None
    ordering: Optional[str] = None
    exit_criteria: Optional[str] = None
    rules: List[ResolvedRuleRef] = Field(default_factory=list)
    subflow: Optional[TraceSubflow] = None
    substeps: List["TraceStep"] = Field(default_factory=list)


class TraceDeploymentRef(BaseModel):
    ruleapp: str = ""
    production: bool = False
    file: Optional[str] = None


class RuleflowRef(BaseModel):
    name: str = ""
    uuid: Optional[str] = None
    file: Optional[str] = None


class OperationTrace(BaseModel):
    operation: str
    uuid: Optional[str] = None
    file: Optional[str] = None
    ruleset_name: str = ""
    target_project: str = ""
    execution_kind: str = "ruleflow"  # "ruleflow" | "query-extractor"
    ruleflow: Optional[RuleflowRef] = None
    inputs: List[TraceVariable] = Field(default_factory=list)
    outputs: List[TraceVariable] = Field(default_factory=list)
    variable_sets: List[TraceVariableSet] = Field(default_factory=list)
    source_artifacts: TraceSourceArtifacts = Field(default_factory=TraceSourceArtifacts)
    type_schemas: Dict[str, TypeSchema] = Field(default_factory=dict)
    steps: List[TraceStep] = Field(default_factory=list)
    deployments: List[TraceDeploymentRef] = Field(default_factory=list)
    unresolved_refs: List[UnresolvedRef] = Field(default_factory=list)
    stats: Dict[str, int] = Field(default_factory=dict)


TraceStep.model_rebuild()


class DeploymentOperationRef(BaseModel):
    """One operation shipped by a deployment, with a compact resolution summary."""

    operation: str
    uuid: Optional[str] = None
    resolved: bool = False
    ruleflow: Optional[str] = None
    execution_kind: str = "ruleflow"
    rule_count: int = 0


class DeploymentTrace(BaseModel):
    """A RuleApp deployment flattened to every ruleflow and rule it ultimately runs."""

    ruleapp: str = ""
    name: str = ""
    production: bool = False
    file: Optional[str] = None
    operations: List[DeploymentOperationRef] = Field(default_factory=list)
    ruleflows: List[RuleflowRef] = Field(default_factory=list)
    rules: List[ResolvedRuleRef] = Field(default_factory=list)
    unresolved_refs: List[UnresolvedRef] = Field(default_factory=list)
    stats: Dict[str, int] = Field(default_factory=dict)


# --- resolver ---


def _ordered_steps(flow: OdmFlow):
    return sorted(
        flow.steps,
        key=lambda s: (s.order if s.order is not None else 1_000_000, s.start_line),
    )


def _element_type(t: str) -> Tuple[str, bool]:
    """Strip array/generic wrappers to a bare element type; flag if it's a collection."""
    t = (t or "").strip()
    collection = False
    if t.endswith("[]"):
        collection, t = True, t[:-2].strip()
    m = re.search(r"<\s*([\w.$]+)\s*>", t)
    if m:
        collection, t = True, m.group(1)
    return t, collection


def build_type_schemas(ws: Workspace, root_types: Set[str]) -> Dict[str, TypeSchema]:
    """Expand BOM parameter types into nested field-level schemas (transitively).

    Returns a registry keyed by qualified type name (like JSON-schema $defs); fields
    whose `bom` flag is set reference another entry, so cycles/shared types stay flat.
    """
    schemas: Dict[str, TypeSchema] = {}
    visited: Set[str] = set()
    queue: List[str] = [t for t in root_types if t]
    while queue:
        bare, _ = _element_type(queue.pop(0))
        if bare in visited:
            continue
        visited.add(bare)

        # enum/domain type -> list its allowed values + descriptions (from xlsx).
        # An enum is an enum even if its values were also captured as pseudo-fields.
        enum_vals = ws.bom_enums_by_qname.get(bare)
        if enum_vals:
            schemas[bare] = TypeSchema(
                name=bare, kind="enumeration",
                enum_values=[EnumValue(**v) for v in enum_vals],
            )
            continue
        info = ws.bom_fields_by_qname.get(bare)
        if not info:
            continue  # primitive / Java / unknown type -> leaf, no schema entry
        fields: List[SchemaField] = []
        for fname, ftype in info["fields"]:
            el, coll = _element_type(ftype)
            is_bom = el in ws.bom_fields_by_qname or el in ws.bom_enums_by_qname
            fields.append(SchemaField(name=fname, type=ftype, bom=is_bom, collection=coll))
            if is_bom and el not in visited:
                queue.append(el)
        schemas[bare] = TypeSchema(
            name=bare, kind=info.get("kind", "concept"),
            extends=list(info.get("extends", [])), fields=fields,
        )
    return schemas


def _project_name(ws: Workspace, wf: Optional[WorkspaceFile]) -> Optional[str]:
    if wf is None or wf.project_dir is None:
        return None
    return wf.project_dir.name


def _artifact_sources(ws: Workspace, op_wf: WorkspaceFile, trace: OperationTrace) -> TraceSourceArtifacts:
    """List source files that explain the operation contract and XOM/BOM types."""
    project_dir = op_wf.project_dir.resolve() if op_wf.project_dir else None

    def in_project(wf: WorkspaceFile) -> bool:
        return project_dir is None or (wf.project_dir and wf.project_dir.resolve() == project_dir)

    artifacts = TraceSourceArtifacts()
    type_prefixes = {((v.type or "").split(".", 1)[0]) for v in trace.inputs + trace.outputs if "." in (v.type or "")}
    for wf in ws.files:
        if not in_project(wf):
            continue
        suffix = Path(wf.rel_path).suffix.lower()
        if suffix == ".var":
            artifacts.variable_sets.append(wf.rel_path)
        elif suffix == ".bom":
            artifacts.bom.append(wf.rel_path)
        elif suffix == ".b2xa":
            artifacts.b2xa.append(wf.rel_path)
        elif suffix == ".voc":
            artifacts.voc.append(wf.rel_path)
    if project_dir:
        java_roots = [project_dir]
        # Common sample/customer layout: <repo>/ruleproject/<Project> plus
        # <repo>/xom/src/main/java. If the workspace root is the rule project,
        # include that adjacent XOM source tree as operation-contract evidence.
        for ancestor in [ws.root, *ws.root.parents[:3]]:
            candidate = ancestor / "xom" / "src" / "main" / "java"
            if candidate.is_dir():
                java_roots.append(candidate)
        for java_root in dict.fromkeys(java_roots):
            for p in sorted(java_root.rglob("*.java")):
                try:
                    rel = p.relative_to(ws.root).as_posix()
                except ValueError:
                    rel = p.as_posix()
                if not type_prefixes or any(f"/{prefix}/" in f"/{rel}" for prefix in type_prefixes):
                    artifacts.xom_java.append(rel)
        for p in sorted((project_dir / "resources" / "xom-libraries").glob("*")):
            if p.is_file():
                try:
                    artifacts.xom_libraries.append(p.relative_to(ws.root).as_posix())
                except ValueError:
                    artifacts.xom_libraries.append(p.as_posix())
    # Stable de-dupe.
    for field in ("variable_sets", "bom", "b2xa", "voc", "xom_java", "xom_libraries"):
        setattr(artifacts, field, sorted(dict.fromkeys(getattr(artifacts, field))))
    return artifacts


def _trace_flow(
    ws: Workspace,
    flow_wf: WorkspaceFile,
    flow: OdmFlow,
    unresolved: List[UnresolvedRef],
    visited: Set[str],
) -> List[TraceStep]:
    steps: List[TraceStep] = []
    for step in _ordered_steps(flow):
        is_subflow = step.step_type == "CALL" or step.sub_flow_call is not None
        is_rule = bool(step.rule_list_entries)

        if is_subflow:
            ts = TraceStep(
                task=step.name, kind="Subflow", order=step.order,
                description=step.condition_desc,
            )
            sub_uuid = step.studio_uuid
            sub = TraceSubflow(
                name=(step.sub_flow_call.name if step.sub_flow_call else step.program_name) or "",
                uuid=sub_uuid,
            )
            if sub_uuid and sub_uuid in ws.flows_by_uuid:
                target_wf, target_flow = ws.flows_by_uuid[sub_uuid]
                sub.file = target_wf.rel_path
                sub.resolved = True
                if not sub.name:
                    sub.name = target_flow.name  # use the resolved flow's real name
                if sub_uuid not in visited:
                    visited.add(sub_uuid)
                    ts.substeps = _trace_flow(ws, target_wf, target_flow, unresolved, visited)
            else:
                unresolved.append(UnresolvedRef(kind="subflow", value=sub_uuid or sub.name or step.name, where=step.name))
            # never leave the sub-flow nameless — fall back to the task identifier
            if not sub.name:
                sub.name = step.name
            ts.subflow = sub
            steps.append(ts)
            continue

        if is_rule:
            ts = TraceStep(
                task=step.name, kind="Rule", order=step.order,
                description=step.condition_desc,
                execution_mode=step.execution_mode, ordering=step.ordering,
                exit_criteria=step.exit_criteria,
            )
            for entry in step.rule_list_entries:
                if entry.rule_uuid:
                    wf = ws.rules_by_uuid.get(entry.rule_uuid)
                    if wf:
                        for name, su, kind in wf.rule_records():
                            if su == entry.rule_uuid or len(wf.rule_records()) == 1:
                                ts.rules.append(ResolvedRuleRef(
                                    name=name, uuid=su, file=wf.rel_path, kind=kind,
                                    project=_project_name(ws, wf), via="rule_uuid"))
                    else:
                        unresolved.append(UnresolvedRef(kind="rule_uuid", value=entry.rule_uuid, where=step.name))
                elif entry.package_name:
                    rules, ok = ws.resolve_package(flow_wf.project_dir, entry.package_name)
                    if ok:
                        for wf in rules:
                            for name, su, kind in wf.rule_records():
                                ts.rules.append(ResolvedRuleRef(
                                    name=name, uuid=su, file=wf.rel_path, kind=kind,
                                    project=_project_name(ws, wf), via="package"))
                    else:
                        unresolved.append(UnresolvedRef(kind="package", value=entry.package_name, where=step.name))
            steps.append(ts)
            continue

        # Action / boundary step
        steps.append(TraceStep(
            task=step.name, kind="Action", order=step.order,
            description=step.condition_desc,
            action_irl=step.initial_actions_irl or step.statement,
        ))
    return steps


def trace_operation(ws: Workspace, op_wf: WorkspaceFile, op: OdmOperation) -> OperationTrace:
    unresolved: List[UnresolvedRef] = []
    trace = OperationTrace(
        operation=op.name, uuid=op.studio_uuid, file=op_wf.rel_path,
        ruleset_name=op.ruleset_name, target_project=op.target_project_name,
    )

    variable_sets: Dict[str, TraceVariableSet] = {}
    for v in op.variables:
        info = ws.variable_info(v.var_set_uuid, v.name)
        vs_file = None
        if v.var_set_uuid and v.var_set_uuid in ws.variable_sets_by_uuid:
            set_wf, set_obj = ws.variable_sets_by_uuid[v.var_set_uuid]
            vs_file = set_wf.rel_path
            variable_sets.setdefault(v.var_set_uuid, TraceVariableSet(
                name=set_obj.name, uuid=set_obj.studio_uuid, file=set_wf.rel_path))
        tv = TraceVariable(
            name=v.name, set=v.set_name, direction=v.direction or "IN",
            type=(info.type if info else None),
            verbalization=(info.verbalization if info else None),
            initial_value=(info.initial_value if info else None),
            variable_set_uuid=v.var_set_uuid,
            variable_set_file=vs_file,
        )
        if v.var_set_uuid and v.var_set_uuid in variable_sets:
            variable_sets[v.var_set_uuid].variables.append(tv)
        if (v.direction or "IN").upper().startswith("OUT") or v.direction == "IN_OUT":
            trace.outputs.append(tv)
        if v.direction != "OUT":
            trace.inputs.append(tv)
    trace.variable_sets = list(variable_sets.values())

    # expand BOM parameter types into nested field-level schemas
    trace.type_schemas = build_type_schemas(
        ws, {v.type for v in trace.inputs + trace.outputs if v.type}
    )
    trace.source_artifacts = _artifact_sources(ws, op_wf, trace)

    flow_entry = ws.flows_by_uuid.get(op.ruleflow_uuid) if op.ruleflow_uuid else None
    if flow_entry is not None:
        flow_wf, flow = flow_entry
        trace.ruleflow = RuleflowRef(name=flow.name, uuid=flow.studio_uuid, file=flow_wf.rel_path)
        visited: Set[str] = {flow.studio_uuid} if flow.studio_uuid else set()
        trace.steps = _trace_flow(ws, flow_wf, flow, unresolved, visited)
    elif op.ruleflow_uuid or op.ruleflow_name:
        # An explicit ruleflow was referenced but could not be found — real gap.
        unresolved.append(UnresolvedRef(kind="ruleflow", value=op.ruleflow_uuid or op.ruleflow_name, where=op.name))
    else:
        # No ruleflow: a query/extractor operation. "What runs" is the rule set of
        # the target project (the query selects from it). Over-approximation noted.
        trace.execution_kind = "query-extractor"
        target_dir = ws.projects_by_uuid.get(op.target_project_uuid or "")
        rules = ws.rules_under(target_dir) if target_dir else []
        step = TraceStep(task="(query extraction)", kind="Rule",
                         description="Rules selected by query extractor from the target project")
        for wf in rules:
            for name, su, kind in wf.rule_records():
                step.rules.append(ResolvedRuleRef(
                    name=name, uuid=su, file=wf.rel_path, kind=kind,
                    project=_project_name(ws, wf), via="query-extractor"))
        # Even with no rule files on disk (incomplete export), keep the synthetic
        # step so the trace transparently shows it's a query-extractor operation
        # whose target project currently contributes N rules.
        trace.steps = [step]

    # deployments that ship this operation
    for dep_wf, dep in ws.deployments:
        for ref in dep.operations:
            if (ref.operation_uuid and ref.operation_uuid == op.studio_uuid) or (
                ref.operation_name and ref.operation_name == op.name
            ):
                trace.deployments.append(TraceDeploymentRef(
                    ruleapp=dep.ruleapp_name, production=dep.production, file=dep_wf.rel_path))

    trace.unresolved_refs = unresolved
    trace.stats = {
        "steps": len(trace.steps),
        "rule_refs": _count_rules(trace.steps),
        "unresolved": len(unresolved),
    }
    return trace


def _count_rules(steps: List[TraceStep]) -> int:
    n = 0
    for s in steps:
        n += len(s.rules)
        n += _count_rules(s.substeps)
    return n


def trace_all(ws: Workspace) -> List[OperationTrace]:
    return [trace_operation(ws, wf, op) for wf, op in ws.operations]


def _flatten_rules(steps: List[TraceStep]) -> List[ResolvedRuleRef]:
    out: List[ResolvedRuleRef] = []
    for s in steps:
        out.extend(s.rules)
        out.extend(_flatten_rules(s.substeps))
    return out


def _dedupe_rules(rules: List[ResolvedRuleRef]) -> List[ResolvedRuleRef]:
    seen: Set[str] = set()
    uniq: List[ResolvedRuleRef] = []
    for r in rules:
        key = r.uuid or f"{r.project}:{r.file}:{r.name}"
        if key not in seen:
            seen.add(key)
            uniq.append(r)
    return uniq


def trace_deployment(ws: Workspace, dep_wf: WorkspaceFile, dep) -> DeploymentTrace:
    """Flatten a deployment (RuleApp) to every ruleflow and rule it ultimately runs."""
    dt = DeploymentTrace(
        ruleapp=dep.ruleapp_name, name=dep.name, production=dep.production,
        file=dep_wf.rel_path,
    )
    unresolved: List[UnresolvedRef] = []
    all_rules: List[ResolvedRuleRef] = []
    flows_seen: Set[str] = set()

    for ref in dep.operations:
        # resolve the operation by UUID first, then by name
        entry = ws.operations_by_uuid.get(ref.operation_uuid or "")
        if entry is None and ref.operation_name:
            entry = next(
                ((wf, op) for wf, op in ws.operations
                 if op.name == ref.operation_name or _slug(op.name) == _slug(ref.operation_name)),
                None,
            )
        if entry is None:
            unresolved.append(UnresolvedRef(
                kind="operation", value=ref.operation_uuid or ref.operation_name, where=dep.name))
            dt.operations.append(DeploymentOperationRef(
                operation=ref.operation_name or "(unknown)", uuid=ref.operation_uuid, resolved=False))
            continue

        op_wf, op = entry
        ot = trace_operation(ws, op_wf, op)
        op_rules = _flatten_rules(ot.steps)
        all_rules.extend(op_rules)
        unresolved.extend(ot.unresolved_refs)

        if ot.ruleflow and (ot.ruleflow.uuid or ot.ruleflow.name) not in flows_seen:
            flows_seen.add(ot.ruleflow.uuid or ot.ruleflow.name)
            dt.ruleflows.append(ot.ruleflow)

        dt.operations.append(DeploymentOperationRef(
            operation=op.name, uuid=op.studio_uuid, resolved=True,
            ruleflow=ot.ruleflow.name if ot.ruleflow else None,
            execution_kind=ot.execution_kind, rule_count=len(op_rules)))

    dt.rules = _dedupe_rules(all_rules)
    dt.unresolved_refs = unresolved
    dt.stats = {
        "operations": len(dt.operations),
        "ruleflows": len(dt.ruleflows),
        "unique_rules": len(dt.rules),
        "unresolved": len(unresolved),
    }
    return dt


def trace_all_deployments(ws: Workspace) -> List[DeploymentTrace]:
    return [trace_deployment(ws, wf, dep) for wf, dep in ws.deployments]


def _slug(name: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in name).strip("_").lower() or "operation"


def assign_unique_slugs(traces: List[OperationTrace]) -> List[Tuple[OperationTrace, str]]:
    """Map each operation trace to a unique filename slug.

    Different projects can ship operations with the SAME name (e.g. bundled app
    copies); disambiguate by appending the target project, then a counter, so their
    per-operation files don't overwrite each other.
    """
    used: Dict[str, int] = {}
    out: List[Tuple[OperationTrace, str]] = []
    for t in traces:
        base = _slug(t.operation)
        slug = base
        if slug in used and t.target_project:
            slug = f"{base}__{_slug(t.target_project)}"
        n = 1
        while slug in used:
            n += 1
            slug = f"{base}-{n}"
        used[slug] = 1
        out.append((t, slug))
    return out


def _matches(trace: OperationTrace, operation: Optional[str], ruleflow: Optional[str]) -> bool:
    if operation and operation.lower() not in trace.operation.lower():
        return False
    if ruleflow:
        rf = trace.ruleflow.name if trace.ruleflow else ""
        if ruleflow.lower() not in rf.lower():
            return False
    return True


def parse_workspace(
    root: Union[str, Path], output_dir: Optional[Union[str, Path]] = None,
    operation: Optional[str] = None, ruleflow: Optional[str] = None,
) -> Tuple[Workspace, List[OperationTrace]]:
    """Build the workspace and (optionally) write operation traces to disk.

    If `operation` or `ruleflow` is given, only the matching operation(s) are traced/
    written (sub-flows are always included, as they expand within the operation).
    """
    ws = build_workspace(root)
    logger.info("Tracing %d operation(s)...", len(ws.operations))
    traces = trace_all(ws)
    if operation or ruleflow:
        traces = [t for t in traces if _matches(t, operation, ruleflow)]
        logger.info("Filtered to %d operation(s) matching operation=%r ruleflow=%r",
                    len(traces), operation, ruleflow)

    if output_dir is not None:
        logger.info("Writing traces to %s ...", output_dir)
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        (out / "operation_trace.json").write_text(
            json.dumps([t.model_dump() for t in traces], indent=2), encoding="utf-8")
        for t, slug in assign_unique_slugs(traces):
            (out / f"{slug}.operation_trace.json").write_text(
                t.model_dump_json(indent=2), encoding="utf-8")

        dep_traces = []
        if not (operation or ruleflow):  # deployment rollup is workspace-wide
            dep_traces = trace_all_deployments(ws)
            (out / "deployment_trace.json").write_text(
                json.dumps([d.model_dump() for d in dep_traces], indent=2), encoding="utf-8")
            for d in dep_traces:
                (out / f"{_slug(d.name or d.ruleapp)}.deployment_trace.json").write_text(
                    d.model_dump_json(indent=2), encoding="utf-8")

        summary = {
            "root": str(ws.root),
            "projects": [str(p.relative_to(ws.root)) if p != ws.root else "." for p in ws.projects],
            "files_parsed": len(ws.files),
            "operations": len(ws.operations),
            "deployments": len(ws.deployments),
            "rules_indexed": len(ws.rules_by_uuid),
            "flows_indexed": len(ws.flows_by_uuid),
            "unresolved_total": sum(t.stats.get("unresolved", 0) for t in traces),
            "warnings": ws.warnings,
        }
        (out / "_workspace_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        logger.info("Done: %d operation trace(s), %d deployment trace(s) written.",
                    len(traces), len(dep_traces))

    return ws, traces
