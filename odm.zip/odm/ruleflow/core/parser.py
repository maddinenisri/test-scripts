"""
Ruleflow parser for IBM ODM Studio .rfl files.

Parses the RuleFlow / Ruleflow / TaskList / NodeList / TransitionList XML
into OdmFlow + OdmStep metadata. Step order follows TransitionList from
start nodes; tasks without a NodeList mapping or not reachable from start
are omitted with a processing warning.
"""

import logging
import xml.etree.ElementTree as ET
from collections import deque
from datetime import datetime
from typing import Dict, List, Optional, Set, Tuple

from ...models import (
    FileProcessingError,
    FileProcessingErrorType,
    Metadata,
    OdmFile,
    OdmFileMetadata,
    OdmFlow,
    OdmFlowTransition,
    OdmRuleListEntry,
    OdmRuleListEntryType,
    OdmStep,
    OdmStepEnrichV2,
    SubFlowCall,
    build_odm_flow_v2,
)
from ...utils import Tokenizer, consistent_key_uuid
from ...base_odm_parser import BaseODMParser
from ...source_positions import (
    SourceSpan,
    element_span,
    parse_xml_root,
    span_enclosing_elements,
)
from ...xml_utils import (
    attr,
    child_text,
    extract_element_studio_uuid,
    extract_studio_uuid,
    extract_documentation,
    find_first_el,
    strip_ns,
)

logger = logging.getLogger(__name__)

_RULEFLOW_NESTED_TEXT_TAGS = frozenset({"IRL", "Body", "Text"})


def _ruleflow_child_text(el: ET.Element, tag_name: str) -> Optional[str]:
    return child_text(el, tag_name, nested_tags=_RULEFLOW_NESTED_TEXT_TAGS)


def _parse_rule_list_entries(task_el: ET.Element) -> List[OdmRuleListEntry]:
    entries: List[OdmRuleListEntry] = []
    list_order = 0
    for rulelist_el in task_el:
        if strip_ns(rulelist_el.tag) != "RuleList":
            continue
        for ref_el in rulelist_el:
            ref_tag = strip_ns(ref_el.tag)
            if ref_tag == "Package":
                pkg = attr(ref_el, "Name", "name")
                if pkg:
                    entries.append(
                        OdmRuleListEntry(
                            entry_type=OdmRuleListEntryType.PACKAGE,
                            list_order=list_order,
                            package_name=pkg,
                        )
                    )
                    list_order += 1
            elif ref_tag in ("Rule", "Function"):
                uuid_val = attr(ref_el, "Uuid", "uuid")
                if uuid_val:
                    entries.append(
                        OdmRuleListEntry(
                            entry_type=OdmRuleListEntryType.RULE,
                            list_order=list_order,
                            rule_uuid=uuid_val,
                        )
                    )
                    list_order += 1
    return entries


def _rule_list_reference_strings(entries: List[OdmRuleListEntry]) -> List[str]:
    refs: List[str] = []
    for entry in sorted(entries, key=lambda e: e.list_order):
        if entry.entry_type == OdmRuleListEntryType.PACKAGE and entry.package_name:
            refs.append(entry.package_name)
        elif entry.entry_type == OdmRuleListEntryType.RULE and entry.rule_uuid:
            refs.append(f"rule:{entry.rule_uuid}")
    return refs


def _parse_rule_execution_fields(
    task_el: ET.Element,
) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    execution_mode = attr(
        task_el,
        "ExecutionMode",
        "executionMode",
        "EngineMode",
        "engineMode",
    )
    ordering = attr(task_el, "Ordering", "ordering", "RuleOrdering", "ruleOrdering")
    exit_criteria = attr(
        task_el,
        "ExitCriteria",
        "exitCriteria",
        "ExitCriterion",
        "exitCriterion",
    )
    if not execution_mode:
        execution_mode = _ruleflow_child_text(task_el, "ExecutionMode") or ""
    if not ordering:
        ordering = _ruleflow_child_text(task_el, "Ordering") or ""
    if not exit_criteria:
        exit_criteria = _ruleflow_child_text(task_el, "ExitCriteria") or ""

    if not any((execution_mode, ordering, exit_criteria)):
        return None, None, None
    return (
        execution_mode or None,
        ordering or None,
        exit_criteria or None,
    )


def _parse_initial_actions_irl(task_el: ET.Element) -> Optional[str]:
    for child in task_el:
        tag = strip_ns(child.tag)
        if tag not in ("InitialActions", "InitialAction"):
            continue
        irl = _ruleflow_child_text(child, "IRL")
        if irl:
            return irl
        if child.text and child.text.strip():
            return child.text.strip()
        parts: List[str] = []
        for nested in child.iter():
            if nested is child:
                continue
            if nested.text and nested.text.strip():
                parts.append(nested.text.strip())
        if parts:
            return "\n".join(parts)
    return None


def _parse_transition_condition(trans_el: ET.Element) -> Tuple[Optional[str], Optional[str]]:
    condition = attr(
        trans_el,
        "Condition",
        "condition",
        "Guard",
        "guard",
        "Expression",
        "expression",
    )
    label = attr(trans_el, "Label", "label", "Name", "name")
    if not condition:
        condition = _ruleflow_child_text(trans_el, "Condition") or _ruleflow_child_text(trans_el, "Guard")
    if not condition:
        for child in trans_el:
            ctag = strip_ns(child.tag)
            if ctag in ("Condition", "Guard", "Expression", "IRL", "BAL"):
                text = _ruleflow_child_text(trans_el, ctag) or (child.text or "").strip()
                if text:
                    condition = text
                    break
    if not label:
        label = _ruleflow_child_text(trans_el, "Label")
    return (condition or None, label or None)


def _parse_rfl_transitions(body_el: ET.Element) -> List[OdmFlowTransition]:
    transitions: List[OdmFlowTransition] = []
    for child in body_el:
        if strip_ns(child.tag) != "TransitionList":
            continue
        for trans_el in child:
            if strip_ns(trans_el.tag) != "Transition":
                continue
            source = attr(trans_el, "Source", "source")
            target = attr(trans_el, "Target", "target")
            identifier = attr(trans_el, "Identifier", "identifier", "Name", "name")
            condition, label = _parse_transition_condition(trans_el)
            if source or target:
                transitions.append(
                    OdmFlowTransition(
                        identifier=identifier,
                        source=source,
                        target=target,
                        condition=condition,
                        guard=condition,
                        label=label,
                    )
                )
        break
    return transitions


def _parse_rfl_task_list_boundary_tasks(
    body_el: ET.Element,
) -> Tuple[Set[str], Set[str]]:
    """Return StartTask and StopTask identifiers from TaskList."""
    start_task_ids: Set[str] = set()
    stop_task_ids: Set[str] = set()
    for child in body_el:
        if strip_ns(child.tag) != "TaskList":
            continue
        for task_el in child:
            task_tag = strip_ns(task_el.tag)
            task_id = attr(task_el, "Identifier", "identifier")
            if not task_id:
                continue
            if task_tag == "StartTask":
                start_task_ids.add(task_id)
            elif task_tag == "StopTask":
                stop_task_ids.add(task_id)
        break
    return start_task_ids, stop_task_ids


def _parse_rfl_executable_task_ids(body_el: ET.Element) -> Set[str]:
    """Return non-boundary task identifiers declared in TaskList."""
    executable_task_ids: Set[str] = set()
    for child in body_el:
        if strip_ns(child.tag) != "TaskList":
            continue
        for task_el in child:
            task_tag = strip_ns(task_el.tag)
            if task_tag in ("StartTask", "StopTask"):
                continue
            task_id = attr(task_el, "Identifier", "identifier")
            if task_id:
                executable_task_ids.add(task_id)
        break
    return executable_task_ids


def _apply_step_graph(
    steps_by_task_id: Dict[str, OdmStep],
    transitions: List[OdmFlowTransition],
    node_to_task: Dict[str, str],
) -> None:
    successors: Dict[str, Set[str]] = {tid: set() for tid in steps_by_task_id}
    predecessors: Dict[str, Set[str]] = {tid: set() for tid in steps_by_task_id}

    for trans in transitions:
        src_task = node_to_task.get(trans.source, trans.source)
        tgt_task = node_to_task.get(trans.target, trans.target)
        if src_task in steps_by_task_id and tgt_task in steps_by_task_id:
            successors[src_task].add(tgt_task)
            predecessors[tgt_task].add(src_task)

    for task_id, step in steps_by_task_id.items():
        step.next_step_ids = sorted(successors.get(task_id, []))
        step.predecessor_step_ids = sorted(predecessors.get(task_id, []))


def _order_tasks_by_transition_walk(
    transitions: List[OdmFlowTransition],
    node_to_task: Dict[str, str],
    start_node_ids: Set[str],
    executable_task_ids: Set[str],
) -> Tuple[List[str], List[str]]:
    """Order reachable executable tasks by walking TransitionList from start nodes."""
    adjacency: Dict[str, List[str]] = {}
    for trans in transitions:
        if trans.source and trans.target:
            adjacency.setdefault(trans.source, []).append(trans.target)

    queue: deque[str] = deque(sorted(start_node_ids))
    seen_nodes: Set[str] = set()
    ordered: List[str] = []
    seen_tasks: Set[str] = set()

    while queue:
        node_id = queue.popleft()
        if node_id in seen_nodes:
            continue
        seen_nodes.add(node_id)
        task_id = node_to_task.get(node_id)
        if task_id and task_id in executable_task_ids and task_id not in seen_tasks:
            ordered.append(task_id)
            seen_tasks.add(task_id)
        for nxt in adjacency.get(node_id, []):
            if nxt not in seen_nodes:
                queue.append(nxt)

    unreachable = [
        task_id for task_id in executable_task_ids if task_id not in seen_tasks
    ]
    return ordered, unreachable


def _parse_rfl_node_maps(
    body_el: ET.Element,
    start_task_ids: Set[str],
    stop_task_ids: Set[str],
) -> Tuple[Dict[str, str], Dict[str, str], Set[str], Set[str], Optional[str]]:
    """Return node_to_task, task_to_node, start_node_ids, stop_node_ids, primary_start_node."""
    node_to_task: Dict[str, str] = {}
    task_to_node: Dict[str, str] = {}
    start_node_ids: Set[str] = set()
    stop_node_ids: Set[str] = set()
    primary_start_node: Optional[str] = None

    for child in body_el:
        if strip_ns(child.tag) != "NodeList":
            continue
        for node_el in child:
            node_tag = strip_ns(node_el.tag)
            node_id = attr(node_el, "Identifier", "identifier")
            task_id = attr(node_el, "Task", "task")
            if node_tag in ("StartNode", "Start"):
                if node_id:
                    start_node_ids.add(node_id)
                    if primary_start_node is None:
                        primary_start_node = node_id
            elif node_tag in ("StopNode", "Stop", "EndNode", "End"):
                if node_id:
                    stop_node_ids.add(node_id)
            elif node_tag == "TaskNode" and node_id and task_id:
                node_to_task[node_id] = task_id
                task_to_node[task_id] = node_id
                if task_id in start_task_ids:
                    start_node_ids.add(node_id)
                    if primary_start_node is None:
                        primary_start_node = node_id
                elif task_id in stop_task_ids:
                    stop_node_ids.add(node_id)
        break

    return node_to_task, task_to_node, start_node_ids, stop_node_ids, primary_start_node


class RuleflowParser(BaseODMParser):
    """Parses IBM ODM Studio .rfl XML into standard Metadata."""

    def __init__(self) -> None:
        super().__init__()
        self._pending_warnings: List[FileProcessingError] = []

    def _get_language_name(self) -> str:
        return "odm_ruleflow"

    def _record_warning(self, title: str, detailed: str) -> None:
        if any(w.title == title and w.detailed == detailed for w in self._pending_warnings):
            return
        logger.warning(f"RuleflowParser: {title} — {detailed}")
        self._pending_warnings.append(
            FileProcessingError(
                title=title,
                detailed=detailed,
                type=FileProcessingErrorType.warning,
            )
        )

    def _validate_rfl_task_node_consistency(
        self,
        flow_name: str,
        body_el: ET.Element,
        node_to_task: Dict[str, str],
        task_to_node: Dict[str, str],
        start_task_ids: Set[str],
        stop_task_ids: Set[str],
    ) -> None:
        executable_task_ids = _parse_rfl_executable_task_ids(body_el)
        all_tasklist_ids = executable_task_ids | start_task_ids | stop_task_ids

        unmapped_tasks = sorted(
            task_id for task_id in executable_task_ids if task_id not in task_to_node
        )
        if unmapped_tasks:
            self._record_warning(
                title="TaskList tasks without NodeList mapping",
                detailed=(
                    f"Task(s) in TaskList of flow {flow_name!r} have no matching "
                    f"NodeList Task= entry: {', '.join(unmapped_tasks)}"
                ),
            )

        broken_nodes = sorted(
            f"{node_id}->{task_id}"
            for node_id, task_id in node_to_task.items()
            if task_id not in all_tasklist_ids
        )
        if broken_nodes:
            self._record_warning(
                title="NodeList tasks not in TaskList",
                detailed=(
                    f"NodeList Task= value(s) in flow {flow_name!r} do not match any "
                    f"TaskList Identifier: {', '.join(broken_nodes)}"
                ),
            )

    def parse_file(
        self,
        relative_path: str,
        file_name: str,
        source_code: str,
        file_hash: str,
        file_uuid: str,
        charset: str = "utf-8",
        parser_run_config=None,
        s3_handler=None,
    ) -> Metadata:
        self._pending_warnings = []
        metadata = super().parse_file(
            relative_path=relative_path,
            file_name=file_name,
            source_code=source_code,
            file_hash=file_hash,
            file_uuid=file_uuid,
            charset=charset,
            parser_run_config=parser_run_config,
            s3_handler=s3_handler,
        )
        metadata.processing_errors.extend(self._pending_warnings)
        return metadata

    def _extract_odm_metadata(
        self, source_code: str, file_name: str, file_uuid: str
    ) -> Optional[OdmFileMetadata]:
        flows = self._parse_ruleflows(source_code, file_uuid)
        if not flows:
            return None

        studio_uuid: Optional[str] = None
        try:
            rfl_root = parse_xml_root(source_code)
            studio_uuid = extract_studio_uuid(rfl_root)
        except ET.ParseError:
            pass

        odm_file = OdmFile(
            key=file_uuid,
            file_name=file_name,
            language="odm_ruleflow",
            parsed_date_time=datetime.now(),
            studio_uuid=studio_uuid,
        )
        return OdmFileMetadata(
            file=odm_file,
            flows=flows,
            parsed_date_time=datetime.now(),
        )

    def raw_token_count_estimator(
        self, metadata: Metadata, tokenizer: Tokenizer, source_code: str
    ) -> int:
        if metadata.odm_file_metadata is None:
            return 0

        full_tokens = tokenizer.count_tokens(source_code)
        total = 0
        for flow in metadata.odm_file_metadata.flows:
            total += full_tokens
            total += full_tokens * len(flow.steps)
        return total

    def _parse_ruleflows(self, source_code: str, file_uuid: str) -> List[OdmFlow]:
        flows: List[OdmFlow] = []
        try:
            root = parse_xml_root(source_code)
        except ET.ParseError as exc:
            logger.warning(f"RuleflowParser: XML parse error — {exc}")
            return flows

        root_tag = strip_ns(root.tag)

        if root_tag != "RuleFlow":
            logger.warning(
                f"RuleflowParser: expected <RuleFlow> root element, found {root_tag!r}"
            )
            return flows

        flow = self._parse_rfl_root(root, file_uuid, source_code)
        if flow:
            flows.append(flow)
        return flows

    def _parse_rfl_root(
        self, root: ET.Element, file_uuid: str, source_code: str
    ) -> Optional[OdmFlow]:
        name_el = find_first_el(root, "name")
        flow_name = (
            name_el.text.strip()
            if name_el is not None and name_el.text
            else "UnnamedFlow"
        )

        ruleflow_el: Optional[ET.Element] = None
        for el in root.iter():
            if strip_ns(el.tag) == "Ruleflow":
                ruleflow_el = el
                break

        if ruleflow_el is None:
            logger.warning("RuleflowParser: no <Ruleflow> element found inside .rfl")
            return None

        flow = self._parse_rfl_ruleflow(ruleflow_el, flow_name, file_uuid, source_code)
        if flow is not None and not flow.documentation:
            flow.documentation = extract_documentation(root)
        if flow is not None and not flow.studio_uuid:
            # The flow's Studio UUID lives as a <uuid> child of the outer <RuleFlow>
            # root (the inner <Ruleflow> element cannot see it).
            flow.studio_uuid = extract_studio_uuid(root)
        return flow

    def _parse_rfl_ruleflow(
        self,
        ruleflow_el: ET.Element,
        flow_name: str,
        file_uuid: str,
        source_code: str,
    ) -> Optional[OdmFlow]:
        body_el: Optional[ET.Element] = None
        for child in ruleflow_el:
            if strip_ns(child.tag) == "Body":
                body_el = child
                break
        if body_el is None:
            return None

        start_task_ids, stop_task_ids = _parse_rfl_task_list_boundary_tasks(body_el)
        node_to_task, task_to_node, start_node_ids, _stop_node_ids, primary_start = (
            _parse_rfl_node_maps(body_el, start_task_ids, stop_task_ids)
        )
        transitions = _parse_rfl_transitions(body_el)

        self._validate_rfl_task_node_consistency(
            flow_name,
            body_el,
            node_to_task,
            task_to_node,
            start_task_ids,
            stop_task_ids,
        )

        if not start_node_ids and primary_start:
            start_node_ids.add(primary_start)
        if not start_node_ids:
            for trans in transitions:
                if trans.source and trans.source not in node_to_task:
                    start_node_ids.add(trans.source)

        outgoing: Dict[str, int] = {}
        for trans in transitions:
            if trans.source:
                outgoing[trans.source] = outgoing.get(trans.source, 0) + 1

        conditional_tasks: Set[str] = {
            node_to_task[nid]
            for nid, cnt in outgoing.items()
            if cnt > 1 and nid in node_to_task
        }

        steps_by_task_id: Dict[str, OdmStep] = {}

        for child in body_el:
            if strip_ns(child.tag) != "TaskList":
                continue
            for task_el in child:
                task_tag = strip_ns(task_el.tag)
                if task_tag in ("StartTask", "StopTask"):
                    continue

                task_id = attr(task_el, "Identifier", "identifier")
                if not task_id or task_id not in task_to_node:
                    continue

                sub_flow_call: Optional[SubFlowCall] = None
                sub_flow_key: Optional[str] = None
                studio_uuid: Optional[str] = None

                if task_tag in ("RuleTask", "ActionTask"):
                    rule_list_entries = _parse_rule_list_entries(task_el)
                    refs = _rule_list_reference_strings(rule_list_entries)
                    program_name = refs[0] if refs else None
                    if task_tag == "ActionTask":
                        desc = f"Action: {', '.join(refs)}" if refs else task_id
                    else:
                        desc = f"Execute: {', '.join(refs)}" if refs else task_id
                    step_type = "PROCESS"
                    execution_mode, ordering, exit_criteria = _parse_rule_execution_fields(
                        task_el
                    )
                    initial_actions_irl = _parse_initial_actions_irl(task_el)
                    studio_uuid = extract_element_studio_uuid(task_el)

                elif task_tag in ("FlowTask", "SubflowTask"):
                    rule_list_entries = []
                    flow_ref: Optional[str] = attr(
                        task_el,
                        "Ruleflow",
                        "ruleflow",
                        "FlowName",
                        "flowName",
                        "Name",
                        "name",
                    ) or None
                    flow_uuid: Optional[str] = attr(
                        task_el,
                        "Uuid",
                        "uuid",
                        "RuleflowUuid",
                        "ruleflowUuid",
                    ) or None
                    for child_el in task_el:
                        ctag = strip_ns(child_el.tag)
                        if ctag == "FlowRef":
                            flow_ref = (
                                attr(child_el, "FlowName", "flowName", "Name", "name")
                                or flow_ref
                            )
                            flow_uuid = (
                                extract_studio_uuid(child_el)
                                or attr(child_el, "Uuid", "uuid")
                                or flow_uuid
                            )
                        elif ctag == "RulesetPath" and child_el.text:
                            flow_ref = child_el.text.strip().rstrip("/").split("/")[-1]
                    program_name = flow_ref
                    desc = f"Call flow: {flow_ref}" if flow_ref else task_id
                    step_type = "CALL"
                    execution_mode, ordering, exit_criteria = None, None, None
                    initial_actions_irl = _parse_initial_actions_irl(task_el)
                    sub_flow_key = None
                    sub_flow_call = (
                        SubFlowCall(name=flow_ref) if flow_ref else None
                    )
                    studio_uuid = flow_uuid

                else:
                    continue

                node_id = task_to_node.get(task_id)
                task_span = element_span(source_code, task_el)

                step = OdmStep(
                    key=consistent_key_uuid(f"{file_uuid}-{flow_name}-{task_id}"),
                    name=task_id,
                    line_number=task_span.start_line,
                    condition_desc=desc,
                    program_name=program_name,
                    step_type=step_type,
                    start_line=task_span.start_line,
                    start_column=task_span.start_column,
                    end_line=task_span.end_line,
                    end_column=task_span.end_column,
                    is_conditional=task_id in conditional_tasks,
                    condition_statement=None,
                    statement=initial_actions_irl,
                    task_id=task_id,
                    node_id=node_id,
                    rule_list_entries=rule_list_entries,
                    execution_mode=execution_mode,
                    ordering=ordering,
                    exit_criteria=exit_criteria,
                    initial_actions_irl=initial_actions_irl,
                    sub_flow_call=sub_flow_call,
                    sub_flow_key=sub_flow_key,
                    studio_uuid=studio_uuid,
                    llm_enrich_v2=OdmStepEnrichV2(
                        rule_list_entries=list(rule_list_entries),
                    ),
                )
                steps_by_task_id[task_id] = step
            break

        if not steps_by_task_id:
            return None

        executable_task_ids = set(steps_by_task_id.keys())
        sorted_task_ids, unreachable_task_ids = _order_tasks_by_transition_walk(
            transitions,
            node_to_task,
            start_node_ids,
            executable_task_ids,
        )
        if unreachable_task_ids:
            self._record_warning(
                title="Unreachable ruleflow tasks",
                detailed=(
                    f"Task(s) mapped in NodeList but not reachable from start nodes "
                    f"via TransitionList: {', '.join(unreachable_task_ids)}"
                ),
            )
            for task_id in unreachable_task_ids:
                steps_by_task_id.pop(task_id, None)

        if not sorted_task_ids:
            self._record_warning(
                title="No reachable ruleflow tasks",
                detailed=(
                    f"No executable tasks were reachable from start nodes in flow "
                    f"{flow_name!r}."
                ),
            )
            return None

        _apply_step_graph(steps_by_task_id, transitions, node_to_task)

        steps: List[OdmStep] = []
        for order_idx, task_id in enumerate(sorted_task_ids, start=1):
            step = steps_by_task_id[task_id]
            step.order = order_idx
            steps.append(step)

        flow_v2 = build_odm_flow_v2(steps, transitions, node_to_task, conditional_tasks)
        step_spans = [
            SourceSpan(s.start_line, s.start_column, s.end_line, s.end_column)
            for s in steps
        ]
        flow_span = span_enclosing_elements(
            source_code, ruleflow_el, *step_spans
        )
        rfl_studio_uuid: Optional[str] = None
        for el in ruleflow_el.iter():
            if strip_ns(el.tag) == "RuleFlow":
                rfl_studio_uuid = extract_studio_uuid(el)
                break

        return OdmFlow(
            name=flow_name,
            language="odm_ruleflow",
            key=consistent_key_uuid(f"{file_uuid}-flow-{flow_name}"),
            steps=steps,
            transitions=transitions,
            flow_v2=flow_v2,
            studio_uuid=rfl_studio_uuid,
            documentation=extract_documentation(ruleflow_el),
            start_line=flow_span.start_line,
            end_line=flow_span.end_line,
        )
