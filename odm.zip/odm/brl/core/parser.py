"""
BRL (Business Rule Language) parser for IBM ODM .brl files.

Each .brl file is a single business rule in IBM ODM Studio XML format.

The IRL text in <definition> may use:
  if   <conditions>  then <actions>
  definitions <setup> then <actions>

Conditions and setup lines become Parameters; action lines become CallExpressions.

Each .brl file = one rule → one Function in metadata.functions.
"""

import logging
import re
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import List, Optional, Tuple

from ...models import (
    CallExpression,
    Function,
    Metadata,
    OdmBrlRule,
    OdmFile,
    OdmFileMetadata,
    Parameter,
)
from ...utils import Tokenizer, consistent_key_uuid
from ...base_odm_parser import BaseODMParser
from ...bom_helpers import extract_bom_qualified_types_from_brl
from ...source_positions import (
    element_span,
    fragment_span_in_element,
    parse_xml_root,
)
from ...xml_utils import (
    extract_studio_uuid,
    extract_documentation,
    find_first_el,
)

logger = logging.getLogger(__name__)


def _parse_irl(irl_text: str) -> Tuple[List[str], List[str]]:
    """Split IRL rule body into (conditions, actions)."""
    text = irl_text.strip()

    then_m = re.search(r'\bthen\b', text, re.IGNORECASE)
    if not then_m:
        conds = [l.strip().rstrip(';') for l in text.splitlines() if l.strip()]
        return conds, []

    before_then = text[: then_m.start()]
    after_then = text[then_m.end():]

    cond_lines = []
    for raw in before_then.splitlines():
        stripped = raw.strip()
        if not stripped:
            continue
        if re.match(r'^(if|when|definitions)\s*$', stripped, re.IGNORECASE):
            continue
        stripped = re.sub(r'^(if|when|definitions)\s+', '', stripped, flags=re.IGNORECASE)
        stripped = stripped.rstrip(';').strip()
        if stripped:
            cond_lines.append(stripped)

    action_lines = []
    for raw in after_then.splitlines():
        stripped = raw.strip().rstrip(';').strip()
        if stripped:
            action_lines.append(stripped)

    return cond_lines, action_lines


class BRLParser(BaseODMParser):
    """Parses IBM ODM .brl XML files into standard Metadata."""

    def _get_language_name(self) -> str:
        return "odm_brl"

    def _extract_odm_metadata(
        self, source_code: str, file_name: str, file_uuid: str
    ) -> Optional[OdmFileMetadata]:
        try:
            root = parse_xml_root(source_code)
        except ET.ParseError:
            return None

        name_el = find_first_el(root, "name")
        rule_name = (
            name_el.text.strip()
            if name_el is not None and name_el.text
            else "UnnamedRule"
        )
        studio_uuid = extract_studio_uuid(root)
        documentation = extract_documentation(root)
        function_key = consistent_key_uuid(f"{file_uuid}-rule-{rule_name}")

        return OdmFileMetadata(
            file=OdmFile(
                key=file_uuid,
                file_name=file_name,
                language="odm_brl",
                parsed_date_time=datetime.now(),
                studio_uuid=studio_uuid,
            ),
            rules=[
                OdmBrlRule(
                    name=rule_name,
                    function_key=function_key,
                    studio_uuid=studio_uuid,
                    documentation=documentation,
                    bom_type_refs=extract_bom_qualified_types_from_brl(source_code),
                )
            ],
            parsed_date_time=datetime.now(),
        )

    def _extract_functions(self, source_code: str, file_uuid: str) -> List[Function]:
        try:
            root = parse_xml_root(source_code)
        except ET.ParseError as exc:
            logger.warning(f"BRLParser: XML parse error — {exc}")
            return []

        name_el = find_first_el(root, "name")
        rule_name = (
            name_el.text.strip()
            if name_el is not None and name_el.text
            else "UnnamedRule"
        )

        definition_el = find_first_el(root, "definition")
        irl_text = (definition_el.text or "") if definition_el is not None else ""

        rule_span = element_span(source_code, root)
        if definition_el is not None:
            body_span = element_span(source_code, definition_el)
        else:
            body_span = rule_span

        conditions, actions = _parse_irl(irl_text)

        parameters = [
            Parameter(name=cond, type="condition", optional=False)
            for cond in conditions
            if cond
        ]

        calls: List[CallExpression] = []
        for action in actions:
            if not action:
                continue
            act_span = (
                fragment_span_in_element(source_code, definition_el, action)
                if definition_el is not None
                else None
            )
            if act_span is None:
                act_span = body_span
            calls.append(
                CallExpression(
                    function_called=action,
                    start_line=act_span.start_line,
                    start_column=act_span.start_column,
                    end_line=act_span.end_line,
                    end_column=act_span.end_column,
                )
            )

        func = Function(
            name=rule_name,
            parameters=parameters,
            return_type="void",
            start_line=rule_span.start_line,
            start_column=rule_span.start_column,
            end_line=rule_span.end_line,
            end_column=rule_span.end_column,
            calls=calls,
            body_start_line=body_span.start_line,
            body_start_column=body_span.start_column,
            body_end_line=body_span.end_line,
            body_end_column=body_span.end_column,
        )
        func.key = consistent_key_uuid(f"{file_uuid}-rule-{rule_name}")
        func.line_count = rule_span.end_line - rule_span.start_line + 1
        return [func]

    def raw_token_count_estimator(
        self, metadata: Metadata, tokenizer: Tokenizer, source_code: str
    ) -> int:
        return tokenizer.count_tokens(source_code) * len(metadata.functions)
