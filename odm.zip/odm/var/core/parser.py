"""
Variable Set parser for IBM ODM .var files.

A .var file defines the typed, verbalized run-time variables for a ruleset.

Mapping:
  The VariableSet → one Class (name = varset name)
  Each <variables> element → one ClassAttribute (name, type)
"""

import logging
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import List, Optional

from ...models import (
    Class,
    ClassAttribute,
    Metadata,
    OdmFile,
    OdmFileMetadata,
    OdmVariable,
    OdmVariableSet,
)
from ...utils import Tokenizer, consistent_key_uuid
from ...base_odm_parser import BaseODMParser
from ...source_positions import parse_xml_root
from ...xml_utils import extract_studio_uuid, find_first_el, strip_ns

logger = logging.getLogger(__name__)


class VarSetParser(BaseODMParser):
    """Parses IBM ODM .var Variable Set XML into standard Metadata."""

    def _get_language_name(self) -> str:
        return "odm_var"

    def _extract_odm_metadata(
        self, source_code: str, file_name: str, file_uuid: str
    ) -> Optional[OdmFileMetadata]:
        try:
            root = parse_xml_root(source_code)
        except ET.ParseError as exc:
            logger.warning(f"VarSetParser: XML parse error — {exc}")
            return None

        name_el = find_first_el(root, "name")
        varset_name = (
            name_el.text.strip()
            if name_el is not None and name_el.text
            else "UnnamedVarSet"
        )

        variables: List[OdmVariable] = []
        for var_el in root.iter():
            if strip_ns(var_el.tag) != "variables":
                continue
            tech = var_el.get("name")
            if not tech:
                continue
            verb = (var_el.get("verbalization") or "").strip() or None
            init = (var_el.get("initialValue") or "").strip() or None
            variables.append(
                OdmVariable(
                    name=tech,
                    type=var_el.get("type") or "Object",
                    verbalization=verb,
                    initial_value=init,
                )
            )

        if not variables:
            return None

        return OdmFileMetadata(
            file=OdmFile(
                key=file_uuid,
                file_name=file_name,
                language="odm_var",
                studio_uuid=extract_studio_uuid(root),
                parsed_date_time=datetime.now(),
            ),
            variable_set=OdmVariableSet(
                name=varset_name,
                studio_uuid=extract_studio_uuid(root),
                variables=variables,
            ),
        )

    def _extract_classes(self, source_code: str, file_uuid: str) -> List[Class]:
        try:
            root = parse_xml_root(source_code)
        except ET.ParseError as exc:
            logger.warning(f"VarSetParser: XML parse error — {exc}")
            return []

        name_el = find_first_el(root, "name")
        varset_name = (
            name_el.text.strip()
            if name_el is not None and name_el.text
            else "UnnamedVarSet"
        )

        attributes: List[ClassAttribute] = []
        var_index = 0
        for var_el in root.iter():
            if strip_ns(var_el.tag) != "variables":
                continue
            var_index += 1
            technical_name = var_el.get("name") or f"var{var_index}"
            verbalization = var_el.get("verbalization", "").strip()
            attr_name = verbalization if verbalization else technical_name
            attr_type = var_el.get("type") or "Object"
            attributes.append(
                ClassAttribute(
                    name=attr_name,
                    type=attr_type,
                    start_line=var_index,
                    start_column=1,
                    end_line=var_index,
                    end_column=1,
                )
            )

        if not attributes:
            return []

        cls = Class(
            name=varset_name,
            start_line=1,
            start_column=1,
            end_line=len(attributes),
            end_column=0,
            methods=[],
            attributes=attributes,
            extends=[],
            implements=[],
        )
        cls.key = consistent_key_uuid(f"{file_uuid}-varset-{varset_name}")
        return [cls]

    def raw_token_count_estimator(
        self, metadata: Metadata, tokenizer: Tokenizer, source_code: str
    ) -> int:
        return tokenizer.count_tokens(source_code) * len(metadata.classes)
