"""
DMT (Decision Table) parser for IBM ODM .dmt files.

A decision table has:
  - Column definitions (condition + action headers)
  - Rows — each row IS one business rule

Mapping:
  metadata.classes       → one Class per decision table; each row → ClassMethod
    row condition cells  → ClassMethod.parameters (type="condition")
    row action cells     → ClassMethod.calls (CallExpression)
"""

import logging
import xml.etree.ElementTree as ET
from typing import List, Optional, Tuple

from ...models import (
    CallExpression,
    Class,
    ClassAttribute,
    ClassMethod,
    Metadata,
    Parameter,
)
from ...utils import Tokenizer, consistent_key_uuid
from ...base_odm_parser import BaseODMParser
from ...source_positions import parse_xml_root
from ...xml_utils import strip_ns

logger = logging.getLogger(__name__)


class DMTParser(BaseODMParser):
    """Parses IBM ODM .dmt decision-table XML into standard Metadata."""

    def _get_language_name(self) -> str:
        return "odm_dmt"

    def _extract_classes(self, source_code: str, file_uuid: str) -> List[Class]:
        return self._parse_row_classes(source_code, file_uuid)

    def raw_token_count_estimator(
        self, metadata: Metadata, tokenizer: Tokenizer, source_code: str
    ) -> int:
        full_tokens = tokenizer.count_tokens(source_code)
        total = 0
        for cls in metadata.classes:
            total += full_tokens * len(cls.methods)
        return total

    def _parse_row_classes(self, source_code: str, file_uuid: str) -> List[Class]:
        classes: List[Class] = []
        try:
            root = parse_xml_root(source_code)
        except ET.ParseError as exc:
            logger.warning(f"DMTParser: XML parse error (rows) — {exc}")
            return classes

        nodes = list(root) if strip_ns(root.tag) in ("tables", "decisionTables") else [root]
        for node in nodes:
            if strip_ns(node.tag) == "decisionTable":
                cls = self._build_row_class(node, file_uuid)
                if cls:
                    classes.append(cls)
        return classes

    def _build_row_class(self, node: ET.Element, file_uuid: str) -> Optional[Class]:
        name = node.get("name") or node.get("displayName") or "UnnamedTable"

        condition_headers: List[str] = []
        action_headers: List[str] = []

        for cond_block in node.iter():
            if strip_ns(cond_block.tag) == "conditions":
                for col_def in cond_block:
                    if strip_ns(col_def.tag) == "columnDefinition":
                        condition_headers.append(col_def.get("header", f"Condition{len(condition_headers)+1}"))
                break

        for action_block in node.iter():
            if strip_ns(action_block.tag) == "actions":
                for col_def in action_block:
                    if strip_ns(col_def.tag) == "columnDefinition":
                        action_headers.append(col_def.get("header", f"Action{len(action_headers)+1}"))
                break

        methods = self._parse_rows(node, name, condition_headers, action_headers, file_uuid)
        if not methods:
            return None

        cls = Class(
            name=name,
            start_line=1,
            start_column=1,
            end_line=len(methods),
            end_column=0,
            methods=methods,
            attributes=[
                ClassAttribute(name="table_type", type="str", start_line=1, start_column=1, end_line=1, end_column=1)
            ],
            extends=[],
            implements=[],
        )
        cls.key = consistent_key_uuid(f"{file_uuid}-dmt-class-{name}")
        return cls

    def _parse_rows(
        self,
        node: ET.Element,
        table_name: str,
        condition_headers: List[str],
        action_headers: List[str],
        file_uuid: str,
    ) -> List[ClassMethod]:
        methods: List[ClassMethod] = []

        row_nodes: List[ET.Element] = []
        for child in node:
            tag = strip_ns(child.tag)
            if tag == "rows":
                row_nodes = [r for r in child if strip_ns(r.tag) == "row"]
                break
            elif tag == "row":
                row_nodes.append(child)

        for row_index, row_node in enumerate(row_nodes, start=1):
            row_id = row_node.get("id") or row_node.get("name") or str(row_index)
            condition_cells, action_cells = self._extract_cells(row_node)

            parameters = [
                Parameter(name=f"{header}: {value}", type="condition", optional=False)
                for header, value in zip(condition_headers, condition_cells)
                if value.strip()
            ]
            calls = [
                CallExpression(function_called=f"{header}: {value}", start_line=row_index, start_column=1, end_line=row_index, end_column=1)
                for header, value in zip(action_headers, action_cells)
                if value.strip()
            ]

            method = ClassMethod(
                name=f"Rule {row_id}",
                class_name=table_name,
                parameters=parameters,
                return_type="void",
                start_line=row_index,
                start_column=1,
                end_line=row_index,
                end_column=1,
                calls=calls,
                body_start_line=row_index,
                body_start_column=1,
                body_end_line=row_index,
                body_end_column=1,
            )
            method.key = consistent_key_uuid(f"{file_uuid}-dmt-row-{table_name}-{row_id}")
            method.line_count = 1
            methods.append(method)

        return methods

    def _extract_cells(self, row_node: ET.Element) -> Tuple[List[str], List[str]]:
        condition_cells: List[str] = []
        action_cells: List[str] = []

        for child in row_node:
            tag = strip_ns(child.tag)

            if tag in ("cells", "conditionCells"):
                for cell in child:
                    condition_cells.append(cell.get("value") or cell.text or "")
            elif tag == "actionCells":
                for cell in child:
                    action_cells.append(cell.get("value") or cell.text or "")
            elif tag == "conditionCell":
                condition_cells.append(child.get("value") or child.text or "")
            elif tag == "actionCell":
                action_cells.append(child.get("value") or child.text or "")
            elif tag == "cell":
                value = child.get("value") or child.text or ""
                condition_cells.append(value)

        return condition_cells, action_cells
