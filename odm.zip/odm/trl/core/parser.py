"""
TRL (Technical Rule Language) parser for IBM ODM .trl files.

Each .trl file is a single technical rule.
"""

import logging
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import List, Optional

from ...models import (
    Function,
    Metadata,
    OdmBrlRule,
    OdmFile,
    OdmFileMetadata,
)
from ...utils import Tokenizer, consistent_key_uuid
from ...base_odm_parser import BaseODMParser
from ...source_positions import element_span, parse_xml_root
from ...xml_utils import extract_documentation, extract_studio_uuid, find_first_el

logger = logging.getLogger(__name__)


class TRLParser(BaseODMParser):
    """Parses IBM ODM .trl TechnicalRule XML into standard Metadata."""

    def _get_language_name(self) -> str:
        return "odm_trl"

    def _extract_odm_metadata(
        self, source_code: str, file_name: str, file_uuid: str
    ) -> Optional[OdmFileMetadata]:
        try:
            root = parse_xml_root(source_code)
        except ET.ParseError:
            return None

        studio_uuid = extract_studio_uuid(root)
        name_el = find_first_el(root, "name")
        rule_name = (
            name_el.text.strip()
            if name_el is not None and name_el.text
            else "UnnamedTechnicalRule"
        )
        documentation = extract_documentation(root)
        function_key = consistent_key_uuid(f"{file_uuid}-trl-{rule_name}")

        return OdmFileMetadata(
            file=OdmFile(
                key=file_uuid,
                file_name=file_name,
                language="odm_trl",
                parsed_date_time=datetime.now(),
                studio_uuid=studio_uuid,
            ),
            rules=[
                OdmBrlRule(
                    name=rule_name,
                    function_key=function_key,
                    studio_uuid=studio_uuid,
                    documentation=documentation,
                )
            ],
            parsed_date_time=datetime.now(),
        )

    def _extract_functions(self, source_code: str, file_uuid: str) -> List[Function]:
        try:
            root = parse_xml_root(source_code)
        except ET.ParseError as exc:
            logger.warning(f"TRLParser: XML parse error — {exc}")
            return []

        name_el = find_first_el(root, "name")
        rule_name = (
            name_el.text.strip()
            if name_el is not None and name_el.text
            else "UnnamedTechnicalRule"
        )

        definition_el = find_first_el(root, "definition")
        if definition_el is not None:
            rule_span = element_span(source_code, definition_el)
        else:
            rule_span = element_span(source_code, root)

        func = Function(
            name=rule_name,
            parameters=[],
            return_type="void",
            start_line=rule_span.start_line,
            start_column=rule_span.start_column,
            end_line=rule_span.end_line,
            end_column=rule_span.end_column,
            calls=[],
            body_start_line=rule_span.start_line,
            body_start_column=rule_span.start_column,
            body_end_line=rule_span.end_line,
            body_end_column=rule_span.end_column,
        )
        func.key = consistent_key_uuid(f"{file_uuid}-trl-{rule_name}")
        func.line_count = rule_span.end_line - rule_span.start_line + 1
        return [func]

    def raw_token_count_estimator(
        self, metadata: Metadata, tokenizer: Tokenizer, source_code: str
    ) -> int:
        return tokenizer.count_tokens(source_code) * len(metadata.functions)
