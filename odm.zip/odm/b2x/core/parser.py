"""
B2X (BOM-to-XOM execution binding) parser for IBM ODM .b2xa/.b2x files.

Each .b2xa/.b2x file is an XML document rooted at <b2x:translation> that maps
BOM virtual methods to their concrete ARL/Java execution bodies.

Top-level elements extracted:
  <id>    — artifact UUID / identifier
  <lang>  — execution language (e.g. "ARL")
  <class> — one per BOM class, containing:
      <businessName>  — fully-qualified BOM class name
      <method>        — one per method, containing:
          <name>          — method name
          <parameter type="..."/>  — zero-or-more typed parameters
          <body>          — CDATA execution body
"""

import logging
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import List, Optional

from ...base_odm_parser import BaseODMParser
from ...models import (
    Metadata,
    OdmB2xClass,
    OdmB2xMapping,
    OdmB2xMethod,
    OdmFile,
    OdmFileMetadata,
)
from ...source_positions import parse_xml_root
from ...utils import Tokenizer
from ...xml_utils import strip_ns

logger = logging.getLogger(__name__)


def _child_text(el: ET.Element, tag: str) -> str:
    """Return stripped text of the first direct child with local tag *tag*."""
    for child in el:
        if strip_ns(child.tag) == tag:
            return (child.text or "").strip()
    return ""


def _parse_method(method_el) -> OdmB2xMethod:
    """Extract name, parameter types, and body from a <method> element."""
    name = _child_text(method_el, "name")
    parameters: List[str] = []
    body = ""
    for child in method_el:
        local = strip_ns(child.tag)
        if local == "parameter":
            param_type = (child.get("type") or "").strip()
            if param_type:
                parameters.append(param_type)
        elif local == "body":
            body = (child.text or "").strip()
    return OdmB2xMethod(name=name, parameters=parameters, body=body)


def _parse_class(class_el) -> OdmB2xClass:
    """Extract businessName and methods from a <class> element."""
    business_name = _child_text(class_el, "businessName")
    methods: List[OdmB2xMethod] = []
    for child in class_el:
        if strip_ns(child.tag) == "method":
            try:
                methods.append(_parse_method(child))
            except Exception:
                logger.debug("B2xParser: skipping unparseable <method>", exc_info=True)
    return OdmB2xClass(business_name=business_name, methods=methods)


def _parse_b2xa(root) -> OdmB2xMapping:
    """Build an OdmB2xMapping from the parsed XML root element."""
    b2x_id = _child_text(root, "id")
    lang = _child_text(root, "lang")
    classes: List[OdmB2xClass] = []
    for child in root:
        if strip_ns(child.tag) == "class":
            try:
                classes.append(_parse_class(child))
            except Exception:
                logger.debug("B2xParser: skipping unparseable <class>", exc_info=True)
    return OdmB2xMapping(id=b2x_id, lang=lang, classes=classes)


class B2xParser(BaseODMParser):
    """Parses IBM ODM .b2xa/.b2x XML files into standard Metadata."""

    def _get_language_name(self) -> str:
        return "odm_b2x"

    def raw_token_count_estimator(
        self, metadata: Metadata, tokenizer: Tokenizer, source_code: str
    ) -> int:
        odm_meta = metadata.odm_file_metadata
        if odm_meta is None or not odm_meta.b2x_mappings:
            return 0
        # Weight by number of methods across all classes — mirrors the BRL pattern
        # of multiplying token count by the number of top-level semantic units.
        method_count = sum(
            len(cls.methods)
            for mapping in odm_meta.b2x_mappings
            for cls in mapping.classes
        )
        if method_count == 0:
            return 0
        return tokenizer.count_tokens(source_code) * method_count

    def _extract_odm_metadata(
        self, source_code: str, file_name: str, file_uuid: str
    ) -> Optional[OdmFileMetadata]:
        try:
            root = parse_xml_root(source_code)
        except ET.ParseError as exc:
            logger.warning("B2xParser: XML parse error — %s", exc)
            return None
        except Exception as exc:
            logger.warning("B2xParser: unexpected parse error — %s", exc)
            return None

        try:
            mapping = _parse_b2xa(root)
        except Exception as exc:
            logger.warning("B2xParser: failed to build B2xMapping — %s", exc)
            mapping = OdmB2xMapping()

        return OdmFileMetadata(
            file=OdmFile(
                key=file_uuid,
                file_name=file_name,
                language="odm_b2x",
                parsed_date_time=datetime.now(),
            ),
            b2x_mappings=[mapping],
            parsed_date_time=datetime.now(),
        )
