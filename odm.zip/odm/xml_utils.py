"""Shared IBM ODM Studio XML helpers for BRL, DTA, and ruleflow parsers."""

import xml.etree.ElementTree as ET
from typing import FrozenSet, Optional, Set


def strip_ns(tag: str) -> str:
    return tag.split("}", 1)[-1] if "}" in tag else tag


def attr(el: ET.Element, *names: str) -> str:
    for name in names:
        val = el.get(name)
        if val:
            return val.strip()
    return ""


def find_first_el(root: ET.Element, tag: str) -> Optional[ET.Element]:
    for el in root.iter():
        if strip_ns(el.tag) == tag:
            return el
    return None


def child_text(
    el: ET.Element,
    tag_name: str,
    *,
    nested_tags: Optional[FrozenSet[str]] = None,
) -> Optional[str]:
    for child in el:
        if strip_ns(child.tag) == tag_name:
            if child.text and child.text.strip():
                return child.text.strip()
            for nested in child:
                if nested_tags is not None and strip_ns(nested.tag) not in nested_tags:
                    continue
                if nested.text and nested.text.strip():
                    return nested.text.strip()
    return None


def element_text(root: ET.Element, tag: str) -> Optional[str]:
    """Return stripped text from the first element with the given local tag name."""
    match = find_first_el(root, tag)
    if match is None:
        return None
    text = (match.text or "").strip()
    return text or None


def extract_studio_uuid(root: ET.Element) -> Optional[str]:
    """Read Studio artifact UUID from root <uuid> or uuid/Uuid attributes."""
    uuid_el = root.find("uuid")
    if uuid_el is not None and uuid_el.text and uuid_el.text.strip():
        return uuid_el.text.strip()

    for tag in ("uuid", "Uuid", "UUID"):
        val = attr(root, tag)
        if val:
            return val

    for child in root:
        if strip_ns(child.tag) in ("uuid", "Uuid"):
            text = (child.text or "").strip()
            if text:
                return text
            nested = attr(child, "value", "Value", "Uuid", "uuid")
            if nested:
                return nested
    return None


def extract_element_studio_uuid(el: ET.Element) -> Optional[str]:
    """Read per-row / per-rule UUID from element attributes or nested <uuid>."""
    for name in ("Uuid", "uuid", "UUID", "RuleUuid", "ruleUuid", "RuleUUID"):
        val = attr(el, name)
        if val:
            return val
    uuid_el = find_first_el(el, "uuid")
    if uuid_el is not None and uuid_el.text and uuid_el.text.strip():
        return uuid_el.text.strip()
    for child in el:
        if strip_ns(child.tag) in ("uuid", "Uuid", "Rule"):
            text = (child.text or "").strip()
            if text:
                return text
            nested = attr(child, "Uuid", "uuid", "value", "Value")
            if nested:
                return nested
    return None


def extract_documentation(root: ET.Element) -> Optional[str]:
    """Read Studio author documentation from <documentation> CDATA/text."""
    doc_el = find_first_el(root, "documentation")
    if doc_el is None:
        return None
    text = (doc_el.text or "").strip()
    return text or None
