"""
BOM (Business Object Model) parser for IBM ODM .bom and .voc files.

The BOM defines the vocabulary that rules operate on: concepts (classes),
enumerations, domains, and verb phrases. This maps to Interface objects
because a BOM entity is a type contract — it declares shape and vocabulary,
not implementation.

  Interface        → one BOM concept / enumeration / domain class
  ClassAttribute   → each BOM attribute or enum value
  ClassMethod      → each vocabulary phrase (verbalization)
"""

from __future__ import annotations

import logging
import re
from datetime import datetime
from typing import Dict, List, Optional, Set, Tuple

from ...models import (
    ClassAttribute,
    ClassMethod,
    Interface,
    Metadata,
    OdmBomType,
    OdmFile,
    OdmFileMetadata,
    Parameter,
    build_odm_bom_type_details,
)
from ...utils import Tokenizer, consistent_key_uuid
from ...base_odm_parser import BaseODMParser
from ...bom_helpers import append_bom_dependencies

logger = logging.getLogger(__name__)

_VOC_CONCEPT_RE = re.compile(r"^([\w.]+)#concept\.label\s*=\s*(.+)$", re.MULTILINE)
_VOC_INSTANCE_RE = re.compile(
    r"^([\w.]+)\.(\w+)#instance\.label\s*=\s*(.+)$",
    re.MULTILINE,
)
_VOC_PHRASE_RE = re.compile(
    r"^([\w.]+)\.(\w+)(?:\([^)]*\))?#phrase\.(action|condition|navigation)\s*=\s*(.+)$",
    re.MULTILINE,
)

_BOM_PACKAGE_RE = re.compile(
    r"^\s*package\s+([A-Za-z_][\w.]*)\s*;",
    re.MULTILINE | re.IGNORECASE,
)
_BOM_CLASS_HEADER_RE = re.compile(
    r"^\s*public\s+(?:(abstract)\s+)?(?:(final)\s+)?(?:(enum)\s+)?class\s+(\w+)"
    r"(?:\s+extends\s+([\w.]+))?\s*\{?\s*$",
    re.MULTILINE,
)
_BOM_ENUM_HEADER_RE = re.compile(
    r"^\s*public\s+enum\s+(\w+)\s*\{?\s*$",
    re.MULTILINE,
)
_BOM_CLASS_PROPERTY_RE = re.compile(
    r'^\s*property\s+"([^"]+)"\s+"([^"]*)"\s*$',
    re.MULTILINE,
)
_BOM_DOMAIN_BLOCK_BRACE_RE = re.compile(r"domain\s*\{([^}]*)\}", re.MULTILINE | re.DOTALL)
_BOM_DOMAIN_BLOCK_PAREN_RE = re.compile(r"domain\s*\(([^)]*)\)", re.MULTILINE | re.DOTALL)
_BOM_DOMAIN_STATIC_REF_RE = re.compile(r"static\s+(\w+)")
_BOM_FIELD_RE = re.compile(
    r"^\s*public(?:\s+(?:static|final|readonly))*"
    r"\s+(?!class\s|enum\s)([\w.\[\]]+)\s+(\w+)\s*(?:property\s*)?(?:;)?\s*$",
    re.MULTILINE,
)
_BOM_METHOD_RE = re.compile(
    r"^\s*public\s+(?:static\s+)?(?:final\s+)?(?:readonly\s+)?"
    r"([\w.\[\]]+)\s+(\w+)\s*\(([^)]*)\)",
    re.MULTILINE,
)
_BOM_VERBALIZATION_RE = re.compile(r'verbalization\s+"([^"]+)"', re.MULTILINE)


def _qualified_type_to_package(qualified: str) -> str:
    path = (qualified or "").strip().rstrip(";")
    if not path:
        return ""
    parts = path.split(".")
    if len(parts) > 1 and parts[-1] and parts[-1][0].isupper():
        return ".".join(parts[:-1])
    if len(parts) > 1 and parts[-1].startswith("_"):
        return ".".join(parts[:-1])
    return path


class BOMParser(BaseODMParser):
    """Parses IBM ODM .bom (Java-like DSL) and .voc (property labels) into Metadata."""

    def __init__(self):
        super().__init__()
        self._bom_types = []

    def _get_language_name(self) -> str:
        return "odm_bom"

    def _odm_file_language(self, file_name: str) -> str:
        if file_name.lower().endswith(".voc"):
            return "odm_voc"
        return self._get_language_name()

    def _extract_odm_metadata(self, source_code: str, file_name: str, file_uuid: str):
        return OdmFileMetadata(
            file=OdmFile(
                key=file_uuid,
                file_name=file_name,
                language=self._odm_file_language(file_name),
                parsed_date_time=datetime.now(),
            ),
            bom_types=list(self._bom_types),
            parsed_date_time=datetime.now(),
        )

    def _extract_imports(self, source_code: str, metadata: Metadata) -> None:
        packages: Set[str] = set()
        for field_match in _BOM_FIELD_RE.finditer(source_code):
            pkg = _qualified_type_to_package(field_match.group(1))
            if pkg:
                packages.add(pkg)
        for method_match in _BOM_METHOD_RE.finditer(source_code):
            pkg = _qualified_type_to_package(method_match.group(1))
            if pkg:
                packages.add(pkg)
        append_bom_dependencies(metadata, packages)

    def _extract_package(self, source_code: str) -> Optional[str]:
        package_match = _BOM_PACKAGE_RE.search(source_code)
        if package_match:
            return package_match.group(1).strip()

        concept_fqns = [m.group(1).strip() for m in _VOC_CONCEPT_RE.finditer(source_code)]
        package_candidates = [fqn.rsplit(".", 1)[0] for fqn in concept_fqns if "." in fqn]
        if not package_candidates:
            return None

        split_parts = [pkg.split(".") for pkg in package_candidates]
        common_parts: List[str] = []
        for parts in zip(*split_parts):
            if len(set(parts)) == 1:
                common_parts.append(parts[0])
            else:
                break
        if common_parts:
            return ".".join(common_parts)
        return package_candidates[0]

    def _extract_interfaces(self, source_code: str, file_uuid: str) -> List[Interface]:
        self._bom_types = []
        if "#concept.label" in source_code:
            return self._parse_voc_properties(source_code, file_uuid)
        if (
            "public class" in source_code
            or "public final class" in source_code
            or "public enum" in source_code
            or "public abstract class" in source_code
        ):
            return self._parse_bom_dsl(source_code, file_uuid)
        return []

    def raw_token_count_estimator(self, metadata: Metadata, tokenizer: Tokenizer, source_code: str) -> int:
        if not metadata.interfaces:
            return 0
        per_iface = tokenizer.count_tokens(source_code)
        phrase_calls = sum(len(iface.methods) for iface in metadata.interfaces)
        return per_iface * len(metadata.interfaces) + per_iface * phrase_calls

    def _parse_bom_dsl(self, source_code: str, file_uuid: str) -> List[Interface]:
        interfaces: List[Interface] = []
        package = self._extract_package(source_code) or ""
        lines = source_code.splitlines()
        n = len(lines)
        i = 0

        while i < n:
            line = lines[i]
            class_match = _BOM_CLASS_HEADER_RE.match(line.strip())
            enum_match = None if class_match else _BOM_ENUM_HEADER_RE.match(line.strip())
            if not class_match and not enum_match:
                i += 1
                continue

            if enum_match:
                class_name = enum_match.group(1)
                extends: List[str] = []
                is_enum = True
                is_domain = False
            else:
                class_name = class_match.group(4)
                extends = [class_match.group(5)] if class_match.group(5) else []
                is_enum = bool(class_match.group(3))
                is_domain = False

            start_line = i + 1
            i += 1
            preamble_lines: List[str] = []
            while i < n and "{" not in lines[i]:
                preamble_lines.append(lines[i])
                i += 1

            depth = 0
            body_lines: List[str] = []
            while i < n:
                body_line = lines[i]
                depth += body_line.count("{") - body_line.count("}")
                body_lines.append(body_line)
                if depth <= 0:
                    break
                i += 1

            preamble = "\n".join(preamble_lines)
            body = "\n".join(body_lines)
            attributes, methods, has_domain_block = self._parse_bom_dsl_body(body, preamble, class_name, start_line, package)

            if not enum_match:
                is_enum = is_enum or self._looks_like_enum_class(attributes)
                is_domain = has_domain_block or self._has_domain_provider_metadata(methods, attributes) or self._looks_like_domain_class(class_name, attributes)

            if is_enum and not extends:
                extends = ["enumeration"]
            if is_domain and "domain" not in extends:
                extends = [*extends, "domain"]

            end_line = start_line + max(len(body_lines), 1) - 1
            iface = Interface(name=class_name, start_line=start_line, start_column=1, end_line=end_line, end_column=1, is_exported=True, extends=extends, attributes=attributes, methods=methods)
            iface.key = consistent_key_uuid(f"{file_uuid}-bom-{class_name}")
            interfaces.append(iface)
            i += 1

        self._annotate_domain_field_types(interfaces)
        return self._finalize_bom_interfaces(interfaces, package, file_uuid)

    def _finalize_bom_interfaces(self, interfaces: List[Interface], package: str, file_uuid: str) -> List[Interface]:
        pkg = (package or "").strip()
        bom_types: List[OdmBomType] = []
        for iface in interfaces:
            self._assign_interface_method_keys(iface, file_uuid)
            bom_types.append(OdmBomType(interface_key=iface.key, details=build_odm_bom_type_details(iface, pkg)))
        self._bom_types = bom_types
        return interfaces

    def _assign_interface_method_keys(self, iface: Interface, file_uuid: str) -> None:
        class_name = iface.name or "UnnamedBomType"
        for method in iface.methods or []:
            if method.key:
                continue
            method.key = consistent_key_uuid(f"{file_uuid}-bom-{class_name}-{method.name}")

    def _looks_like_enum_class(self, attributes: List[ClassAttribute]) -> bool:
        member_attrs = [attr for attr in attributes if attr.type != "domain-static-ref"]
        if not member_attrs:
            return False
        return all(attr.type.endswith("-enum-value") for attr in member_attrs)

    def _has_domain_provider_metadata(self, methods: List[ClassMethod], attributes: List[ClassAttribute]) -> bool:
        if any(method.return_type == "domain-provider-property" for method in methods):
            return True
        return any(attr.type == "domain-static-ref" for attr in attributes)

    def _looks_like_domain_class(self, class_name: str, attributes: List[ClassAttribute]) -> bool:
        lowered = class_name.lower()
        if not (lowered.endswith("values") or lowered.endswith("domain")):
            return False
        return bool(attributes)

    def _annotate_domain_field_types(self, interfaces: List[Interface]) -> None:
        class_names = {iface.name for iface in interfaces}
        referenced_as_domain: Set[str] = set()
        for iface in interfaces:
            for attr in iface.attributes:
                base_type = attr.type.split(":")[0].replace("-enum-value", "")
                if base_type in class_names and base_type != iface.name:
                    attr.type = f"{base_type}:domain-ref"
                    referenced_as_domain.add(base_type)
        for iface in interfaces:
            if iface.name in referenced_as_domain and "domain" not in iface.extends:
                iface.extends.append("domain")

    def _field_modifiers(self, line: str) -> Tuple[bool, bool]:
        lowered = line.lower()
        return "static" in lowered and "final" in lowered, "static" in lowered

    def _parse_bom_dsl_body(self, body: str, preamble: str, class_name: str, base_line: int, package: str) -> Tuple[List[ClassAttribute], List[ClassMethod], bool]:
        attributes: List[ClassAttribute] = []
        methods: List[ClassMethod] = []
        seen_names: Set[str] = set()
        line_offset = base_line
        has_domain_block = False

        for prop_match in _BOM_CLASS_PROPERTY_RE.finditer(preamble):
            prop_key = prop_match.group(1).strip()
            prop_value = prop_match.group(2).strip()
            prop_label = prop_key.rsplit(".", 1)[-1] if "." in prop_key else prop_key
            if prop_label in seen_names:
                continue
            seen_names.add(prop_label)
            methods.append(ClassMethod(name=f"{prop_key}={prop_value}", class_name=class_name, parameters=[], return_type="domain-provider-property", start_line=line_offset, start_column=1, end_line=line_offset, end_column=1, calls=[]))
            line_offset += 1

        for domain_pattern in (_BOM_DOMAIN_BLOCK_BRACE_RE, _BOM_DOMAIN_BLOCK_PAREN_RE):
            for domain_match in domain_pattern.finditer(body):
                has_domain_block = True
                for ref_match in _BOM_DOMAIN_STATIC_REF_RE.finditer(domain_match.group(1)):
                    ref_name = ref_match.group(1)
                    if ref_name in seen_names:
                        continue
                    seen_names.add(ref_name)
                    attributes.append(ClassAttribute(name=ref_name, type="domain-static-ref", start_line=line_offset, start_column=1, end_line=line_offset, end_column=1))
                    line_offset += 1

        for method_match in _BOM_METHOD_RE.finditer(body):
            method_name = method_match.group(2)
            if method_name in seen_names or method_name == class_name:
                continue
            seen_names.add(method_name)
            params_str = method_match.group(3).strip()
            params = [Parameter(name=part.strip().split()[-1], type=part.strip().split()[0] if " " in part.strip() else "any", optional=False) for part in params_str.split(",") if part.strip()]
            methods.append(ClassMethod(name=method_name, class_name=class_name, parameters=params, return_type=method_match.group(1), start_line=line_offset, start_column=1, end_line=line_offset, end_column=1, calls=[]))
            line_offset += 1

        for field_match in _BOM_FIELD_RE.finditer(body):
            field_line = field_match.group(0)
            field_name = field_match.group(2)
            field_type = field_match.group(1)
            is_static_final, is_static = self._field_modifiers(field_line)
            if field_name in seen_names or field_name in ("static", "final", "readonly"):
                continue
            seen_names.add(field_name)
            stored_type = field_type
            if is_static_final or (is_static and field_name.startswith("_")):
                stored_type = f"{field_type}-enum-value"
            attributes.append(ClassAttribute(name=field_name, type=stored_type, start_line=line_offset, start_column=1, end_line=line_offset, end_column=1))
            line_offset += 1

        for verb_match in _BOM_VERBALIZATION_RE.finditer(body):
            phrase = verb_match.group(1).strip()
            if phrase in seen_names:
                continue
            seen_names.add(phrase)
            methods.append(ClassMethod(name=phrase, class_name=class_name, parameters=[], return_type="verbalization", start_line=line_offset, start_column=1, end_line=line_offset, end_column=1, calls=[]))
            line_offset += 1

        return attributes, methods, has_domain_block

    def _parse_voc_properties(self, source_code: str, file_uuid: str) -> List[Interface]:
        interfaces: List[Interface] = []
        phrase_priority = {"action": 0, "condition": 1, "navigation": 2}
        best_phrase: Dict[str, Dict[str, Tuple[int, str]]] = {}

        for phrase_match in _VOC_PHRASE_RE.finditer(source_code):
            class_fqn = phrase_match.group(1)
            field_name = phrase_match.group(2)
            phrase_type = phrase_match.group(3)
            phrase_text = phrase_match.group(4).strip()
            priority = phrase_priority.get(phrase_type, 99)
            existing = best_phrase.setdefault(class_fqn, {}).get(field_name)
            if existing is None or priority < existing[0]:
                best_phrase[class_fqn][field_name] = (priority, phrase_text)

        instances: Dict[str, List[Tuple[str, str]]] = {}
        for instance_match in _VOC_INSTANCE_RE.finditer(source_code):
            class_fqn = instance_match.group(1)
            inst_name = instance_match.group(2)
            label = instance_match.group(3).strip()
            instances.setdefault(class_fqn, []).append((inst_name, label))

        for concept_match in _VOC_CONCEPT_RE.finditer(source_code):
            class_fqn = concept_match.group(1)
            concept_label = concept_match.group(2).strip()
            class_name = class_fqn.split(".")[-1]
            start_line = source_code[: concept_match.start()].count("\n") + 1

            attributes: List[ClassAttribute] = []
            methods: List[ClassMethod] = []
            attr_line = start_line

            methods.append(ClassMethod(name=concept_label, class_name=class_name, parameters=[], return_type="concept-label", start_line=attr_line, start_column=1, end_line=attr_line, end_column=1, calls=[]))
            attr_line += 1

            for inst_name, label in instances.get(class_fqn, []):
                attributes.append(ClassAttribute(name=inst_name, type=f"{label}-enum-value", start_line=attr_line, start_column=1, end_line=attr_line, end_column=1))
                attr_line += 1

            for field_name, (_priority, phrase_text) in best_phrase.get(class_fqn, {}).items():
                methods.append(ClassMethod(name=phrase_text, class_name=class_name, parameters=[], return_type="phrase", start_line=attr_line, start_column=1, end_line=attr_line, end_column=1, calls=[]))
                attr_line += 1

            extends: List[str] = []
            if attributes and all(attr.type.endswith("-enum-value") for attr in attributes):
                extends = ["enumeration"]

            iface = Interface(name=class_name, start_line=start_line, start_column=1, end_line=attr_line, end_column=1, is_exported=True, extends=extends, attributes=attributes, methods=methods)
            iface.key = consistent_key_uuid(f"{file_uuid}-bom-{class_name}")
            interfaces.append(iface)

        package = self._extract_package(source_code) or ""
        return self._finalize_bom_interfaces(interfaces, package, file_uuid)
