"""
Rule Package parser for IBM ODM .rulepackage files.

Each rule package folder contains a hidden .rulepackage file that declares the
package namespace.

Mapping:
  The RulePackage → one Class (name = package name, no methods)
"""

import logging
import xml.etree.ElementTree as ET
from typing import List

from ...models import Class, Metadata
from ...utils import Tokenizer, consistent_key_uuid
from ...base_odm_parser import BaseODMParser
from ...source_positions import parse_xml_root
from ...xml_utils import find_first_el

logger = logging.getLogger(__name__)


class RulePackageParser(BaseODMParser):
    """Parses IBM ODM .rulepackage XML into standard Metadata."""

    def _get_language_name(self) -> str:
        return "odm_rulepackage"

    def _extract_classes(self, source_code: str, file_uuid: str) -> List[Class]:
        try:
            root = parse_xml_root(source_code)
        except ET.ParseError as exc:
            logger.warning(f"RulePackageParser: XML parse error — {exc}")
            return []

        name_el = find_first_el(root, "name")
        pkg_name = (
            name_el.text.strip()
            if name_el is not None and name_el.text
            else "UnnamedPackage"
        )

        cls = Class(
            name=pkg_name,
            start_line=1,
            start_column=1,
            end_line=1,
            end_column=0,
            methods=[],
            attributes=[],
            extends=[],
            implements=[],
        )
        cls.key = consistent_key_uuid(f"{file_uuid}-pkg-{pkg_name}")
        return [cls]

    def raw_token_count_estimator(
        self, metadata: Metadata, tokenizer: Tokenizer, source_code: str
    ) -> int:
        return tokenizer.count_tokens(source_code) * len(metadata.classes)
