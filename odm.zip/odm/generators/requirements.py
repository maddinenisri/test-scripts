"""
Requirements-document generator.

Turns the resolved operation traces (the `odm` module's "what runs" model) into
human-readable Markdown requirements — one document per decision-service operation,
including each rule's actual authored logic (BAL ``IF…THEN…`` for ``.brl``/``.trl``,
column+row tables for ``.dta`` decision tables) and the BOM data dictionary.

This reuses the workspace resolution (nested/qualified packages, cross-project),
so the generated docs match what `odm-trace` reports.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import List, Optional

from .. import xml_utils
from ..source_positions import parse_xml_root
from ..workspace import Workspace
from ..operation_trace import OperationTrace, TraceStep, assign_unique_slugs

logger = logging.getLogger(__name__)


def _abs(ws: Workspace, rel_path: Optional[str]) -> Optional[Path]:
    return (ws.root / rel_path) if rel_path else None


def _read_brl_logic(path: Optional[Path]):
    """Return (documentation, definition) authored text for a .brl/.trl/.fct file."""
    if not path or not path.exists():
        return None, None
    try:
        root = parse_xml_root(path.read_text(encoding="utf-8"))
    except Exception:
        return None, None
    return xml_utils.extract_documentation(root), xml_utils.element_text(root, "definition")


def _decision_table(ws: Workspace, uuid: Optional[str]):
    """Return the parsed OdmDecisionTable + its rows for a resolved .dta rule, if any."""
    wf = ws.rules_by_uuid.get(uuid or "")
    if wf is None or wf.metadata.odm_file_metadata is None:
        return None, []
    ofm = wf.metadata.odm_file_metadata
    table = ofm.decision_tables[0] if ofm.decision_tables else None
    return table, ofm.decision_table_rows


_BOUND_OPS = (("is at least", "≥"), ("is at most", "≤"),
              ("is more than", ">"), ("is less than", "<"))


def _tidy_cell(v: str) -> str:
    """Simplify open-ended range cells like '900 is at least 900' -> '≥ 900'."""
    v = (v or "").strip()
    for phrase, sym in _BOUND_OPS:
        m = re.match(rf"^(\S+)\s+{phrase}\s+(\S+)$", v)
        if m and m.group(1) == m.group(2):
            return f"{sym} {m.group(2)}"
        m = re.match(rf"^{phrase}\s+(.+)$", v)
        if m:
            return f"{sym} {m.group(1)}"
    return v


def _collect_drivers(ws: Workspace, trace):
    """Find input fields the rules' conditions branch on (the decision drivers)."""
    from collections import Counter
    counter: Counter = Counter()
    seen = set()
    for s in trace.steps:
        for r in _all_rules(s):
            key = r.uuid or (r.project, r.file, r.name)
            if key in seen:
                continue
            seen.add(key)
            if r.kind == "DecisionTable":
                table, rows = _decision_table(ws, r.uuid)
                for col in dict.fromkeys(a.field for row in rows for a in row.conditions):
                    counter[(col, "decision table")] += 1
                continue
            _, defn = _read_brl_logic(_abs(ws, r.file))
            cond = split_bal(defn).get("if", "") if defn else ""
            for m in re.finditer(r"the ([a-z][\w ]*?) of 'the ([\w ]+)'", cond, re.I):
                counter[(m.group(1).strip(), m.group(2).strip())] += 1
    return counter.most_common()


def split_bal(text: str) -> dict:
    """Split a BAL/IRL rule body into definitions/if/then/else sections.

    Sections are delimited by a bare keyword line (`definitions`, `if`, `then`,
    `else`). Text before any keyword is `preamble` (e.g. technical/init rules with
    no if/then). Returns a dict with the sections that are present.
    """
    sections, cur, buf = {}, "preamble", []
    for line in (text or "").splitlines():
        kw = line.strip().lower().rstrip(":")
        if kw in ("definitions", "if", "then", "else"):
            body = "\n".join(buf).strip()
            if body:
                sections[cur] = body
            buf, cur = [], kw
        else:
            buf.append(line)
    body = "\n".join(buf).strip()
    if body:
        sections[cur] = body
    return sections


def _fmt_block(text: str) -> str:
    lines = [ln.rstrip() for ln in (text or "").splitlines() if ln.strip()]
    return "\n".join(lines)


def _fmt_bal(text: str) -> str:
    """Collapse a BAL definition into a tidy fenced block."""
    lines = [ln.rstrip() for ln in (text or "").splitlines() if ln.strip()]
    return "```\n" + "\n".join(lines) + "\n```"


def _render_rule(ws: Workspace, rule) -> List[str]:
    out = [f"### {rule.name}", ""]
    meta = []
    if rule.project:
        meta.append(f"project `{rule.project}`")
    if rule.file:
        meta.append(f"source `{rule.file}`")
    if meta:
        out.append("_" + " · ".join(meta) + "_")
        out.append("")

    if rule.kind == "DecisionTable":
        table, rows = _decision_table(ws, rule.uuid)
        if table is not None:
            conds = [a.field for r in rows for a in r.conditions]
            acts = [a.field for r in rows for a in r.actions]
            cond_cols = list(dict.fromkeys(conds))
            act_cols = list(dict.fromkeys(acts))
            out.append(f"Decision table — {len(rows)} row(s); "
                       f"conditions ({', '.join(cond_cols) or '—'}) → "
                       f"actions ({', '.join(act_cols) or '—'}).")
            out.append("")
            if rows:
                header = ["#"] + cond_cols + ["→"] + act_cols
                out.append("| " + " | ".join(header) + " |")
                out.append("| " + " | ".join("---" for _ in header) + " |")
                for r in rows[:60]:
                    cmap = {a.field: _tidy_cell(a.value) for a in r.conditions}
                    amap = {a.field: a.value for a in r.actions}
                    cells = ([str(r.row_index)]
                             + [cmap.get(c, "") for c in cond_cols]
                             + ["→"]
                             + [amap.get(c, "") for c in act_cols])
                    out.append("| " + " | ".join(str(x) for x in cells) + " |")
                if len(rows) > 60:
                    out.append(f"| …{len(rows) - 60} more rows | | | | |")
            out.append("")
            return out

    # ActionRule / TechnicalRule / Function -> authored BAL text, applicability-first
    doc, defn = _read_brl_logic(_abs(ws, rule.file))
    if doc:
        out.append(f"> {doc}")
        out.append("")
    if not defn:
        out.append("_(logic not available as source — may be a function or built artifact)_")
        out.append("")
        return out

    sections = split_bal(defn)
    if "if" in sections:
        out.append("**Applies when:**")
        out.append("```")
        out.append(_fmt_block(sections["if"]))
        out.append("```")
        if "definitions" in sections:
            out.append(f"_Setup:_ `{_fmt_block(sections['definitions']).replace(chr(10), ' ')}`")
        if "then" in sections:
            out.append("**Then:**")
            out.append("```")
            out.append(_fmt_block(sections["then"]))
            out.append("```")
        if "else" in sections:
            out.append("**Otherwise:**")
            out.append("```")
            out.append(_fmt_block(sections["else"]))
            out.append("```")
    else:
        # no condition — unconditional / initialization (e.g. technical .trl rules)
        kind_note = "Initialization (technical rule) — always runs" if rule.kind == "TechnicalRule" \
            else "Always applies (unconditional)"
        out.append(f"_{kind_note}._")
        out.append("```")
        out.append(_fmt_block(defn))
        out.append("```")
    out.append("")
    return out


def _process_lines(steps: List[TraceStep], depth: int = 0) -> List[str]:
    out = []
    pad = "    " * depth
    for s in steps:
        bullet = f"{s.order}. " if s.order is not None else "- "
        if s.kind == "Rule":
            names = ", ".join(r.name for r in s.rules) or "_no rules in source (see Gaps)_"
            out.append(f"{pad}{bullet}**{s.task}** — apply rules: {names}")
        elif s.kind == "Subflow":
            tag = "" if (s.subflow and s.subflow.resolved) else " _(unresolved)_"
            out.append(f"{pad}{bullet}**{s.task}** — sub-flow `{s.subflow.name if s.subflow else '?'}`{tag}")
            out += _process_lines(s.substeps, depth + 1)
        else:
            act = (s.action_irl or "").replace("\n", " ").strip()
            out.append(f"{pad}{bullet}**{s.task}** — action{(': ' + act) if act else ''}")
    return out


def render_operation_md(ws: Workspace, trace: OperationTrace) -> str:
    op = ws.operations_by_uuid.get(trace.uuid or "", (None, None))[1]
    L: List[str] = [f"# {trace.operation} — Decision Service Requirements", ""]

    L.append(f"- **Ruleset:** {trace.ruleset_name or '—'}")
    if trace.ruleflow:
        L.append(f"- **Ruleflow:** {trace.ruleflow.name}  (`{trace.ruleflow.file}`)")
    else:
        L.append(f"- **Execution:** {trace.execution_kind}")
    L.append(f"- **Target project:** {trace.target_project or '—'}")
    if trace.deployments:
        deps = ", ".join((d.ruleapp or "?") + (" [production]" if d.production else "") for d in trace.deployments)
        L.append(f"- **Shipped in:** {deps}")
    L.append("")

    L += ["## Purpose", ""]
    L.append((op.description.strip() if op and op.description else "_No description provided in the source._"))
    L.append("")

    L += ["## Inputs / Outputs", "", "| Dir | Name | Type | Business name |", "| --- | --- | --- | --- |"]
    for v in trace.inputs + [o for o in trace.outputs if o.direction == "OUT"]:
        L.append(f"| {v.direction} | `{v.name}` | `{v.type or '?'}` | {v.verbalization or ''} |")
    L.append("")

    if trace.variable_sets:
        L += ["## Operation Variable Sets", "",
              "_The `.dop` operation signature references variables from these `.var` files. "
              "This is the declared ODM service contract; working-memory facts used by rules are listed separately when visible in rule logic._", ""]
        for vs in trace.variable_sets:
            L.append(f"**{vs.name or 'variables'}** — `{vs.file or ''}` `{vs.uuid or ''}`")
            L.append("")
            L.append("| Direction | Variable | Type | Verbalization | Initial value |")
            L.append("| --- | --- | --- | --- | --- |")
            for v in vs.variables:
                init = (v.initial_value or "").replace("|", "\\|")
                L.append(f"| {v.direction} | `{v.name}` | `{v.type or '?'}` | {v.verbalization or ''} | `{init}` |")
            L.append("")

    artifacts = trace.source_artifacts
    if any(getattr(artifacts, f) for f in ("bom", "b2xa", "voc", "xom_java", "xom_libraries")):
        L += ["## Contract Source Artifacts", "",
              "_Files used to understand operation variables, business vocabulary, execution mappings, and XOM shape._", ""]
        groups = [
            ("BOM", artifacts.bom),
            ("B2XA", artifacts.b2xa),
            ("VOC", artifacts.voc),
            ("XOM Java", artifacts.xom_java),
            ("XOM libraries", artifacts.xom_libraries),
        ]
        for title, files in groups:
            if files:
                L.append(f"**{title}**")
                for f in files:
                    L.append(f"- `{f}`")
                L.append("")

    L += ["## Process", ""]
    L += _process_lines(trace.steps) or ["_No steps resolved._"]
    L.append("")

    drivers = _collect_drivers(ws, trace)
    if drivers:
        L += ["## Decision drivers (input fields that gate execution)", "",
              "_Input fields the rules' conditions branch on — i.e. what about the "
              "incoming data determines which rules apply._", ""]
        for (field, obj), n in drivers[:12]:
            L.append(f"- **{field}** of *{obj}* — gates {n} rule(s)")
        L.append("")

    L += ["## Business rules", ""]
    seen = set()
    for s in trace.steps:
        for r in _all_rules(s):
            key = r.uuid or (r.project, r.file, r.name)
            if key in seen:
                continue
            seen.add(key)
            L += _render_rule(ws, r)
    if not seen:
        if trace.execution_kind == "query-extractor":
            L += ["_This operation selects rules by query from its target project; no "
                  "rule source was found in the scanned workspace. Point at the parent "
                  "folder that contains the rule project to include them._", ""]
        else:
            L += ["_No rules resolved for this operation._", ""]

    if trace.type_schemas:
        L += ["## Data dictionary", ""]
        for qn, ts in trace.type_schemas.items():
            if ts.enum_values:
                L.append(f"**{qn}** _(enumeration)_")
                for ev in ts.enum_values:
                    desc = ev.description or ev.summary or ""
                    label = f" — {ev.title}" if ev.title and ev.title != ev.value else ""
                    tail = f": {desc}" if desc else ""
                    L.append(f"- `{ev.value}`{label}{tail}")
                L.append("")
                continue
            L.append(f"**{qn}**")
            for f in ts.fields:
                ref = " → see above" if f.bom else ""
                coll = "[]" if f.collection else ""
                L.append(f"- `{f.name}`: {f.type}{coll}{ref}")
            L.append("")

    L += ["## Traceability", "", "| Rule | Kind | Project | Source | UUID |", "| --- | --- | --- | --- | --- |"]
    trace_rows = 0
    for s in trace.steps:
        for r in _all_rules(s):
            L.append(f"| {r.name} | {r.kind} | {r.project or ''} | `{r.file or ''}` | `{r.uuid or ''}` |")
            trace_rows += 1
    if trace_rows == 0:
        L.append("| _no rules_ | | | | |")
    L.append("")

    if trace.unresolved_refs:
        L += ["## Gaps (referenced but not found in source)", ""]
        for u in trace.unresolved_refs:
            L.append(f"- **{u.kind}** `{u.value}` (in task `{u.where}`) — in production this contributes no rules.")
        L.append("")

    return "\n".join(L)


def _all_rules(step: TraceStep):
    yield from step.rules
    for ss in step.substeps:
        yield from _all_rules(ss)


def _slug(name: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in name).strip("_").lower() or "operation"


def generate_requirements(ws: Workspace, traces: List[OperationTrace], out_dir) -> List[Path]:
    """Write one requirements .md per operation plus an index; return written paths."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    written = []
    index = ["# Decision Service Requirements", "",
             f"Generated from `{ws.root}` — {len(traces)} operation(s).", ""]
    for t, slug in assign_unique_slugs(traces):
        fn = f"{slug}.md"
        (out / fn).write_text(render_operation_md(ws, t), encoding="utf-8")
        written.append(out / fn)
        rules = t.stats.get("rule_refs", 0)
        flow = t.ruleflow.name if t.ruleflow else f"({t.execution_kind})"
        proj = f" — {t.target_project}" if t.target_project else ""
        index.append(f"- [{t.operation}]({fn}) — flow `{flow}`, {rules} rule(s){proj}")
    (out / "index.md").write_text("\n".join(index) + "\n", encoding="utf-8")
    logger.info("Wrote %d requirements document(s) to %s", len(written), out)
    return written
