"""
Track B — merge ODM execution traces into the static model -> execution-grounded
requirements.

Ingests `(input_id, operation, fired_rules[], output)` records (captured from ODM via
the HTDS `__TraceFilter__`, see docs/guide/track-b-execution-trace.md) and annotates
each operation with what was **observed** to run:
  - per-rule coverage: which inputs fired it;
  - never-fired rules across the corpus (dead/rare-logic candidates);
  - per-input executed path + output.

This is the tool side of Track B. It needs no ODM at author time — it merges trace
files. The traces themselves are produced by ODM (the engine is the oracle).
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from pathlib import Path
from typing import Dict, List

from ..workspace import Workspace
from ..operation_trace import OperationTrace, assign_unique_slugs
from .requirements import _all_rules

logger = logging.getLogger(__name__)


def _norm(s: str) -> str:
    return "".join(c.lower() for c in (s or "") if c.isalnum())


def _qualified(rule) -> str:
    """Source-folder-relative dotted name from the rule's file path.

    e.g. rules/fraudReview/scoringEngine/init.trl -> fraudReview.scoringEngine.init
    """
    parts = (rule.file or "").split("/")
    if parts and parts[0].lower() in ("rules", "src"):
        parts = parts[1:]
    if parts:
        parts[-1] = parts[-1].rsplit(".", 1)[0]
    return ".".join(parts)


TIERS = ("uuid", "qual", "name")  # most specific -> least


def _rule_tiers(rule) -> dict:
    """A static rule's identity keys split by specificity tier."""
    q = _qualified(rule)
    return {
        "uuid": {_norm(rule.uuid)} if rule.uuid else set(),
        "qual": {_norm(q)} if q else set(),
        "name": {_norm(rule.name)},
    }


def _fired_tiers(entry) -> dict:
    """A fired-rule entry's keys split by tier — a bare string, or {name,uuid,path,...}."""
    uuid, qual, name = set(), set(), set()
    if isinstance(entry, dict):
        for k in ("uuid", "id", "ruleId"):
            if entry.get(k):
                uuid.add(_norm(str(entry[k])))
        for k in ("path", "rulePath"):
            if entry.get(k):
                qual.add(_norm(str(entry[k])))
        for k in ("name", "ruleName", "businessName"):
            v = entry.get(k)
            if v:
                (qual if "." in str(v) else name).add(_norm(str(v)))
    else:
        s = str(entry)
        (qual if "." in s else name).add(_norm(s))
    return {"uuid": uuid, "qual": qual, "name": name}


def _fired_label(entry) -> str:
    if isinstance(entry, dict):
        return entry.get("name") or entry.get("ruleName") or entry.get("path") or entry.get("uuid") or "?"
    return str(entry)


def load_trace_records(path) -> List[dict]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return data if isinstance(data, list) else data.get("records", [data])


def _static_rules(trace: OperationTrace):
    out, seen = [], set()
    for s in trace.steps:
        for r in _all_rules(s):
            k = r.uuid or r.name
            if k not in seen:
                seen.add(k)
                out.append(r)
    return out


def merge_execution(ws: Workspace, traces: List[OperationTrace], records: List[dict], out_dir) -> List[Path]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    by_op: Dict[str, list] = defaultdict(list)
    for r in records:
        by_op[_norm(r.get("operation", ""))].append(r)

    written = []
    for t, slug in assign_unique_slugs(traces):
        recs = by_op.get(_norm(t.operation), [])
        rules = _static_rules(t)
        rtiers = [(r, _rule_tiers(r)) for r in rules]
        fired_inputs: Dict[str, set] = defaultdict(set)  # rule key -> set(input_id)
        ambiguous_hits: set = set()
        for rec in recs:
            iid = str(rec.get("input_id", "?"))
            for entry in rec.get("fired_rules", []):
                ftier = _fired_tiers(entry)
                # attribute at the most specific tier that yields any match
                for tier in TIERS:
                    fk = ftier[tier]
                    if not fk:
                        continue
                    matches = [r for r, rt in rtiers if rt[tier] & fk]
                    if not matches:
                        continue
                    for r in matches:
                        fired_inputs[r.uuid or r.name].add(iid)
                    if tier == "name" and len(matches) > 1:
                        ambiguous_hits.add(_fired_label(entry))
                    break

        L = [f"# {t.operation} — Execution-grounded requirements", ""]
        L.append(f"_Observed from {len(recs)} execution(s) (ODM `__TraceFilter__` traces). "
                 "Static applicability is in the requirements doc; this shows what actually ran._")
        L.append("")

        if not recs:
            L += ["_No execution traces provided for this operation. Run inputs through ODM "
                  "(see docs/guide/track-b-execution-trace.md) and re-merge._", ""]
        else:
            # disambiguate display when a bare name repeats — show the qualified path
            dup = {n for n, c in {
                nm: sum(1 for r in rules if r.name == nm) for nm in {r.name for r in rules}
            }.items() if c > 1}
            label = lambda r: (_qualified(r) or r.name) if r.name in dup else r.name

            L += ["## Rule coverage (observed)", "",
                  "| Rule | Fired for input(s) | # |", "| --- | --- | --- |"]
            for r in rules:
                ids = sorted(fired_inputs.get(r.uuid or r.name, []))
                cell = ", ".join(ids) if ids else "_never_"
                L.append(f"| {label(r)} | {cell} | {len(ids)} |")
            L.append("")

            never = [label(r) for r in rules if not fired_inputs.get(r.uuid or r.name)]
            if never:
                L += ["## Never fired across the corpus", "",
                      "_Exists in the ruleset but did not execute for any sampled input — "
                      "dead, rare, or needs an input that wasn't covered._", ""]
                L += [f"- {n}" for n in never] + [""]

            if ambiguous_hits:
                L += ["## ⚠ Ambiguous attribution", "",
                      "_These rule names occur on more than one rule, and the trace identified "
                      "them by bare name only — the firing was attributed to every rule with that "
                      "name. Emit qualified names or UUIDs in `fired_rules` to disambiguate "
                      "(see docs/guide/track-b-execution-trace.md)._", ""]
                L += [f"- {n}" for n in sorted(ambiguous_hits)] + [""]

            L += ["## Executed path per input", ""]
            for rec in recs:
                iid = rec.get("input_id", "?")
                L.append(f"### Input `{iid}`")
                fired = [_fired_label(x) for x in rec.get("fired_rules", [])]
                L.append("- **Fired (in order):** " + (", ".join(fired) if fired else "_none_"))
                if "output" in rec:
                    L.append("- **Output:** `" + json.dumps(rec["output"]) + "`")
                L.append("")

        path = out / f"{slug}.execution.md"
        path.write_text("\n".join(L), encoding="utf-8")
        written.append(path)

    logger.info("Wrote %d execution-grounded doc(s) to %s", len(written), out)
    return written
