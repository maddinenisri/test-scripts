"""
LLM prompt-bundle generator.

For each decision-service operation, assembles a single self-contained prompt that
an LLM can turn into a requirements document / PRD. The bundle contains:

  1. INSTRUCTIONS  — role + task + grounding rules (don't invent; mark gaps).
  2. GROUNDED FACTS — the human-readable requirements rendering (data contract,
     decision process, every rule's actual logic, data dictionary, gaps).
  3. MACHINE-READABLE TRACE — the operation's JSON, so the model has the exact
     structured facts (typed I/O, resolved rules with files/UUIDs, type schemas).

The output is deterministic and offline — it does NOT call any LLM. You paste a
`<operation>.prompt.md` into your model of choice (or feed it programmatically).
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import List

from ..workspace import Workspace
from ..operation_trace import OperationTrace, assign_unique_slugs
from .requirements import render_operation_md

logger = logging.getLogger(__name__)

INSTRUCTIONS = """\
# Task: write a requirements document (PRD) for an IBM ODM decision service

You are a senior business analyst. Using ONLY the grounded facts below, write a
clear Product Requirements Document for this decision service.

## Grounding rules (important)
- The **GROUNDED FACTS** and the **MACHINE-READABLE TRACE** are the single source of
  truth for *what the service does*: its inputs/outputs, the ordered process, and the
  exact business rules (with their logic). **Do not invent, drop, rename, or alter**
  any rule, field, type, threshold, or step. Quote rule logic faithfully.
- You MAY add the business *why* — purpose, rationale, scope, stakeholders,
  non-functional requirements, assumptions, edge cases, acceptance criteria — but
  label every such inference **(inferred — confirm)** so reviewers know it is not
  from the source.
- Anything under **Gaps** is referenced by the rules but missing from the source.
  Surface each as an explicit **open question / risk** (in production it runs no
  rules), do not silently ignore it.
- Restate each rule in plain business English next to its literal logic.

## Produce these sections
1. Overview (one paragraph)
2. Background & rationale *(inferred — confirm)*
3. Scope (in / out) *(inferred — confirm)*
4. Stakeholders *(inferred — confirm)*
5. Data contract — inputs/outputs (from facts) + field notes
6. Decision process — the ordered steps (from facts)
7. Business rules — for each: literal logic (from facts) + plain-English meaning +
   rationale *(inferred — confirm)*
8. Non-functional requirements *(inferred — confirm)*
9. Assumptions & constraints *(inferred — confirm)*
10. Edge cases & open questions — include every Gap
11. Acceptance criteria / test scenarios — a passing and a failing case per rule
12. Traceability — keep the rule → source file → UUID table verbatim

Write in clear, reviewable prose. Prefer tables for the data contract and rules.
"""


def facts_and_json(ws: Workspace, trace: OperationTrace) -> str:
    """The grounded-facts + embedded-JSON body (the LLM 'user' content)."""
    facts = render_operation_md(ws, trace)
    trace_json = trace.model_dump_json(indent=2)
    return "\n".join([
        "# GROUNDED FACTS (do not contradict)\n",
        "_The following is the tool-extracted requirements model — every line traces "
        "to a source file in the rule project._\n",
        facts,
        "\n---\n",
        "# MACHINE-READABLE TRACE (JSON)\n",
        "_The same operation as structured data: typed inputs/outputs, ordered steps, "
        "resolved rules (with source file + UUID), nested BOM type schemas, and any "
        "unresolved references._\n",
        "```json",
        trace_json,
        "```",
    ])


def render_prompt(ws: Workspace, trace: OperationTrace) -> str:
    """The full single-file prompt (instructions + facts + JSON) for copy-paste use."""
    return INSTRUCTIONS + "\n\n---\n\n" + facts_and_json(ws, trace)


def generate_prompts(ws: Workspace, traces: List[OperationTrace], out_dir) -> List[Path]:
    """Write one self-contained LLM prompt (.prompt.md) per operation + an index."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    written = []
    index = ["# LLM Prompts — one per decision service", "",
             f"Generated from `{ws.root}` — {len(traces)} service(s). Paste a file into "
             "your LLM to draft its requirements document; the facts + JSON are embedded.", ""]
    for t, slug in assign_unique_slugs(traces):
        fn = f"{slug}.prompt.md"
        (out / fn).write_text(render_prompt(ws, t), encoding="utf-8")
        written.append(out / fn)
        flow = t.ruleflow.name if t.ruleflow else f"({t.execution_kind})"
        proj = f" — {t.target_project}" if t.target_project else ""
        index.append(f"- [{t.operation}]({fn}) — flow `{flow}`, {t.stats.get('rule_refs', 0)} rule(s){proj}")
    (out / "index.md").write_text("\n".join(index) + "\n", encoding="utf-8")
    logger.info("Wrote %d LLM prompt(s) to %s", len(written), out)
    return written
