"""
LLM requirements generation against a local (Claude-compatible) endpoint.

For each operation, sends the grounded prompt bundle (instructions as the system
message, grounded facts + JSON as the user message) to a local LLM proxy and writes
the model's requirements document to `<out>/llm/<service>.md`.

Reuses the stdlib `odm_parser.llm` client (so the same local proxy convention serves
both modules): the proxy speaks the Anthropic `POST /v1/messages` API and handles
auth itself, so the client only needs the endpoint URL — no API key in the tool.
Configure via `--llm-url` / `--llm-model` or the `ODM_PARSER_LLM_URL` /
`ODM_PARSER_LLM_MODEL` environment variables (default `http://127.0.0.1:9001`).
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

from ..workspace import Workspace
from ..operation_trace import OperationTrace, assign_unique_slugs
from .prompt import INSTRUCTIONS, facts_and_json

logger = logging.getLogger(__name__)


def generate_llm(
    ws: Workspace,
    traces: List[OperationTrace],
    out_dir,
    base_url: Optional[str] = None,
    model: Optional[str] = None,
    max_tokens: Optional[int] = None,
) -> List[Path]:
    """Generate one requirements doc per operation via a local LLM endpoint."""
    try:
        from odm_parser.llm import LLMClient, LLMConfig, LLMError
    except Exception as exc:  # pragma: no cover - both packages ship together
        raise RuntimeError(
            "the LLM client (odm_parser.llm) is not importable; install the repo "
            f"with `pip install -e .` so both modules are available ({exc})"
        ) from exc

    cfg = LLMConfig.from_env()
    if base_url:
        cfg.base_url = base_url
    if model:
        cfg.model = model
    if max_tokens:
        cfg.max_tokens = max_tokens
    client = LLMClient(cfg)

    if not client.health():
        raise LLMError(
            f"LLM endpoint not reachable at {cfg.base_url} (GET /health failed). "
            "Start your local proxy, or pass --llm-url / set ODM_PARSER_LLM_URL."
        )
    logger.info("LLM endpoint OK at %s (model=%s)", cfg.base_url, cfg.model or "<proxy default>")

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    written: List[Path] = []
    for t, slug in assign_unique_slugs(traces):
        logger.info("LLM: drafting requirements for %r ...", t.operation)
        user = facts_and_json(ws, t)
        try:
            text = client.complete(user, system=INSTRUCTIONS)
        except LLMError as exc:
            logger.error("LLM failed for %s: %s", t.operation, exc)
            text = (f"# {t.operation} — requirements (LLM generation FAILED)\n\n"
                    f"> The local LLM endpoint errored: {exc}\n\n"
                    f"> Use the grounded prompt at `../prompts/{slug}.prompt.md` instead.")
        path = out / f"{slug}.md"
        path.write_text(text.rstrip() + "\n", encoding="utf-8")
        written.append(path)

    logger.info("Wrote %d LLM requirements doc(s) to %s", len(written), out)
    return written
