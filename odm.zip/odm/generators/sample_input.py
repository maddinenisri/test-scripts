"""
Sample-input generator (Track A).

Builds a representative **input object model** per operation from the resolved BOM
schema (the operation's input variables + their nested type schemas), as JSON. This
is the object shape the rules operate on *after* the input XML is converted to
objects — useful for documentation and as a seed for a test corpus.

Honest note: the on-the-wire **XML** structure is defined by the customer's XML
schema and the init `.trl` mapping (XML → objects), which is not derivable from the
BOM. So we emit the faithful **object model (JSON)**; the XML wire format is a
separate, customer-specific mapping.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Dict, List

from ..workspace import Workspace
from ..operation_trace import OperationTrace, assign_unique_slugs

logger = logging.getLogger(__name__)

_PRIMITIVE_EXAMPLE = {
    "int": 0, "java.lang.Integer": 0, "java.lang.Long": 0, "long": 0, "short": 0,
    "double": 0.0, "java.lang.Double": 0.0, "float": 0.0,
    "boolean": False, "java.lang.Boolean": False,
    "string": "string", "java.lang.String": "string",
    "java.util.Date": "2026-01-01", "date": "2026-01-01",
}


def _element_type(t: str):
    t = (t or "").strip()
    collection = t.endswith("[]") or "java.util.List" in t or "java.util.Collection" in t
    t = t.replace("[]", "").strip()
    return t, collection


def _example(type_name: str, schemas, seen) -> object:
    bare, coll = _element_type(type_name)
    schema = schemas.get(bare)
    if schema is not None and schema.enum_values:
        val = schema.enum_values[0].value
    elif schema is not None:  # concept -> nested object
        if bare in seen:
            val = {"$ref": bare}
        else:
            seen = seen | {bare}
            val = {f.name: _example(f.type, schemas, seen) for f in schema.fields}
    else:
        val = _PRIMITIVE_EXAMPLE.get(bare.lower(), _PRIMITIVE_EXAMPLE.get(bare, f"<{bare}>"))
    return [val] if coll else val


def build_sample_input(trace: OperationTrace) -> Dict[str, object]:
    schemas = trace.type_schemas
    return {v.name: _example(v.type or "string", schemas, set()) for v in trace.inputs}


def generate_sample_inputs(ws: Workspace, traces: List[OperationTrace], out_dir) -> List[Path]:
    """Write one representative input-object JSON per operation."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    written = []
    for t, slug in assign_unique_slugs(traces):
        sample = {
            "_operation": t.operation,
            "_note": ("Representative input OBJECT model (post XML->object conversion). "
                      "The wire XML format is defined by the project's XML schema and init .trl mapping."),
            "input": build_sample_input(t),
        }
        path = out / f"{slug}.input.json"
        path.write_text(json.dumps(sample, indent=2), encoding="utf-8")
        written.append(path)
    logger.info("Wrote %d sample input(s) to %s", len(written), out)
    return written
