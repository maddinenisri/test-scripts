"""
PRD-skeleton generator.

Emits a Product Requirements Document per decision-service operation with the
`[TOOL]` blocks pre-filled from the resolved trace (data contract, decision process,
rule logic, traceability, gaps) and `[ANALYST]` placeholders left for the team to
write the business *why*. Same structure as docs/guide/example-prd-miniloan.md.

Reuses the requirements generator's rule-logic rendering so the facts are identical.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import List

from ..workspace import Workspace
from ..operation_trace import OperationTrace, assign_unique_slugs
from .requirements import _all_rules, _process_lines, _render_rule

logger = logging.getLogger(__name__)

A = "`[ANALYST]`"
T = "`[TOOL]`"


def _unique_rules(trace: OperationTrace):
    seen, out = set(), []
    for s in trace.steps:
        for r in _all_rules(s):
            key = r.uuid or (r.project, r.file, r.name)
            if key not in seen:
                seen.add(key)
                out.append(r)
    return out


def render_prd_md(ws: Workspace, trace: OperationTrace) -> str:
    flow = trace.ruleflow.name if trace.ruleflow else trace.execution_kind
    deps = ", ".join((d.ruleapp or "?") + (" [production]" if d.production else "")
                     for d in trace.deployments) or "—"
    L: List[str] = [f"# {trace.operation} — Product Requirements Document (draft)", ""]
    L += [f"> **Tags:** {T} = grounded fact from the rule project (verbatim, traceable). "
          f"{A} = business context to write (replace the _italic placeholders_, then drop the tags).", ""]

    L += ["## 1. Overview", "",
          f"{A} _One paragraph: what this decision service does and why it exists._", "",
          f"{T} Operation **{trace.operation}** — ruleset `{trace.ruleset_name or '—'}`, "
          f"ruleflow `{flow}`, target project `{trace.target_project or '—'}`. Shipped in: {deps}.", ""]

    L += ["## 2. Background & rationale", "",
          f"{A} _Why this service exists; the policy/regulation it encodes._", ""]
    L += ["## 3. Scope", "", f"{A} _In scope / out of scope._", ""]
    L += ["## 4. Stakeholders", "",
          f"{A} _Product owner, policy owner, compliance, consuming systems._", ""]

    L += ["## 5. Interface — data contract", "", f"{T} Inputs / Outputs:", "",
          "| Dir | Name | Type | Business name |", "| --- | --- | --- | --- |"]
    for v in trace.inputs + [o for o in trace.outputs if o.direction == "OUT"]:
        L.append(f"| {v.direction} | `{v.name}` | `{v.type or '?'}` | {v.verbalization or ''} |")
    L.append("")
    if trace.type_schemas:
        L += [f"{T} Data dictionary:", ""]
        for qn, ts in trace.type_schemas.items():
            if ts.enum_values:
                vals = ", ".join(ev.value for ev in ts.enum_values[:12])
                more = " …" if len(ts.enum_values) > 12 else ""
                L.append(f"- **{qn}** _(enumeration)_: {vals}{more}")
            else:
                fields = ", ".join(f"{f.name}: {f.type}" for f in ts.fields)
                L.append(f"- **{qn}**: {fields}")
        L.append("")
    L += [f"{A} _Field-level constraints: required/optional, formats, valid ranges, units._", ""]

    L += ["## 6. Functional requirements — decision process", "",
          f"{T} The service runs, in order:", ""]
    L += _process_lines(trace.steps) or ["_No steps resolved._"]
    L += ["", f"{A} _Overall semantics: when is the outcome approve vs reject? "
          "How are reasons returned to the caller?_", ""]

    L += ["## 7. Business rules catalogue", "",
          f"{A} _For each rule, add **Why** (rationale · owner · change control)._", ""]
    rules = _unique_rules(trace)
    for i, r in enumerate(rules, 1):
        L.append(f"### R{i} — {r.name}")
        L.append("")
        L.append(T)
        body = [ln for ln in _render_rule(ws, r) if not ln.startswith("### ")]
        L += body
        L.append(f"{A} _**Why:** rationale · owner · change control._")
        L.append("")
    if not rules:
        if trace.execution_kind == "query-extractor":
            L += ["_Query-extractor operation; no rule source found in the scanned "
                  "workspace (point at the parent folder to include it)._", ""]
        else:
            L += ["_No rules resolved for this operation._", ""]

    L += ["## 8. Non-functional requirements", "",
          f"{A} _(the tool does not infer these — fill in):_",
          "- **Performance:** _decision latency target (e.g. p95 < 200 ms)_",
          "- **Availability:** _SLA and fallback behaviour on outage_",
          "- **Auditability:** _what to log per decision (rules fired, reasons)_",
          "- **Security & privacy:** _handling of personal/financial data_",
          "- **Consistency:** deterministic — identical inputs yield identical outputs.", ""]

    L += ["## 9. Assumptions & constraints", "",
          f"{A} _Upstream data sources, units/currency, who owns the thresholds._", ""]

    L += ["## 10. Edge cases & open questions", "",
          f"{A} _Boundary conditions, refer-vs-reject decisions, exception handling._", ""]
    if trace.unresolved_refs:
        L += [f"{T} **Gaps — referenced but not found in source (resolve these):**"]
        for u in trace.unresolved_refs:
            L.append(f"- {u.kind} `{u.value}` (task `{u.where}`) — contributes no rules in production.")
        L.append("")
    else:
        L += [f"{T} Gaps: none (`unresolved_total = 0`).", ""]

    L += ["## 11. Acceptance criteria / test scenarios", "",
          f"{A} _Define a passing and a failing case per rule:_", ""]
    for r in rules:
        L.append(f"- **{r.name}**: _given … when … then …_")
    if not rules:
        L.append("_None — no rules resolved._")
    L.append("")

    L += ["## 12. Traceability", "", T, "",
          "| Rule | Kind | Project | Source | UUID |", "| --- | --- | --- | --- | --- |"]
    for r in rules:
        L.append(f"| {r.name} | {r.kind} | {r.project or ''} | `{r.file or ''}` | `{r.uuid or ''}` |")
    if not rules:
        L.append("| _no rules_ | | | | |")
    L += ["", "---",
          "_Generated by `odm-trace --prd`. Replace every `[ANALYST]` placeholder, "
          "resolve any Gaps, then drop the `[TOOL]`/`[ANALYST]` tags for the final PRD._"]
    return "\n".join(L)


def generate_prd(ws: Workspace, traces: List[OperationTrace], out_dir) -> List[Path]:
    """Write one PRD-skeleton .prd.md per operation plus an index; return paths."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    written = []
    index = ["# Product Requirements Documents (drafts)", "",
             f"Generated from `{ws.root}` — {len(traces)} service(s). "
             "Each file has `[TOOL]` facts pre-filled; complete the `[ANALYST]` sections.", ""]
    for t, slug in assign_unique_slugs(traces):
        fn = f"{slug}.prd.md"
        (out / fn).write_text(render_prd_md(ws, t), encoding="utf-8")
        written.append(out / fn)
        flow = t.ruleflow.name if t.ruleflow else f"({t.execution_kind})"
        proj = f" — {t.target_project}" if t.target_project else ""
        index.append(f"- [{t.operation}]({fn}) — flow `{flow}`, {t.stats.get('rule_refs', 0)} rule(s){proj}")
    (out / "index.md").write_text("\n".join(index) + "\n", encoding="utf-8")
    logger.info("Wrote %d PRD draft(s) to %s", len(written), out)
    return written
